# Example Review Report

This is a deterministic example for comparison. A live AutoGen run will produce different wording.

## Executive Summary

The order-total sample has one major correctness bug, one critical security issue, and one privacy issue. The failing tests are meaningful and should guide the first patch.

## Highest-Priority Fixes

1. Fix tax calculation in `calculate_order_total()`: `tax = discounted_subtotal * tax_rate`.
2. Replace `eval()` in `apply_discount_rule()` with an allowlisted rule mapping.
3. Validate discount and item values before calculating totals.
4. Mask customer email in `format_receipt()`.

## Suggested Patch Plan

- Add input validation for item price, quantity, tax rate, and discount.
- Replace dynamic expressions with named discount rules.
- Update receipt formatting to mask emails.
- Re-run `pytest` and `ruff`.

# AutoGen Multi-Agent Practical: Code Review Team

This package builds a practical multi-agent code review system with AutoGen AgentChat.

You will build and run:

1. A single reviewer agent.
2. A two-agent reflection pattern: reviewer plus critic.
3. A specialist team using round-robin coordination.
4. An optional selector-style manager team.
5. Controlled local tools for file inspection, tests, and static checks.
6. State saving after team runs.

The practical target is a tiny Python order-total project with intentional defects. The goal is to learn multi-agent design, not ecommerce logic.

---

## What this practical teaches

By the end, you can explain and implement:

- How an `AssistantAgent` gets a role, model client, system message, and tools.
- How YAML keeps role definitions separate from orchestration code.
- How Python functions become AutoGen function-calling tools.
- How `RoundRobinGroupChat` coordinates specialist agents.
- How a selector-style team differs from round-robin coordination.
- Why termination conditions are essential for agent loops.
- How to save team state for inspection or later resumption.

---

## Package structure

```text
autogen_multi_agent/
├── notebook.ipynb
├── main.py
├── config.py
├── agents/
│   ├── roles.yaml
│   └── factory.py
├── tools/
│   └── code_review_tools.py
├── sample_project/
│   ├── order_total.py
│   ├── test_order_total.py
│   └── expected_findings.md
├── outputs/
│   ├── .gitkeep
│   └── example_review_report.md
├── .env.sample
├── requirements.txt
├── pyproject.toml
├── README.md
└── trainer_guide.md
```

---

## Setup

### 1. Create and activate a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

macOS / Linux:

```bash
python -m venv .venv
source .venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure environment variables

```bash
cp .env.sample .env
```

Then edit `.env`:

```text
OPENAI_API_KEY=sk-your-real-key
OPENAI_MODEL=gpt-4o-mini
```

The package is parameterized so the model can be changed without editing source code.

---

## Run the deterministic offline check first

This does not require an API key.

```bash
python main.py --offline
```

Expected behavior:

- Lists files in `sample_project/`.
- Reads `order_total.py` with line numbers.
- Runs the intentionally failing tests.
- Runs Ruff static checks.
- Shows the same controlled tools that the agents will call in the live demo.

---

## Run live AutoGen demos

### Single reviewer

```bash
python main.py --mode single
```

Use this to show how one tool-using agent behaves before adding a team.

### Two-agent reflection

```bash
python main.py --mode reflection
```

This demonstrates the reviewer/critic pattern from earlier self-reflection work.

### Specialist round-robin team

```bash
python main.py --mode round-robin
```

This is the main practical demo. The logic, security, maintainability, and synthesis roles take turns in a shared conversation.

### Optional selector team

```bash
python main.py --mode selector
```

This shows a manager-style pattern where a selector model chooses the next speaker. Use this only after the round-robin workflow is clear.

---

## Notebook workflow

Open the notebook after dependencies are installed:

```bash
jupyter notebook notebook.ipynb
```

The notebook is designed to run safely even before the API key is configured. Live AutoGen cells are guarded by an `LIVE_AUTOGEN_ENABLED` flag.

---

## Estimated API cost

The package defaults to `gpt-4o-mini` and a tiny sample project to keep demo cost low. Actual cost depends on:

- selected model,
- number of live runs,
- output length,
- whether the selector team is used.

A normal classroom pass should be well below the BIA per-session target when the default model and concise outputs are used. Check the current OpenAI pricing page before quoting exact costs.

---

## Common troubleshooting

### `OPENAI_API_KEY is not configured`

Copy `.env.sample` to `.env`, then add your real key.

### `ModuleNotFoundError: autogen_agentchat`

The virtual environment is not active or dependencies were not installed. Activate the environment and run:

```bash
pip install -r requirements.txt
```

### Tests fail in `sample_project`

That is expected. The project is intentionally buggy so the agents have real findings to discuss.

### Ruff flags `eval`

That is also expected. It is the security issue that the review team should catch.

---

## References

- AutoGen AgentChat teams: https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/tutorial/teams.html
- AutoGen tools and function calling: https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/tutorial/agents.html
- AutoGen human-in-the-loop: https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/tutorial/human-in-the-loop.html
- AutoGen state management: https://microsoft.github.io/autogen/stable/user-guide/agentchat-user-guide/tutorial/state.html
- AutoGen GitHub project status: https://github.com/microsoft/autogen

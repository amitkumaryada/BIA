"""Controlled tools exposed to AutoGen agents."""

"""Controlled local tools for the AutoGen code review practical.

The agents can inspect only the provided sample_project directory. This avoids giving
an LLM unrestricted file-system access while still demonstrating function calling.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SAMPLE_PROJECT_DIR = PACKAGE_ROOT / "sample_project"


def _result(payload: dict) -> str:
    """Serialize a tool result as formatted JSON.

    Params:
        payload: Result dictionary.

    Returns:
        JSON string safe for LLM consumption.
    """
    return json.dumps(payload, indent=2, ensure_ascii=False)

def _clean_subprocess_text(text: str) -> str:
    """Remove platform-specific startup noise from subprocess output.

    Params:
        text: Raw subprocess output.

    Returns:
        Cleaned output string.
    """
    if not text:
        return ""
    marker = "/opt/pyvenv/bin/python: No module named"
    if "Spreadsheet runtime warmup failed during python startup" in text:
        if marker in text:
            # Preserve meaningful command errors such as missing ruff.
            return text[text.rfind(marker):].strip()
        return ""
    return text.strip()


def _safe_project_path(relative_path: str) -> Path:
    """Resolve a relative path under sample_project and block traversal.

    Params:
        relative_path: Path relative to sample_project.

    Returns:
        Resolved Path inside sample_project.

    Raises:
        ValueError: If the path escapes sample_project or is not a file.
    """
    candidate = (SAMPLE_PROJECT_DIR / relative_path).resolve()
    root = SAMPLE_PROJECT_DIR.resolve()
    if root not in candidate.parents and candidate != root:
        raise ValueError("Access denied: path must stay inside sample_project.")
    if not candidate.exists() or not candidate.is_file():
        raise ValueError(f"File not found under sample_project: {relative_path}")
    return candidate


def summarize_project() -> str:
    """Summarize the sample project boundaries for reviewers.

    Returns:
        JSON string describing the target project and allowed tools.
    """
    return _result(
        {
            "project_root": "sample_project/",
            "scope": "Tiny Python order-total library with intentional bugs.",
            "allowed_actions": [
                "list files",
                "read files with line numbers",
                "run pytest",
                "run ruff static checks",
            ],
            "blocked_actions": [
                "editing files",
                "reading outside sample_project",
                "executing arbitrary shell commands",
            ],
        }
    )


def list_project_files() -> str:
    """List reviewable files in sample_project.

    Returns:
        JSON string containing relative file paths and sizes.
    """
    files: list[dict[str, object]] = []
    for path in sorted(SAMPLE_PROJECT_DIR.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            files.append(
                {
                    "path": path.relative_to(SAMPLE_PROJECT_DIR).as_posix(),
                    "size_bytes": path.stat().st_size,
                }
            )
    return _result({"files": files})


def read_project_file(relative_path: str) -> str:
    """Read a file from sample_project with line numbers.

    Params:
        relative_path: File path relative to sample_project.

    Returns:
        JSON string with numbered file contents.
    """
    try:
        path = _safe_project_path(relative_path)
        lines = path.read_text(encoding="utf-8").splitlines()
        numbered = [f"{index + 1:03d}: {line}" for index, line in enumerate(lines)]
        return _result({"path": relative_path, "content": "\n".join(numbered)})
    except Exception as exc:  # noqa: BLE001 - tool should return friendly errors to the model
        return _result({"error": str(exc), "path": relative_path})


def run_pytest() -> str:
    """Run the sample project's test suite.

    Returns:
        JSON string with return code, stdout, and stderr.
    """
    try:
        completed = subprocess.run(
            [sys.executable, "-m", "pytest", "sample_project", "--color=no"],
            cwd=PACKAGE_ROOT,
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
        return _result(
            {
                "command": f"{sys.executable} -m pytest sample_project",
                "return_code": completed.returncode,
                "stdout": _clean_subprocess_text(completed.stdout)[-4000:],
                "stderr": _clean_subprocess_text(completed.stderr)[-2000:],
            }
        )
    except subprocess.TimeoutExpired:
        return _result({"error": "pytest timed out after 20 seconds"})


def run_ruff_check() -> str:
    """Run a static style check on the sample project.

    Returns:
        JSON string with return code, stdout, and stderr.
    """
    try:
        completed = subprocess.run(
            [sys.executable, "-m", "ruff", "check", "sample_project", "--output-format=concise"],
            cwd=PACKAGE_ROOT,
            capture_output=True,
            text=True,
            timeout=20,
            check=False,
        )
        return _result(
            {
                "command": f"{sys.executable} -m ruff check sample_project",
                "return_code": completed.returncode,
                "stdout": _clean_subprocess_text(completed.stdout)[-4000:],
                "stderr": _clean_subprocess_text(completed.stderr)[-2000:],
            }
        )
    except subprocess.TimeoutExpired:
        return _result({"error": "ruff timed out after 20 seconds"})

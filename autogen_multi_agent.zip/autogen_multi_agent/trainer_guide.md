# Trainer Guide: AutoGen Multi-Agent Practical

## Practical goal

The practical turns AutoGen theory into a working system: a team of agents reviews a small Python project, uses controlled tools, coordinates findings, and produces a final report.

The key teaching message:

> Multi-agent systems are not magic. They are role design + controlled tools + orchestration + termination + observability.

---

## Suggested practical timing

Assume about 100 minutes are available for hands-on work after theory.

| Time | Segment | Trainer action |
|---:|---|---|
| 0–10 min | Project orientation | Open the folder, show `sample_project/`, explain that defects are intentional. |
| 10–20 min | Offline tools | Run `python main.py --offline`; show that tools work before AutoGen enters the picture. |
| 20–35 min | YAML roles | Walk through `agents/roles.yaml`; connect roles to system messages and descriptions. |
| 35–50 min | Single reviewer | Run `python main.py --mode single`; show the strengths and limits of one agent. |
| 50–65 min | Reflection team | Run `python main.py --mode reflection`; connect to earlier evaluator/critic patterns. |
| 65–85 min | Specialist team | Run `python main.py --mode round-robin`; pause when each specialist speaks. |
| 85–95 min | State and outputs | Show `outputs/*_team_state.json` and explain save/load use cases. |
| 95–100 min | Debrief | Compare live findings with `sample_project/expected_findings.md`. |

If time is tight, skip the selector team and human-approval discussion.

---

## Files to emphasize

### `sample_project/order_total.py`

Use this to ground the review. There are visible issues with tax calculation, `eval()`, validation, and receipt privacy.

### `tools/code_review_tools.py`

This is the most important engineering file. It demonstrates safe tool boundaries:

- agents can list files,
- agents can read only `sample_project/`,
- agents can run tests and static checks,
- agents cannot edit files or run arbitrary shell commands.

### `agents/roles.yaml`

This is where role design becomes explicit. Ask the class:

- Which agent should own correctness?
- Which agent should own security?
- What happens when two roles overlap?
- What should the synthesizer do that the reviewers should not?

### `agents/factory.py`

This connects AutoGen concepts to code:

- model client,
- AssistantAgent,
- tools,
- termination conditions,
- RoundRobinGroupChat,
- SelectorGroupChat,
- UserProxyAgent pattern.

---

## Live demo commands

Start with:

```bash
python main.py --offline
```

Then run:

```bash
python main.py --mode single
```

Then:

```bash
python main.py --mode reflection
```

Main team:

```bash
python main.py --mode round-robin
```

Optional stretch:

```bash
python main.py --mode selector
```

---

## What the agents should find

Expected high-value findings:

1. `calculate_order_total()` treats `0.18` as 1800% because it multiplies the fractional tax rate by `100`.
2. `apply_discount_rule()` uses `eval()` and can execute arbitrary Python code.
3. Discounts larger than subtotal are not rejected.
4. Receipt formatting exposes the full customer email address.
5. Tests fail because the implementation does not match expected business rules.

If the live output misses a finding, use it as a teaching moment. Multi-agent design improves coverage, but it does not guarantee completeness.

---

## Likely questions and strong answers

### Why not give the agent unrestricted terminal access?

Because unrestricted execution is unsafe. The practical uses controlled tools to show the correct pattern: expose narrow capabilities with clear docstrings and safe boundaries.

### Why use YAML for roles?

It separates agent behavior from orchestration code. This makes prompts reviewable, versionable, and easier for non-engineering stakeholders to inspect.

### Why round-robin first?

Round-robin is predictable and easy to debug. Selector teams are more dynamic, but they add another model decision and can be harder to reason about.

### Why does the final answer vary between runs?

LLM outputs are probabilistic. Role prompts, temperature, termination conditions, and available tool outputs reduce variance but do not eliminate it.

### Why does the package include an offline mode?

Offline mode proves the local project, tests, and tools work before introducing API keys, model calls, or multi-agent orchestration.

### Is AutoGen the best framework for production?

AutoGen is valuable for learning multi-agent patterns, but the official project now points new Microsoft-stack projects toward Microsoft Agent Framework. The transferable skills are role design, tool boundaries, team orchestration, and termination.

---

## Common errors and fixes

### Missing API key

Symptom:

```text
OPENAI_API_KEY is not configured
```

Fix:

```bash
cp .env.sample .env
```

Add the real key to `.env`.

### Wrong environment active

Symptom:

```text
ModuleNotFoundError: autogen_agentchat
```

Fix:

Activate the virtual environment and reinstall:

```bash
pip install -r requirements.txt
```

### Notebook async issue

If a notebook complains about an event loop, restart the kernel and run cells in order. The notebook keeps live calls guarded to reduce this issue.

### Selector team behaves unexpectedly

Use round-robin for the core demo. Selector routing depends on model judgment and may repeat or skip roles depending on conversation state.

### High token usage

Stop after one single-agent run and one round-robin run. Avoid re-running selector mode unless demonstrating orchestration trade-offs.

---

## What to skip if running short

Skip in this order:

1. Selector team.
2. Human-in-the-loop approval pattern.
3. State JSON inspection.
4. Reflection team.

Do not skip:

- offline tools,
- YAML roles,
- round-robin specialist team,
- termination explanation.

---

## Extension ideas

- Add a `patch_writer` agent that proposes a diff but does not apply it.
- Add a `test_designer` agent that writes missing tests.
- Add structured JSON output with Pydantic validation.
- Replace round-robin with selector routing and compare findings.
- Add a second sample project and compare transferability.
- Add LangSmith or other tracing in a later production-focused session.

---

## Trainer debrief prompts

Use these after the run:

- Which issue did the single agent miss that the team caught?
- Which role produced the highest-value finding?
- Did any agent repeat another agent unnecessarily?
- Did the termination marker work as expected?
- What guardrail would you add before allowing patch generation?

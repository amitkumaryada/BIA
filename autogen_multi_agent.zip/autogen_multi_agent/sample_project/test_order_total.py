"""Tests for the intentionally flawed order-total module."""

from __future__ import annotations

import pytest

from sample_project.order_total import apply_discount_rule, calculate_order_total, format_receipt


def test_total_uses_fractional_tax_rate() -> None:
    """A tax rate of 0.18 means 18%, not 1800%."""
    items = [{"price": 100.0, "quantity": 2}]
    assert calculate_order_total(items, tax_rate=0.18, discount=20.0) == 212.40


def test_discount_cannot_make_total_negative() -> None:
    """Discounts larger than subtotal should be rejected."""
    items = [{"price": 50.0, "quantity": 1}]
    with pytest.raises(ValueError):
        calculate_order_total(items, tax_rate=0.18, discount=80.0)


def test_unsafe_discount_rule_is_rejected() -> None:
    """Dynamic discount expressions must not allow code execution."""
    with pytest.raises(ValueError):
        apply_discount_rule("__import__('os').system('echo unsafe')", {"subtotal": 100.0})


def test_receipt_masks_email_address() -> None:
    """Receipt text should not expose the full email address."""
    receipt = format_receipt({"name": "Asha", "email": "asha@example.com"}, 118.0)
    assert "asha@example.com" not in receipt
    assert "asha@***" in receipt

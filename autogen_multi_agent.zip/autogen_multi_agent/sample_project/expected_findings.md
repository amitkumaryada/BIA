# Expected Findings for the Sample Project

This file is for trainer preparation and self-checking after the practical.

## High-priority findings

1. `order_total.py` multiplies `tax_rate` by `100` even though the function expects a fractional rate such as `0.18`. This creates a much larger tax than intended.
2. `apply_discount_rule()` uses `eval()`, which can execute arbitrary Python code. A safer approach is to map approved rule names to predefined functions or use a restricted expression evaluator.
3. `calculate_order_total()` allows discounts larger than subtotal, which can produce negative taxable amounts.
4. `format_receipt()` exposes the full email address. Mask or omit personally identifiable information in receipts/logs.

## Teaching point

The sample project is intentionally small. The goal is not a realistic ecommerce engine; the goal is to make multi-agent review behavior observable within a classroom time box.

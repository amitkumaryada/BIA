"""Tiny order-total module with intentional defects.

This file is deliberately imperfect so the AutoGen team has realistic issues to find.
Do not copy these patterns into production code.
"""

from __future__ import annotations


def calculate_order_total(items: list[dict], tax_rate: float = 0.18, discount: float = 0.0) -> float:
    """Calculate an order total after a flat discount and tax.

    Params:
        items: List of dictionaries with price and quantity.
        tax_rate: Tax rate as a fraction, such as 0.18 for 18%.
        discount: Flat discount amount.

    Returns:
        Rounded order total.
    """
    subtotal = 0.0
    for item in items:
        subtotal += item["price"] * item.get("quantity", 1)

    discounted_subtotal = subtotal - discount

    # BUG: tax_rate is already a fraction. Multiplying by 100 makes tax huge.
    tax = discounted_subtotal * (tax_rate * 100)

    return round(discounted_subtotal + tax, 2)


def apply_discount_rule(rule_expression: str, order_context: dict) -> float:
    """Apply a dynamic discount rule.

    Params:
        rule_expression: Expression provided by a business user.
        order_context: Values such as subtotal and customer tier.

    Returns:
        Discount amount.

    Security note:
        This function is intentionally unsafe for review practice.
    """
    # BUG: eval can execute arbitrary code.
    return float(eval(rule_expression, {}, order_context))  # noqa: S307


def format_receipt(customer: dict, total: float) -> str:
    """Create a short receipt string.

    Params:
        customer: Customer details.
        total: Order total.

    Returns:
        Receipt text.
    """
    name = customer.get("name", "Guest")
    email = customer.get("email", "unknown@example.com")
    return f"Receipt for {name} ({email}): total={total}"

"""Intentionally flawed sample project for code review practice."""

"""Runtime configuration for the AutoGen multi-agent code review practical.

All API keys and model choices are read from environment variables. Nothing in this
package contains real credentials.
"""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

PACKAGE_ROOT = Path(__file__).resolve().parent
SAMPLE_PROJECT_DIR = PACKAGE_ROOT / "sample_project"
OUTPUTS_DIR = PACKAGE_ROOT / "outputs"
ROLES_PATH = PACKAGE_ROOT / "agents" / "roles.yaml"

load_dotenv(PACKAGE_ROOT / ".env")

# DEFAULT: OpenAI. To swap models, edit OPENAI_MODEL in .env.
MODEL_NAME = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
DEBUG_AUTOGEN = os.getenv("DEBUG_AUTOGEN", "0") == "1"

REVIEW_TASK = """
Review the Python project in sample_project/.

Goal:
Produce a developer-facing code review report for correctness, security,
maintainability, and testability.

Required process:
1. Inspect available project files.
2. Read the source and test files.
3. Run the local tests.
4. Run a static check if available.
5. Identify issues with file names and line numbers where possible.
6. Prioritize findings by severity.
7. The final synthesis must end with the exact marker: FINAL_REVIEW_COMPLETE

Important constraints:
- Do not modify files during the review.
- Do not execute arbitrary code beyond the controlled local tools.
- Keep the final report concise and actionable.
""".strip()


def require_openai_key() -> None:
    """Raise a friendly error if the OpenAI API key is missing.

    Returns:
        None.

    Raises:
        RuntimeError: If OPENAI_API_KEY is not configured.
    """
    if not OPENAI_API_KEY or OPENAI_API_KEY == "sk-your-key-here":
        raise RuntimeError(
            "OPENAI_API_KEY is not configured. Copy .env.sample to .env and add your own key. "
            "You can still run `python main.py --offline` without an API key."
        )

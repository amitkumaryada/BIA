"""Factory functions for building AutoGen agents and teams.

The practical intentionally uses current AgentChat APIs rather than older GroupChatManager
examples. This keeps the classroom workflow close to the current AutoGen documentation.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import yaml

from config import MODEL_NAME, OPENAI_API_KEY, ROLES_PATH, require_openai_key
from tools.code_review_tools import (
    list_project_files,
    read_project_file,
    run_pytest,
    run_ruff_check,
    summarize_project,
)


@dataclass(frozen=True)
class RoleConfig:
    """Configuration for one AutoGen AssistantAgent role.

    Params:
        name: Stable agent name used by AutoGen.
        description: Short role description used by selector-style teams.
        system_message: Behavior contract for the agent.
        can_use_tools: Whether this role receives code review tools.

    Returns:
        Immutable role configuration object.
    """

    name: str
    description: str
    system_message: str
    can_use_tools: bool = True


def load_role_configs(path: Path = ROLES_PATH) -> dict[str, RoleConfig]:
    """Load role definitions from YAML.

    Params:
        path: YAML file path.

    Returns:
        Mapping of role name to RoleConfig.

    Raises:
        FileNotFoundError: If the YAML file does not exist.
        ValueError: If required role fields are missing.
    """
    raw = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or "agents" not in raw:
        raise ValueError("roles.yaml must contain a top-level 'agents' mapping.")

    roles: dict[str, RoleConfig] = {}
    for name, config in raw["agents"].items():
        try:
            roles[name] = RoleConfig(
                name=name,
                description=str(config["description"]),
                system_message=str(config["system_message"]),
                can_use_tools=bool(config.get("can_use_tools", True)),
            )
        except KeyError as exc:
            raise ValueError(f"Role '{name}' is missing required field: {exc}") from exc
    return roles


def code_review_tools() -> list[Callable[..., str]]:
    """Return controlled local tools exposed to AutoGen agents.

    Returns:
        List of Python functions. AgentChat converts them into FunctionTool schemas.
    """
    return [
        summarize_project,
        list_project_files,
        read_project_file,
        run_pytest,
        run_ruff_check,
    ]


def build_model_client():
    """Create an OpenAI model client for AutoGen.

    Returns:
        OpenAIChatCompletionClient instance.

    Raises:
        RuntimeError: If OPENAI_API_KEY is missing.
    """
    require_openai_key()

    # Import lazily so offline demos can run without importing AutoGen dependencies.
    from autogen_ext.models.openai import OpenAIChatCompletionClient

    # COST NOTE: Typical class demo runs are intended to stay low-cost by using
    # gpt-4o-mini and a tiny sample project. Actual cost depends on model pricing,
    # number of runs, and output length.
    return OpenAIChatCompletionClient(
        model=MODEL_NAME,
        api_key=OPENAI_API_KEY,
        parallel_tool_calls=False,
        temperature=0.2,
    )


def build_assistant_agent(role: RoleConfig, model_client, tools: list[Callable[..., str]] | None = None):
    """Build one AutoGen AssistantAgent from a role configuration.

    Params:
        role: Role configuration loaded from YAML.
        model_client: AutoGen chat completion client.
        tools: Optional controlled tool functions.

    Returns:
        AssistantAgent configured for the role.
    """
    from autogen_agentchat.agents import AssistantAgent

    selected_tools = tools if role.can_use_tools else []
    return AssistantAgent(
        name=role.name,
        description=role.description,
        model_client=model_client,
        tools=selected_tools,
        system_message=role.system_message,
        reflect_on_tool_use=True,
        max_tool_iterations=4,
    )


def build_single_reviewer(model_client):
    """Create a single reviewer agent for the first demo.

    Params:
        model_client: AutoGen chat completion client.

    Returns:
        AssistantAgent.
    """
    roles = load_role_configs()
    return build_assistant_agent(roles["single_reviewer"], model_client, code_review_tools())


def build_reflection_team(model_client):
    """Create a two-agent reflection team: reviewer plus critic.

    Params:
        model_client: AutoGen chat completion client.

    Returns:
        RoundRobinGroupChat with review/critique termination.
    """
    from autogen_agentchat.conditions import MaxMessageTermination, TextMentionTermination
    from autogen_agentchat.teams import RoundRobinGroupChat

    roles = load_role_configs()
    tools = code_review_tools()
    primary = build_assistant_agent(roles["developer_reviewer"], model_client, tools)
    critic = build_assistant_agent(roles["critique_reviewer"], model_client, tools)
    termination = TextMentionTermination("APPROVE") | MaxMessageTermination(max_messages=8)
    return RoundRobinGroupChat([primary, critic], termination_condition=termination)


def build_round_robin_review_team(model_client):
    """Create the specialist multi-agent code review team.

    Params:
        model_client: AutoGen chat completion client.

    Returns:
        RoundRobinGroupChat that cycles through specialist reviewers and synthesizer.
    """
    from autogen_agentchat.conditions import MaxMessageTermination, TextMentionTermination
    from autogen_agentchat.teams import RoundRobinGroupChat

    roles = load_role_configs()
    tools = code_review_tools()
    participants = [
        build_assistant_agent(roles["logic_reviewer"], model_client, tools),
        build_assistant_agent(roles["security_reviewer"], model_client, tools),
        build_assistant_agent(roles["maintainability_reviewer"], model_client, tools),
        build_assistant_agent(roles["report_synthesizer"], model_client, tools),
    ]
    termination = TextMentionTermination("FINAL_REVIEW_COMPLETE") | MaxMessageTermination(max_messages=12)
    return RoundRobinGroupChat(participants, termination_condition=termination)


def build_selector_review_team(model_client):
    """Create an optional manager-style selector team.

    This is a stretch demo. The selector uses the model to choose the next specialist,
    so it can cost slightly more than round-robin.

    Params:
        model_client: AutoGen chat completion client.

    Returns:
        SelectorGroupChat.
    """
    from autogen_agentchat.conditions import MaxMessageTermination, TextMentionTermination
    from autogen_agentchat.teams import SelectorGroupChat

    roles = load_role_configs()
    tools = code_review_tools()
    participants = [
        build_assistant_agent(roles["logic_reviewer"], model_client, tools),
        build_assistant_agent(roles["security_reviewer"], model_client, tools),
        build_assistant_agent(roles["maintainability_reviewer"], model_client, tools),
        build_assistant_agent(roles["report_synthesizer"], model_client, tools),
    ]
    selector_prompt = """
    You are selecting the next reviewer for a code review team.
    Choose exactly one participant from {participants}.
    Use logic_reviewer for failing tests and calculations.
    Use security_reviewer for unsafe execution or data exposure.
    Use maintainability_reviewer for readability, typing, and design.
    Use report_synthesizer when enough specialist findings exist to produce the final report.
    Conversation so far:
    {history}
    """.strip()
    termination = TextMentionTermination("FINAL_REVIEW_COMPLETE") | MaxMessageTermination(max_messages=12)
    return SelectorGroupChat(
        participants,
        model_client=model_client,
        termination_condition=termination,
        selector_prompt=selector_prompt,
        allow_repeated_speaker=False,
    )


def build_human_approval_team(model_client):
    """Create a short human-approval demonstration team.

    Params:
        model_client: AutoGen chat completion client.

    Returns:
        RoundRobinGroupChat that asks a human to approve from the console.
    """
    from autogen_agentchat.agents import UserProxyAgent
    from autogen_agentchat.conditions import TextMentionTermination
    from autogen_agentchat.teams import RoundRobinGroupChat

    roles = load_role_configs()
    tools = code_review_tools()
    synthesizer = build_assistant_agent(roles["report_synthesizer"], model_client, tools)
    human_approver = UserProxyAgent("human_approver", input_func=input)
    termination = TextMentionTermination("APPROVE")
    return RoundRobinGroupChat([synthesizer, human_approver], termination_condition=termination)

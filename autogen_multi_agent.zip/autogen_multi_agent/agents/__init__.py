"""Agent definitions and factory helpers for the AutoGen practical."""

"""Command-line runner for the AutoGen multi-agent practical.

Run offline checks without an API key:
    python main.py --offline

Run a live AutoGen team after creating .env:
    python main.py --mode round-robin
"""

from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path

from agents.factory import (
    build_model_client,
    build_reflection_team,
    build_round_robin_review_team,
    build_selector_review_team,
    build_single_reviewer,
)
from config import OUTPUTS_DIR, REVIEW_TASK
from tools.code_review_tools import list_project_files, read_project_file, run_pytest, run_ruff_check


def run_offline_demo() -> None:
    """Run deterministic local checks without an LLM.

    Returns:
        None.
    """
    print("\n=== Offline project file list ===")
    print(list_project_files())

    print("\n=== Source file preview ===")
    print(read_project_file("order_total.py"))

    print("\n=== Pytest result ===")
    print(run_pytest())

    print("\n=== Ruff result ===")
    print(run_ruff_check())

    print(
        "\nOffline demo complete. The live AutoGen run uses the same tools, "
        "but lets specialist agents decide when to call them."
    )


async def run_live(mode: str) -> None:
    """Run a live AutoGen demo.

    Params:
        mode: One of single, reflection, round-robin, selector.

    Returns:
        None.
    """
    from autogen_agentchat.ui import Console

    model_client = build_model_client()
    try:
        if mode == "single":
            agent = build_single_reviewer(model_client)
            stream = agent.run_stream(task=REVIEW_TASK)
        elif mode == "reflection":
            team = build_reflection_team(model_client)
            stream = team.run_stream(task=REVIEW_TASK)
        elif mode == "round-robin":
            team = build_round_robin_review_team(model_client)
            stream = team.run_stream(task=REVIEW_TASK)
        elif mode == "selector":
            team = build_selector_review_team(model_client)
            stream = team.run_stream(task=REVIEW_TASK)
        else:
            raise ValueError(f"Unsupported mode: {mode}")

        # COST NOTE: One live run sends the source file, test output, and agent messages
        # through the selected chat model. Keep output concise during class.
        await Console(stream)

        if mode in {"reflection", "round-robin", "selector"}:
            state = await team.save_state()
            OUTPUTS_DIR.mkdir(exist_ok=True)
            state_path = OUTPUTS_DIR / f"{mode}_team_state.json"
            state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
            print(f"\nSaved team state to: {state_path}")
    finally:
        await model_client.close()


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments.

    Returns:
        Parsed argparse namespace.
    """
    parser = argparse.ArgumentParser(description="AutoGen multi-agent code review practical")
    parser.add_argument(
        "--mode",
        choices=["single", "reflection", "round-robin", "selector"],
        default="round-robin",
        help="Live AutoGen pattern to run.",
    )
    parser.add_argument(
        "--offline",
        action="store_true",
        help="Run deterministic local checks without OpenAI or AutoGen.",
    )
    return parser.parse_args()


def main() -> None:
    """Entry point for the command-line demo.

    Returns:
        None.
    """
    args = parse_args()
    if args.offline:
        run_offline_demo()
        return

    try:
        asyncio.run(run_live(args.mode))
    except RuntimeError as exc:
        print(f"\nConfiguration error: {exc}")
        print("Tip: run `python main.py --offline` first to verify local files and tests.")


if __name__ == "__main__":
    main()

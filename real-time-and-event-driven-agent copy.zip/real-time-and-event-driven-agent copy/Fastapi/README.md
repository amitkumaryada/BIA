# FastAPI Demo Project

A learning project demonstrating FastAPI basics including REST endpoints, Pydantic models, and JSON data handling.

## Project Structure

```
Fastapi/
├── main.py          # Main FastAPI app with user creation endpoint
├── api/
│   ├── api.py       # Utility functions for reading JSON data
│   └── api1.py      # FastAPI app with math operations
└── data/            # JSON data files (required)
    ├── users.json
    └── questions.json
```

## Requirements

- Python 3.8+
- FastAPI
- Uvicorn
- Pydantic

Install dependencies:

```bash
pip install fastapi uvicorn pydantic
```

## Running the Applications

### Main App (Port 8000)

```bash
python main.py
# or
uvicorn main:app --reload
```

**Endpoints:**
- `POST /users` — Create a user (requires JSON body with `username` and `email`)

Example request:
```bash
curl -X POST http://localhost:8000/users \
  -H "Content-Type: application/json" \
  -d '{"username": "john", "email": "john@example.com"}'
```

### Math API (Port 5001)

```bash
python api/api1.py
```

**Endpoints:**
- `GET /` — Welcome message
- `POST /add?a=5&b=3` — Add two numbers
- `POST /elvi?a=10&b=4` — Subtract two numbers

## Data Files

Create a `data/` folder in the project root with the following JSON files:

**users.json:**
```json
[
  {"id": 1, "name": "Alice"},
  {"id": 2, "name": "Bob"}
]
```

**questions.json:**
```json
[
  {"position": 1, "question": "What is FastAPI?"},
  {"position": 2, "question": "How do you define routes?"}
]
```

## API Documentation

Once running, access the interactive API docs at:
- Swagger UI: `http://localhost:8000/docs`
- ReDoc: `http://localhost:8000/redoc`

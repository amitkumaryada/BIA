# WebSocket Pub/Sub Project

A **real-time publish/subscribe messaging system** built with FastAPI WebSockets. Multiple clients can communicate through channels in real-time.

## Project Structure

```
websocket/
├── main.py              # FastAPI app entry point
├── publisher_module.py  # Publisher WebSocket endpoint
├── subscriber_module.py # Subscriber WebSocket endpoint
├── connections.py       # Shared in-memory connection store
├── requirements.txt     # Dependencies
└── README.md
```

## How It Works

### Connections (`connections.py`)
Shared state storing active WebSocket connections organized by channel and username:
```python
subscribers = {
    "channel1": {"user1": WebSocket, "user2": WebSocket},
    "channel2": {"user3": WebSocket}
}
```

### Subscribe Endpoint (`subscriber_module.py`)
- **URL:** `ws://localhost:8000/ws/subscribe/{channel}/{username}`
- Accepts WebSocket connection and registers user to a channel
- Keeps connection alive, waiting for messages
- Removes user from channel on disconnect

### Publish Endpoint (`publisher_module.py`)
- **URL:** `ws://localhost:8000/ws/publish/{channel}/{sender}`
- Accepts messages from publisher
- Broadcasts to all subscribers in that channel
- Cleans up dead connections automatically

## Requirements

```bash
pip install -r requirements.txt
```

## Running the Server

### Option 1: Python
```bash
python main.py
```

### Option 2: Docker
```bash
docker-compose up --build
```

## Usage Example

**Terminal 1 — Start server:**
```bash
python main.py
```

**Terminal 2 — Subscribe to "news" channel:**
```bash
websocat ws://localhost:8000/ws/subscribe/news/alice
```

**Terminal 3 — Publish to "news" channel:**
```bash
websocat ws://localhost:8000/ws/publish/news/bob
# Type messages and press Enter — alice will receive them instantly
```

## Installing websocat

### macOS
```bash
brew install websocat
```

### Linux
```bash
cargo install websocat
# or download from https://github.com/vi/websocat/releases
```

### Windows
Download `websocat.exe` from [releases](https://github.com/vi/websocat/releases), put it in your PATH, and run:
```bash
websocat ws://localhost:8000/ws/subscribe/{channel_name}/{subscriber_name}
```

## Key Features

- **Channel-based** — Messages are isolated per channel
- **Real-time** — No polling, instant delivery via WebSockets
- **In-memory** — No persistence, messages are live only
- **Multi-subscriber** — One publisher can broadcast to many subscribers
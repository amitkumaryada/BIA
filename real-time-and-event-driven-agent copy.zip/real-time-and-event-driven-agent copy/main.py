from fastapi import FastAPI

app = FastAPI()


@app.get("/")
def read_root():
    return {"Hello": "World"}


@app.get("/get_my_info/")
def get_my_info():
    return {"name": "Amit Yadav", "age": 30}


@app.post("/square_item/{item_id}")
def create_item(item_id: int, p: int):
    return {"item_id": item_id, "square": item_id ** p}
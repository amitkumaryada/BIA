# Google ADK Multi-Agent System with Neo4j

A multi-agent system built using **Google Agent Development Kit (ADK)** that helps users build knowledge graphs with Neo4j. The system uses LLM-powered agents (via Groq) to understand user intent, suggest files, and propose graph schemas.

## Project Structure

```
googleADK/
├── README.md                         # This file
├── TUTORIAL.md                       # Step-by-step learning guide
├── requirements.txt                  # Python dependencies
├── .env                              # Environment variables (create this)
├── helper.py                         # Utility functions and AgentCaller wrapper
├── neo4j_for_adk.py                  # Neo4j database wrapper for ADK
├── tools.py                          # Tool definitions for agents
├── intro_to_adk.ipynb                # Introduction to Google ADK basics
├── user_intent.ipynb                 # User intent agent implementation
├── file_suggession_agent.ipynb       # File suggestion agent
└── schema_proposal_structured.ipynb  # Schema proposal agent (multi-agent loop)
```

## Prerequisites

- **Python 3.10+**
- **Docker** (for running Neo4j)
- **Groq API Key** (free tier available at https://console.groq.com)

## Installation

### Step 1: Clone/Navigate to the Project

```bash
cd /path/to/googleADK
```

### Step 2: Create a Virtual Environment (Recommended)

```bash
python -m venv venv
source venv/bin/activate  # On macOS/Linux
# OR
venv\Scripts\activate     # On Windows
```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

**Dependencies:**
- `google-adk==1.5.0` - Google Agent Development Kit
- `neo4j==5.28.1` - Neo4j Python driver
- `groq` - Groq API client (used via LiteLLM)

### Step 4: Set Up Environment Variables

Create a `.env` file in the `googleADK` directory:

```bash
# Groq API Key (Required - get free key at https://console.groq.com)
GROQ_API_KEY=your_groq_api_key_here

# Neo4j Configuration
NEO4J_URI=bolt://localhost:7687
NEO4J_USERNAME=neo4j
NEO4J_PASSWORD=your_password
NEO4J_DATABASE=neo4j

# Neo4j Import Directory (for file operations)
NEO4J_IMPORT_DIR=/path/to/your/data/import
```

### Step 5: Start Neo4j Database with Docker

Run the following command to start Neo4j:

```bash
docker run \
  --publish=7474:7474 \
  --publish=7687:7687 \
  --env NEO4J_AUTH=neo4j/your_password \
  --volume=$(pwd)/../data:/data \
  --volume=$(pwd)/../data/import:/var/lib/neo4j/import \
  neo4j:latest
```

**Ports:**
- `7474` - Neo4j Browser (HTTP)
- `7687` - Bolt protocol (database connection)

**Verify Neo4j is running:**
- Open http://localhost:7474 in your browser
- Login with username `neo4j` and your password

## Running the Notebooks

### Option 1: Using Jupyter Notebook

```bash
pip install jupyter
jupyter notebook
```

Then open any of the `.ipynb` files.

### Option 2: Using VS Code

1. Install the **Jupyter** extension in VS Code
2. Open any `.ipynb` file
3. Select the Python kernel from your virtual environment

## Notebooks Overview

### 1. `intro_to_adk.ipynb` - Introduction to Google ADK

**Purpose:** Learn the basics of Google ADK

**What you'll learn:**
- Setting up LLM models with LiteLLM (Groq)
- Creating basic agents with tools
- Using Runner and SessionService
- Understanding ADK events and responses

**Key concepts:**
- `Agent` - Core agent definition
- `LiteLlm` - LLM wrapper (supports Groq, OpenAI, etc.)
- `Runner` - Agent execution engine
- `InMemorySessionService` - Session management

### 2. `user_intent.ipynb` - User Intent Agent

**Purpose:** Build an agent that helps users define knowledge graph use cases

**What you'll learn:**
- Defining agent instructions with chain-of-thought
- Creating tools with `ToolContext` for state management
- Human-in-the-loop interaction patterns

**Output:** `approved_user_goal` containing:
- `kind_of_graph` - Brief graph type description
- `graph_description` - Detailed purpose description

### 3. `file_suggession_agent.ipynb` - File Suggestion Agent

**Purpose:** Agent that suggests files for knowledge graph construction

**Features:**
- Lists available files from import directory
- Samples file contents
- Suggests relevant files based on user goal

### 4. `schema_proposal_structured.ipynb` - Schema Proposal Agent

**Purpose:** Multi-agent system that proposes graph schema

**Features:**
- **Schema Proposal Agent** - Analyzes files and proposes node/relationship constructions
- **Schema Critic Agent** - Validates and critiques the proposed schema
- **LoopAgent** - Orchestrates refinement iterations
- Uses the "critic pattern" for iterative improvement

## Groq Models

This project uses Groq for fast LLM inference. Available models:

| Model | Use Case | Rate Limits |
|-------|----------|-------------|
| `groq/llama-3.3-70b-versatile` | Complex reasoning | Lower TPM |
| `groq/llama-3.1-8b-instant` | Fast responses | Higher TPM |
| `groq/mixtral-8x7b-32768` | Long context | Medium TPM |

**Rate Limit Tips:**
- Use `llama-3.1-8b-instant` for development to avoid rate limits
- Add delays between requests if hitting limits
- Upgrade to Groq Dev Tier for higher limits

## Key Components

### `helper.py`

Provides utility functions:
- `load_env()` - Load environment variables
- `get_neo4j_import_dir()` - Get Neo4j import directory
- `AgentCaller` - Wrapper class for agent interaction
- `make_agent_caller()` - Factory function to create AgentCaller

### `neo4j_for_adk.py`

Neo4j database wrapper:
- `Neo4jForADK` - Database connection class
- `send_query()` - Execute Cypher queries
- `tool_success()` / `tool_error()` - ADK-friendly response helpers

### `tools.py`

Agent tools for:
- File operations (`list_available_files`, `sample_file`)
- Neo4j operations (`neo4j_is_ready`, `clear_neo4j_data`, `create_uniqueness_constraint`)
- State management (`get_approved_user_goal`, `get_approved_files`)

## Troubleshooting

### Neo4j Connection Issues

```python
# Test Neo4j connection
from neo4j_for_adk import graphdb
result = graphdb.send_query("RETURN 'Neo4j is Ready!' as message")
print(result)
```

### Groq API Issues

```python
# Test Groq connection
from google.adk.models.lite_llm import LiteLlm
llm = LiteLlm(model="groq/llama-3.1-8b-instant")
print(llm.llm_client.completion(
    model=llm.model, 
    messages=[{"role": "user", "content": "Are you ready?"}], 
    tools=[]
))
```

### Common Errors

| Error | Solution |
|-------|----------|
| `NEO4J_URI not set` | Add `NEO4J_URI=bolt://localhost:7687` to `.env` |
| `GROQ_API_KEY not set` | Add your Groq API key to `.env` |
| `Connection refused` | Ensure Neo4j Docker container is running |
| `Authentication failed` | Check Neo4j username/password in `.env` |
| `RateLimitError` | Use smaller model or wait between requests |
| `URI scheme b'' not supported` | Ensure `.env` file is loaded (restart kernel) |

## Example Usage

```python
from google.adk.agents import Agent
from google.adk.models.lite_llm import LiteLlm
from helper import make_agent_caller

# Create an agent with Groq
llm = LiteLlm(model="groq/llama-3.1-8b-instant")
my_agent = Agent(
    name="my_agent",
    model=llm,
    description="A helpful assistant",
    instruction="You are a helpful assistant.",
    tools=[]
)

# Create caller and interact
caller = await make_agent_caller(my_agent)
response = await caller.call("Hello!")
```

## Learning Path

For a complete learning experience, see **[TUTORIAL.md](TUTORIAL.md)** which covers:
1. ADK fundamentals
2. Building your first agent
3. State management and tools
4. Multi-agent collaboration

## License

This project is for educational purposes.
# Building a Knowledge Graph Multi-Agent System with Google ADK

A hands-on tutorial that takes you from zero to a fully functional multi-agent system for building knowledge graphs.

---

## The Story

Imagine you're a data engineer tasked with building a knowledge graph for supply chain analysis. You have CSV files containing information about products, parts, suppliers, and their relationships. Instead of manually designing the schema and writing import scripts, you'll build an AI-powered system that:

1. **Understands your goal** through natural conversation
2. **Analyzes your data files** and suggests which ones to use
3. **Proposes a graph schema** with nodes and relationships
4. **Critiques and refines** the schema through multi-agent collaboration

Let's build this system step by step.

---

## Chapter 1: Introduction to Google ADK

**Notebook:** `intro_to_adk.ipynb`

### What You'll Learn

- How to set up the Google Agent Development Kit
- Creating your first agent with tools
- Understanding the event-driven execution model

### The Basics

Google ADK is a framework for building AI agents that can:
- Use tools to interact with external systems
- Maintain conversation state across turns
- Collaborate with other agents

### Setting Up the LLM

We use **Groq** for fast inference via the `LiteLlm` wrapper:

```python
from google.adk.models.lite_llm import LiteLlm

# Groq models are prefixed with "groq/"
llm = LiteLlm(model="groq/llama-3.3-70b-versatile")
llm_small = LiteLlm(model="groq/llama-3.1-8b-instant")  # Faster, higher rate limits
```

### Your First Agent

An agent needs:
- **name** - Unique identifier
- **model** - The LLM to use
- **description** - What the agent does (used for delegation)
- **instruction** - Detailed behavior guidelines
- **tools** - Functions the agent can call

```python
from google.adk.agents import Agent

hello_agent = Agent(
    name="hello_agent_v1",
    model=llm,
    description="Has friendly chats with a user.",
    instruction="""You are a helpful assistant. 
                   If the user provides their name, use the 'say_hello' tool.""",
    tools=[say_hello],
)
```

### Tools: Connecting Agents to the World

Tools are Python functions that agents can call. They receive arguments from the LLM and return structured results:

```python
def say_hello(person_name: str) -> dict:
    """Formats a welcome message to a named person."""
    return graphdb.send_query(
        "RETURN 'Hello to you, ' + $person_name AS reply",
        {"person_name": person_name}
    )
```

### Running an Agent

The execution flow involves three components:

1. **SessionService** - Manages conversation history and state
2. **Runner** - Orchestrates agent execution
3. **Events** - Represent steps in the agent's thinking

```python
from google.adk.sessions import InMemorySessionService
from google.adk.runners import Runner

session_service = InMemorySessionService()
await session_service.create_session(
    app_name="hello_app",
    user_id="user_1",
    session_id="session_1"
)

runner = Runner(
    agent=hello_agent,
    app_name="hello_app",
    session_service=session_service
)
```

### The AgentCaller Helper

To simplify interaction, we use a helper class:

```python
from helper import make_agent_caller

caller = await make_agent_caller(hello_agent)
response = await caller.call("Hello, I'm Alice!")
```

### Key Takeaways

- Agents are defined with instructions and tools
- Tools return structured dictionaries with `status` keys
- The Runner handles the execution loop
- Events track the agent's reasoning process

---

## Chapter 2: Understanding User Intent

**Notebook:** `user_intent.ipynb`

### The Challenge

Before building a knowledge graph, we need to understand:
- What kind of graph does the user want?
- What's the purpose of the graph?

### Designing Agent Instructions

Good instructions have four parts:

#### 1. Role and Goal
```python
agent_role_and_goal = """
    You are an expert at knowledge graph use cases. 
    Your primary goal is to help the user come up with a knowledge graph use case.
"""
```

#### 2. Conversational Hints
```python
agent_conversational_hints = """
    If the user is unsure, suggest classic use cases like:
    - social network with friends and relationships
    - logistics network with suppliers and customers
    - recommendation system with products and purchases
"""
```

#### 3. Output Definition
```python
agent_output_definition = """
    A user goal has two components:
    - kind_of_graph: 2-3 words describing the graph
    - description: a few sentences about the intention
"""
```

#### 4. Chain-of-Thought Directions
```python
agent_chain_of_thought_directions = """
    1. Understand the user's goal
    2. Ask clarifying questions as needed
    3. Use 'set_perceived_user_goal' to record your perception
    4. Present the goal to the user for confirmation
    5. If approved, use 'approve_perceived_user_goal' to save it
"""
```

### State Management with ToolContext

Tools can read and write to session state using `ToolContext`:

```python
from google.adk.tools import ToolContext

def set_perceived_user_goal(kind_of_graph: str, graph_description: str, 
                            tool_context: ToolContext):
    """Sets the perceived user's goal."""
    user_goal_data = {
        "kind_of_graph": kind_of_graph, 
        "graph_description": graph_description
    }
    tool_context.state["perceived_user_goal"] = user_goal_data
    return tool_success("perceived_user_goal", user_goal_data)
```

### Human-in-the-Loop Pattern

The agent doesn't just set the goal—it asks for approval:

```python
def approve_perceived_user_goal(tool_context: ToolContext):
    """Approves the perceived goal after user confirmation."""
    if "perceived_user_goal" not in tool_context.state:
        return tool_error("Set perceived user goal first!")
    
    tool_context.state["approved_user_goal"] = tool_context.state["perceived_user_goal"]
    return tool_success("approved_user_goal", tool_context.state["approved_user_goal"])
```

### Example Conversation

```
User: I'd like a bill of materials graph for root-cause analysis.

Agent: To create a BOM graph, I need to clarify:
       1. Who will use this graph?
       2. What issues do you want to analyze?

User: I'm concerned about manufacturing and supplier issues.

Agent: Based on your focus, here's my understanding:
       - Kind: Bill of Materials
       - Purpose: Trace issues through the supply chain
       
       Does this match your vision?

User: Approve that goal.

Agent: ✓ Your goal has been approved!
```

### Key Takeaways

- Break instructions into logical sections
- Use `ToolContext.state` to persist data across turns
- Implement human-in-the-loop for critical decisions
- Return structured responses with `tool_success` / `tool_error`

---

## Chapter 3: File Suggestion Agent

**Notebook:** `file_suggession_agent.ipynb`

### The Challenge

Given the user's goal, which data files should we use to build the knowledge graph?

### File Discovery Tools

```python
def list_available_files(tool_context: ToolContext) -> dict:
    """Lists files available for knowledge graph construction."""
    import_dir = Path(get_neo4j_import_dir())
    file_names = [str(f.relative_to(import_dir)) 
                  for f in import_dir.rglob("*") if f.is_file()]
    tool_context.state["all_available_files"] = file_names
    return tool_success("all_available_files", file_names)

def sample_file(file_path: str) -> dict:
    """Samples a file by reading up to 100 lines."""
    # Read and return file content for analysis
    ...
```

### The Agent's Task

1. Retrieve the approved user goal
2. List available files
3. Sample promising files to understand their structure
4. Suggest which files are relevant
5. Get user approval

### Output: Approved Files

```python
approved_files = [
    'products.csv',
    'assemblies.csv', 
    'parts.csv',
    'part_supplier_mapping.csv',
    'suppliers.csv'
]
```

---

## Chapter 4: Schema Proposal with Multi-Agent Collaboration

**Notebook:** `schema_proposal_structured.ipynb`

### The Challenge

This is the most complex task: analyzing files and proposing a graph schema. We use **multiple agents** working together.

### The Critic Pattern

Instead of one agent doing everything, we use three:

1. **Schema Proposal Agent** - Proposes node and relationship constructions
2. **Schema Critic Agent** - Validates and critiques the proposal
3. **CheckStatusAndEscalate** - Decides if refinement is complete

### Schema Proposal Agent

#### Instructions
```python
proposal_agent_instruction = """
    You are an expert at knowledge graph modeling.
    
    Guidance for identifying nodes vs relationships:
    - Single thing with unique ID → Node
    - Combination of two things → Relationship
    - Node with multiple IDs → Node with reference relationships
    
    Steps:
    1. Get approved user goal and files
    2. Sample each file to find unique identifiers
    3. Propose node or relationship constructions
    4. Present the construction plan
"""
```

#### Construction Tools

```python
def propose_node_construction(
    approved_file: str,
    proposed_label: str,
    unique_column_name: str,
    proposed_properties: list[str],
    tool_context: ToolContext
) -> dict:
    """Propose a node construction for an approved file."""
    construction_plan = tool_context.state.get("proposed_construction_plan", {})
    construction_plan[proposed_label] = {
        "construction_type": "node",
        "source_file": approved_file,
        "label": proposed_label,
        "unique_column_name": unique_column_name,
        "properties": proposed_properties
    }
    tool_context.state["proposed_construction_plan"] = construction_plan
    return tool_success("node_construction", construction_plan[proposed_label])
```

### Schema Critic Agent

The critic validates the proposal:

```python
critic_agent_instruction = """
    Criticize the proposed schema:
    - Are unique identifiers actually unique?
    - Could any nodes be relationships instead?
    - Is every node connected?
    - Are any relationships redundant?
    
    If valid, respond with: 'valid'
    If problems exist, respond with: 'retry' and list issues
"""
```

### The Loop Agent

The `LoopAgent` orchestrates the refinement cycle:

```python
from google.adk.agents import LoopAgent

schema_refinement_loop = LoopAgent(
    name="schema_refinement_loop",
    max_iterations=2,
    sub_agents=[
        schema_proposal_agent,
        schema_critic_agent,
        CheckStatusAndEscalate(name="StopChecker")
    ]
)
```

### Custom Agent: CheckStatusAndEscalate

```python
from google.adk.agents.base_agent import BaseAgent
from google.adk.events import Event, EventActions

class CheckStatusAndEscalate(BaseAgent):
    async def _run_async_impl(self, ctx):
        feedback = ctx.session.state.get("feedback", "valid")
        should_stop = (feedback == "valid")
        yield Event(
            author=self.name, 
            actions=EventActions(escalate=should_stop)
        )
```

### The Refinement Flow

```
┌─────────────────────────────────────────────────────┐
│                  LoopAgent                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐ │
│  │  Proposal   │→ │   Critic    │→ │   Check &   │ │
│  │   Agent     │  │   Agent     │  │  Escalate   │ │
│  └─────────────┘  └─────────────┘  └─────────────┘ │
│         ↑                                    │      │
│         └────────── retry ───────────────────┘      │
│                                                     │
│         └────────── valid ──────────────────────────┼──→ Done
└─────────────────────────────────────────────────────┘
```

### Example Output

```python
proposed_construction_plan = {
    "Assembly": {
        "construction_type": "node",
        "source_file": "assemblies.csv",
        "label": "Assembly",
        "unique_column_name": "assembly_id",
        "properties": ["assembly_name", "description", "weight_kg"]
    },
    "Part": {
        "construction_type": "node",
        "source_file": "parts.csv",
        "label": "Part",
        "unique_column_name": "part_id",
        "properties": ["part_name", "category", "cost_usd"]
    },
    "SUPPLIES": {
        "construction_type": "relationship",
        "source_file": "part_supplier_mapping.csv",
        "relationship_type": "SUPPLIES",
        "from_node_label": "Part",
        "from_node_column": "part_id",
        "to_node_label": "Supplier",
        "to_node_column": "supplier_id"
    }
}
```

### Key Takeaways

- Use multiple agents for complex tasks
- The critic pattern improves output quality
- `LoopAgent` enables iterative refinement
- Custom agents can implement specialized logic
- State flows between agents via session context

---

## The Complete Pipeline

```
┌──────────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────────┐
│  User Intent │ →  │    File      │ →  │   Schema     │ →  │   Graph      │
│    Agent     │    │  Suggestion  │    │  Proposal    │    │ Construction │
└──────────────┘    └──────────────┘    └──────────────┘    └──────────────┘
       ↓                   ↓                   ↓                   ↓
  approved_         approved_           proposed_            Neo4j
  user_goal          files           construction_plan      Knowledge
                                                              Graph
```

---

## Summary

| Notebook | Agent Type | Key Concepts |
|----------|------------|--------------|
| `intro_to_adk.ipynb` | Single Agent | Tools, Runner, Events |
| `user_intent.ipynb` | Single Agent | State, Human-in-the-loop |
| `file_suggession_agent.ipynb` | Single Agent | File operations |
| `schema_proposal_structured.ipynb` | Multi-Agent | LoopAgent, Critic pattern |

---

## Next Steps

1. **Run the notebooks** in order to see the system in action
2. **Modify the instructions** to handle different domains
3. **Add new tools** for your specific use case
4. **Extend the pipeline** with graph construction agents

Happy building! 🚀

# Product Reviews (Sample)

These are **synthetic** sample reviews to support the unstructured-data portion of the lab.

## P001 — ErgoDesk 120
- "The desk is sturdy, but the motor sometimes stalls near the top height."
- "Love the frame, but a few bolts arrived slightly stripped."

## P002 — ComfyChair Pro
- "Great lumbar support at first, but the mesh back started squeaking after two weeks."
- "Comfortable seat, but the back frame feels a bit flimsy."

## P003 — Oak Bookshelf
- "Looks beautiful, but one of the side panels had a small crack."
- "Easy to assemble; however the shelves sag a little when fully loaded."

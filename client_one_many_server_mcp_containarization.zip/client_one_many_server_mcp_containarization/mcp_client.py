from mcp import ClientSession
from mcp.client.sse import sse_client
import asyncio

async def main():
    async with sse_client("http://localhost:8000/sse") as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            tools = await session.list_tools()
            print("Available tools:", [t.name for t in tools.tools])

            result = await session.call_tool("add", {"a": 3, "b": 5})
            print("Result:", result)

asyncio.run(main())

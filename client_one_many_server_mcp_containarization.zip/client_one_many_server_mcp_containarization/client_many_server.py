from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from langchain_mcp_adapters.tools import load_mcp_tools
from langgraph.prebuilt import create_react_agent
from langchain_groq import ChatGroq
import asyncio
import os

GROQ_API_KEY = "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"
os.environ["GROQ_API_KEY"] = GROQ_API_KEY

model = ChatGroq(model="openai/gpt-oss-120b", temperature=0)

# Define both server parameters
server_params_1 = StdioServerParameters(
    command="python",
    args=["mcp_server.py"]
)

server_params_2 = StdioServerParameters(
    command="python",
    args=["mcp_server2.py"]
)


async def run_agent():
    # Connect to BOTH servers and combine tools
    async with stdio_client(server_params_1) as (read1, write1), \
               stdio_client(server_params_2) as (read2, write2):
        
        async with ClientSession(read1, write1) as session1, \
                   ClientSession(read2, write2) as session2:
            
            # Initialize both sessions
            await session1.initialize()
            await session2.initialize()
            
            print("Both MCP Sessions Initialized.")
            
            # Load tools from both servers
            tools1 = await load_mcp_tools(session1)
            tools2 = await load_mcp_tools(session2)
            
            # Combine all tools
            all_tools = tools1 + tools2
            
            print(f"Loaded Tools: {[tool.name for tool in all_tools]}")
            
            agent = create_react_agent(model, all_tools)
            
            print("ReAct Agent Created.")
            
            response = await agent.ainvoke({
                "messages": [("user", "What is (7+9)x17, then give me sine of the output and also check leave balance for employee E001")]
            })
            
            return response["messages"][-1].content


if __name__ == "__main__":
    print("Starting MCP Client with multiple servers...")
    result = asyncio.run(run_agent())
    print("\nAgent Final Response:")
    print(result)
import math
# import requests
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("Math Tools Server")

emp_datails = {
    "E001": {"name": "John Doe", "department": "Engineering", "position": "Senior Developer"},
    "E002": {"name": "Jane Smith", "department": "Marketing", "position": "Manager"},
    "E003": {"name": "Bob Johnson", "department": "Sales", "position": "Representative"}
}

@mcp.tool()
def get_employee_details(employee_id: str) -> dict:
    """Get employee details by ID"""
    return emp_datails.get(employee_id, {"error": "Employee not found"})

@mcp.tool()
def add(a: int, b: int) -> int:
    print(f"Server received add request: {a}, {b}")
    return a + b

@mcp.tool()
def multiply(a: int, b: int) -> int:
    print(f"Server received multiply request: {a}, {b}")
    return a * b

@mcp.tool()
def sine(a: float) -> float:
    print(f"Server received sine request: {a}")
    return math.sin(a)



if __name__ =="__main__":
    import uvicorn
    print("Starting MCP Server on port 8000....")
    app = mcp.sse_app()
    uvicorn.run(app, host="0.0.0.0", port=8000)
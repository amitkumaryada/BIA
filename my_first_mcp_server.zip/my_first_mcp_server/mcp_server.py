import math
import requests
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("My MCP Server")

@mcp.tool()
def add(a: int, b: int) -> int:
    print(f"Server received add request: {a}, {b}")
    return a + b

@mcp.tool()
def multiply(a: int, b: int) -> int:
    print(f"Server received multiply request: {a}, {b}")
    return a * b

@mcp.tool()
def sine(a: float) -> float:
    print(f"Server received sine request: {a}")
    return math.sin(a)




if __name__ =="__main__":
    print("Starting MCP Server....")
    mcp.run(transport="stdio")
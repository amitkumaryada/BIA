from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from langchain_mcp_adapters.tools import load_mcp_tools
from langgraph.prebuilt import create_react_agent
from langchain_groq import ChatGroq
# from langchain_openai import ChatOpenAI
import asyncio
import os


# Set your API key (replace with your actual key or use environment variables)

GROQ_API_KEY = " " # Replace with your key

os.environ["GROQ_API_KEY"] = GROQ_API_KEY

# OPENAI_API_KEY = "YOUR_OPENAI_API_KEY"

# os.environ["OPENAI_API_KEY"] = OPENAI_API_KEY

# Initialize the LLM model

model = ChatGroq(model="openai/gpt-oss-120b", temperature=0)

# model = ChatOpenAI(model="gpt-4o-mini", temperature=0)



server_params = StdioServerParameters(
    command="python",
    # args=["mcp_server.py"]
    args=["mcp_server2.py"]
)



async def run_agent():
    async with stdio_client(server_params) as (read, write):

        async with ClientSession(read, write) as session:

            await session.initialize()

            print("MCP Session Initialized.")

            tools = await load_mcp_tools(session)

            print(f"Loaded Tools: {[tool.name for tool in tools]}")

            agent = create_react_agent(model, tools)

            print("ReAct Agent Created.")

            print(f"Invoking agent with query")

            response = await agent.ainvoke({
                
                # "messages": [("user", "What is (7+9)x17, then give me sine of the output recieved")]

                "messages": [("user", "Check leave balance for employee E001, then apply leave for dates 2025-01-15 and 2025-01-16, and finally show the leave history")]

            })

            print("Agent invocation complete.")

            # Return the content of the last message (usually the agent's final answer)

            return response["messages"][-1].content


# Standard Python entry point check

if __name__ == "__main__":
    # Run the asynchronous run_agent function and wait for the result

    print("Starting MCP Client...")
    result = asyncio.run(run_agent())
    print("\nAgent Final Response:")
    print(result)
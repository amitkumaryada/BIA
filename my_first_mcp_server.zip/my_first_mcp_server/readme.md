### Setup and Running

**Prerequisites:**
- Python version 3.11 or newer
- Set up a new virtual environment (optional)
- An API key (e.g., OpenAI or Groq, depending on the model you choose)
- Specific Python libraries: `langchain-mcp-adapters`, `langgraph`, and an LLM library (like `langchain-openai` or `langchain-groq`) of your choice

**Steps:**
1. Install dependencies: `pip install -r requirements.txt`
2. Run the MCP server: `python mcp_server.py`
3. Run the client: `python client.py`

# AgentOps & Production Scaling – Deployment & Cost Control (Practical Package)

This folder contains runnable materials for **Session 3: Deployment & Cost Control**.

Learn to:
- Build multi-stage Docker images
- Deploy agents with **Ray Serve autoscaling**
- Use **LangServe** to expose agents as APIs
- Implement **budget alert scripts** for cost control

## 📂 Folder Structure
```
agentops-deployment-cost/
├── app/
│   ├── docker_app/
│   │   ├── Dockerfile
│   │   └── main.py
│   ├── rayserve_app.py
│   ├── langserve_app.py
│   ├── budget_alert.py
│   └── utils.py
├── notebooks/
│   ├── 01_rayserve_autoscale_demo.ipynb
│   └── 02_budget_visualization.ipynb
├── .env.example
├── README.md
├── README_trainer.md
└── requirements.txt
```

## 🚀 Quick Start
1. Install dependencies:
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```
2. Copy `.env.example` to `.env` and fill your OpenAI key.
3. Run demos:
```bash
python app/rayserve_app.py
python app/langserve_app.py
python app/budget_alert.py
```
4. Check notebooks for Ray Serve autoscaling visualization and cost tracking.

from fastapi import FastAPI
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from langserve import add_routes
import os
from utils import load_env

os.environ["OPENAI_API_KEY"] = load_env()

prompt = ChatPromptTemplate.from_template("Explain {topic} in simple terms.")
chain = prompt | ChatOpenAI(model="gpt-3.5-turbo")

app = FastAPI(title="LangServe Adapter Demo")
add_routes(app, chain, path="/explain")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

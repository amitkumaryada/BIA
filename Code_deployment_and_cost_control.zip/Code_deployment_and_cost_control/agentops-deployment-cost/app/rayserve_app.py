from ray import serve
from fastapi import FastAPI, Request
import ray
from openai import OpenAI
import os
from utils import load_env

app = FastAPI()

@serve.deployment(autoscaling_config={"min_replicas": 1, "max_replicas": 3})
@serve.ingress(app)
class LLMService:
    def __init__(self):
        key = load_env()
        os.environ["OPENAI_API_KEY"] = key
        self.client = OpenAI()

    @app.post("/ask")
    async def ask(self, request: Request):
        data = await request.json()
        query = data.get("query", "")
        resp = self.client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": query}]
        )
        return {"response": resp.choices[0].message.content}

entry = LLMService.bind()

if __name__ == "__main__":
    ray.init()
    serve.run(entry)

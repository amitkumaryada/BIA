import pandas as pd, random, smtplib, os
from email.message import EmailMessage

BUDGET_LIMIT = 50.0  # $ threshold
current_spend = round(random.uniform(30, 70), 2)

def send_alert(current):
    msg = EmailMessage()
    msg["Subject"] = "⚠️ Budget Alert – AgentOps"
    msg["From"] = "ai-monitor@example.com"
    msg["To"] = "admin@example.com"
    msg.set_content(f"Monthly usage exceeded: ${current:.2f}")
    print("Simulated alert email:")
    print(msg)

if current_spend > BUDGET_LIMIT:
    send_alert(current_spend)
else:
    print(f"✅ Within budget (${current_spend:.2f})")

# Log spend
pd.DataFrame([{"spend": current_spend}]).to_csv("budget_log.csv", index=False)

print("🚀 AgentOps Docker Multi-Stage Demo Running...")
print("This container demonstrates a clean two-stage build.")

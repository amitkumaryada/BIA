# Trainer Follow-Along: Dashboards & Practical Demonstrations

This guide covers **Grafana + Prometheus** setup, as well as what to show in **LangSmith** and **Helicone** dashboards during the live demo.

---

## Part A — Prometheus + Grafana (Open-Source)

### 1) Launch with Docker
```bash
# Prometheus (port 9090)
docker run -d --name prometheus -p 9090:9090   -v $PWD/dashboards/prometheus.yml:/etc/prometheus/prometheus.yml   prom/prometheus

# Grafana (port 3000)
docker run -d --name grafana -p 3000:3000 grafana/grafana
```

> Make sure `metrics_exporter.py` is running locally so Prometheus can scrape `http://host.docker.internal:8000/metrics` (on macOS/Windows) or `http://host.docker.internal:8000/metrics` / `http://<your-ip>:8000/metrics` on Linux.

### 2) Add Prometheus as a data source in Grafana
- Open `http://localhost:3000` → login (admin / admin on first run) → Data sources → **Prometheus**.
- URL: `http://localhost:9090` → Save & Test.

### 3) Import the prebuilt dashboard
- Dashboards → Import → Upload `dashboards/grafana-dashboard.json` → Select the Prometheus data source → Import.

### 4) Panels to highlight
- **Total LLM Requests** (`sum(llm_requests_total)`)
- **LLM Latency (95th percentile)** (`histogram_quantile(0.95, sum(rate(llm_request_latency_seconds_bucket[5m])) by (le))`)
- Optional: Add your own panels for error counters or model-specific labels.

---

## Part B — LangSmith (Tracing)

**What to show:**
- The **trace timeline** after running `langsmith_demo.py` and `agent_demo.py`.
- The *Thought → Action → Observation* steps in the agent run.
- Prompt parameters (temperature, model) and token usage.
- If time permits: Compare two runs after changing the prompt.

**Where to click:**
- **Traces** list → pick the latest run → expand spans → show inputs/outputs and timing.

---

## Part C — Helicone (Analytics Proxy)

**Before demo:**
- Ensure `.env` has `OPENAI_API_BASE=https://oai.helicone.ai/v1` and `HELICONE_API_KEY=...`.
- Run `python app/helicone_demo.py` a few times.

**What to show in the Helicone UI:**
- Requests table with model, latency, tokens, cost.
- Filters by model or metadata (e.g., `Helicone-User-Id`, `Helicone-Property-Project`).

**Talking points:**
- Cost hotspots and latency outliers.
- Per-user tracking for multi-tenant agent apps.
- Caching & how proxies can reduce repeat-call spend.

---

## Troubleshooting Tips

- If Grafana panels are empty: check Prometheus target status at `http://localhost:9090/targets`.
- If no Prometheus target: ensure `metrics_exporter.py` is running and the `prometheus.yml` scrape URL matches your host.
- LangSmith missing traces: verify `LANGCHAIN_TRACING_V2=true` and a valid `LANGCHAIN_API_KEY`.
- Helicone missing data: confirm `OPENAI_API_BASE` and `Helicone-Auth` header, and that you are sending requests via `helicone_demo.py`.

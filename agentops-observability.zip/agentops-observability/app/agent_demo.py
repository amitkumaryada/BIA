"""LangChain Agent demo with tracing + a simple web search tool.
Shows Thought → Action → Observation steps in LangSmith.

Run:
  python app/agent_demo.py
"""
import os
from utils import load_env
from langchain_openai import ChatOpenAI
from langchain_core.tools import tool
from ddgs import DDGS

@tool
def ddg_search(query: str) -> str:
    """Search the web using DuckDuckGo."""
    with DDGS() as ddgs:
        results = ddgs.text(query, max_results=5)
        lines = [f"- {r['title']}: {r['href']}" for r in results]
        return "\n".join(lines[:5])

def main():
    env = load_env()
    os.environ["LANGCHAIN_TRACING_V2"] = env["LANGCHAIN_TRACING_V2"]
    os.environ["LANGCHAIN_PROJECT"] = env["LANGCHAIN_PROJECT"]
    if env["LANGCHAIN_API_KEY"]:
        os.environ["LANGCHAIN_API_KEY"] = env["LANGCHAIN_API_KEY"]

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)
    llm_with_tools = llm.bind_tools([ddg_search])
    
    messages = [{"role": "user", "content": "Find one open-source tool for LLM observability and explain why it's useful (2 lines)."}]
    response = llm_with_tools.invoke(messages)
    
    if response.tool_calls:
        for tool_call in response.tool_calls:
            if tool_call["name"] == "ddg_search":
                print(f"[Tool Call] Searching: {tool_call['args']}")
                result = ddg_search.invoke(tool_call["args"])
                print(f"[Tool Result]\n{result}\n")
                messages.append(response)
                messages.append({"role": "tool", "tool_call_id": tool_call["id"], "content": result})
        final_response = llm_with_tools.invoke(messages)
        print(final_response.content)
    else:
        print(response.content if response.content else "[No response content - model may have returned empty]")

if __name__ == "__main__":
    main()

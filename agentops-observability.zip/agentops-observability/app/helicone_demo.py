"""Helicone analytics demo.
Routes OpenAI requests through the Helicone proxy for cost/latency tracking.

Run:
  python app/helicone_demo.py
Then open Helicone dashboard to view analytics.
"""



from openai import OpenAI

client = OpenAI(
  api_key=
  base_url="https://ai-gateway.helicone.ai/v1",
)

completion = client.chat.completions.create(
  model="gpt-4o-mini",
  messages=[
    {
      "role": "user",
      "content": "Summarize observability in one sentence"
    }
  ]
)
print(completion.choices[0].message.content)

if __name__ == "__main__":
    main()
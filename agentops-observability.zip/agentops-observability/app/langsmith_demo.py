"""Minimal LangSmith tracing demo.

Run:
  python app/langsmith_demo.py
Then open your LangSmith UI to inspect traces.
"""
import os
from utils import load_env
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

def main():
    env = load_env()
    os.environ["LANGCHAIN_TRACING_V2"] = env["LANGCHAIN_TRACING_V2"]
    os.environ["LANGCHAIN_PROJECT"] = env["LANGCHAIN_PROJECT"]
    if env["LANGCHAIN_API_KEY"]:
        os.environ["LANGCHAIN_API_KEY"] = env["LANGCHAIN_API_KEY"]

    llm = ChatOpenAI(model="gpt-4o-mini", temperature=0.2)
    msg = [HumanMessage(content="In exactly 3 bullet points, define importance of observability for AI agents.")]
    resp = llm.invoke(msg)
    print(resp.content)

if __name__ == "__main__":
    main()

# AgentOps & Production Scaling – Observability (Practical Package)

This package contains runnable code, notebooks, and configuration files to demonstrate **Observability for Agentic Systems** using **LangSmith Tracing**, **Helicone Analytics**, and **Grafana + Prometheus** dashboards.

## 🧰 Contents

```
agentops-observability/
├── app/
│   ├── agent_demo.py              # LangChain agent with tracing
│   ├── langsmith_demo.py          # Minimal tracing example
│   ├── helicone_demo.py           # Route requests via Helicone proxy
│   ├── metrics_exporter.py        # Exposes Prometheus metrics for Grafana
│   └── utils.py                   # Common helpers (env, OpenAI client)
├── dashboards/
│   ├── grafana-dashboard.json     # Importable Grafana dashboard
│   └── prometheus.yml             # Prometheus scrape config (port 8000)
├── notebooks/
│   ├── 01_langsmith_tracing.ipynb
│   └── 02_grafana_prometheus_metrics.ipynb
├── .env.example                   # Copy to .env and add your keys
├── README.md                      # You are here
├── README_dashboards.md           # Follow-along guide for trainer
└── requirements.txt
```

## 🚀 Quick Start

> Python 3.9+ recommended

1) **Create virtualenv & install deps**
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

2) **Set environment variables**
- Copy `.env.example` → `.env` and fill keys.
- Or export manually in your shell.

3) **Run a simple trace (LangSmith)**
```bash
python app/langsmith_demo.py
```

4) **Try Helicone analytics (optional)**
- Ensure `.env` has `OPENAI_API_BASE=https://oai.helicone.ai/v1` and `HELICONE_API_KEY=...`
```bash
python app/helicone_demo.py
```

5) **Expose metrics for Grafana**
```bash
python app/metrics_exporter.py
```
Metrics are served at `http://localhost:8000/metrics`.

6) **(Optional) LangChain Agent with tool + tracing**
```bash
python app/agent_demo.py
```

## 🧪 Notebooks

- `notebooks/01_langsmith_tracing.ipynb` – run and then inspect traces in LangSmith UI.
- `notebooks/02_grafana_prometheus_metrics.ipynb` – generate and observe Prometheus metrics.

## 📊 Dashboards (Prometheus + Grafana)

See **README_dashboards.md** for a trainer follow-along to launch Prometheus and Grafana with Docker, add the data source, and import the included dashboard JSON.

## 🔐 Keys & Privacy

Never commit your real API keys. Use `.env` for local dev and rotate keys periodically.

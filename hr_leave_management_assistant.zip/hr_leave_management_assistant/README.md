# HR Leave Management Assistant - MCP Server

An AI-powered HR Leave Management system built using the **Model Context Protocol (MCP)**. This project demonstrates how to interpret business problems and map them to MCP tools, resources, and prompts.


## 📋 Table of Contents

- [Business Problem]
- [Architecture & Design]
- [MCP Mapping]
- [New Capabilities Added]
- [Installation]
- [Running the Server]
- [Docker Deployment]
- [API Reference]
- [Testing]
- [Design Decisions]

---

## 🎯 Business Problem

### Problem Statement
Organizations need an efficient way to manage employee leave that:
- Tracks employee leave balances accurately
- Processes leave applications quickly
- Provides visibility into team availability
- Generates insights for HR planning
- Integrates with AI assistants for natural language interactions

### Solution
This MCP server provides a comprehensive leave management system that can be accessed by AI assistants (like Claude, ChatGPT via LangChain) through the Model Context Protocol, enabling natural language HR operations.

---

## 🏗 Architecture & Design

```
┌─────────────────────────────────────────────────────────────────┐
│                        AI Assistant                              │
│                   (Claude, LangChain Agent)                      │
└─────────────────────────┬───────────────────────────────────────┘
                          │ MCP Protocol (stdio)
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    MCP Server Layer                              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │
│  │   Tools     │  │  Resources  │  │   Prompts   │              │
│  │ (Actions)   │  │ (Data)      │  │ (Templates) │              │
│  └─────────────┘  └─────────────┘  └─────────────┘              │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Business Logic Layer                          │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │  Employee Management │ Leave Processing │ Analytics     │    │
│  └─────────────────────────────────────────────────────────┘    │
└─────────────────────────┬───────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────┐
│                    Data Layer (SQLite)                           │
│  ┌───────────┐ ┌──────────────┐ ┌─────────────────┐            │
│  │ employees │ │ leave_records│ │ balance_history │            │
│  └───────────┘ └──────────────┘ └─────────────────┘            │
│  ┌───────────────┐ ┌──────────────┐                            │
│  │ leave_policies│ │ team_calendar│                            │
│  └───────────────┘ └──────────────┘                            │
└─────────────────────────────────────────────────────────────────┘
```

---

## 🔧 MCP Mapping

### Tools (Actions)
Tools are executable functions that perform operations:

| Tool | Business Function | Description |
|------|------------------|-------------|
| `add_employee` | Onboarding | Add new employee to system |
| `remove_employee` | Offboarding | Remove employee and records |
| `update_leave_balance` | HR Adjustment | Modify leave balance |
| `list_employees` | Directory | List employees by department |
| `get_employee_details` | Profile View | Get detailed employee info |
| `get_leave_balance` | Balance Check | Check remaining leave days |
| `apply_leave` | Leave Request | Submit leave application |
| `cancel_leave` | Leave Cancellation | Cancel approved leave |
| `get_leave_history` | Leave Records | View leave history |
| `get_department_summary` | Reporting | Department-wise statistics |
| `get_leave_analytics` | **NEW** Analytics | Comprehensive leave insights |
| `get_team_availability` | **NEW** Planning | Team calendar view |
| `get_low_balance_alerts` | **NEW** Alerts | Low balance notifications |
| `get_recent_leave_activity` | Activity Log | Recent leave applications |

### Resources (Static Data)
Resources provide read-only access to data:

| Resource URI | Description |
|--------------|-------------|
| `hr://policies/leave` | Company leave policies document |
| `hr://employees/directory` | Employee directory listing |
| `hr://reports/summary` | Dashboard summary statistics |

### Prompts (Templates)
Pre-built templates for common operations:

| Prompt | Use Case |
|--------|----------|
| `onboard_employee` | New employee onboarding workflow |
| `process_leave_request` | Leave application processing |
| `generate_department_report` | Department analytics report |
| `monthly_hr_review` | Monthly HR review checklist |

---

## 🆕 New Capabilities Added

### 1. Leave Analytics (`get_leave_analytics`)
Comprehensive analytics including:
- Leave utilization rates
- Leave type distribution with visual bars
- Department-wise usage comparison
- Monthly trends visualization
- Top leave takers ranking

### 2. Team Availability (`get_team_availability`)
Project planning support:
- Date range availability check
- Department-wise calendar view
- Conflict identification
- Available headcount per day

### 3. Low Balance Alerts (`get_low_balance_alerts`)
Proactive HR management:
- Configurable threshold alerts
- Critical vs warning classification
- Department breakdown
- Actionable employee list

### 4. Leave Cancellation (`cancel_leave`)
Complete leave lifecycle:
- Cancel previously applied leave
- Automatic balance restoration
- Team calendar updates
- Audit trail maintenance

---

## 📦 Installation

### Prerequisites
- Python 3.10+
- [UV](https://github.com/astral-sh/uv) package manager
- Docker (for containerized deployment)

### Using UV (Recommended)

```bash
# Clone the repository
cd hr_leave_management_assistant

# Install UV if not already installed
curl -LsSf https://astral.sh/uv/install.sh | sh

# Create virtual environment and install dependencies
uv sync

# For development dependencies
uv sync --dev
```

### Using pip (Alternative)

```bash
# Create virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install dependencies
pip install -e .
```

---

## 🚀 Running the Server

### Direct Execution

```bash
# Using UV
uv run python -m hr_leave_management_assistant.server

# Or directly
python src/hr_leave_management_assistant/server.py
```

### With MCP Client

```bash
# Set up environment variables
cp .env.example .env
# Edit .env with your GROQ_API_KEY

# Run interactive client
uv run python -m hr_leave_management_assistant.client

# Or with a single query
uv run python -m hr_leave_management_assistant.client "List all employees"
```

### MCP Inspector (Development)

```bash
# Install MCP inspector
npx @modelcontextprotocol/inspector

# Connect to server
npx @modelcontextprotocol/inspector python src/hr_leave_management_assistant/server.py
```

---

## 🐳 Docker Deployment

### Build and Run

```bash
# Build the image
docker build -t hr-leave-management:latest .

# Run the container
docker run -d \
  --name hr-mcp-server \
  -v hr-data:/app/data \
  hr-leave-management:latest
```

### Using Docker Compose

```bash
# Start services
docker-compose up -d

# View logs
docker-compose logs -f hr-mcp-server

# Stop services
docker-compose down

# Development mode with hot reload
docker-compose --profile dev up hr-mcp-dev
```

### Container Features
- **Multi-stage build** for optimized image size
- **Non-root user** for security
- **Health checks** for container orchestration
- **Volume mounts** for data persistence
- **Resource limits** for production stability

---

## 📚 API Reference

### Example Tool Usage

#### Add Employee
```python
add_employee(
    employee_id="E001",
    name="John Doe",
    email="john.doe@company.com",
    department="Engineering",
    position="Software Engineer",
    initial_leave_balance=20
)
```

#### Apply Leave
```python
apply_leave(
    employee_id="E001",
    leave_dates=["2025-01-15", "2025-01-16"],
    leave_type="Annual"
)
```

#### Get Analytics
```python
get_leave_analytics(year=2025, month=1)
```

#### Check Team Availability
```python
get_team_availability(
    department="Engineering",
    start_date="2025-01-01",
    end_date="2025-01-31"
)
```

---

## 🧪 Testing

```bash
# Run all tests
uv run pytest tests/ -v

# Run with coverage
uv run pytest tests/ -v --cov=src/hr_leave_management_assistant

# Run specific test
uv run pytest tests/test_server.py::TestHRLeaveManagement::test_add_employee -v
```

---

## 🎨 Design Decisions

### 1. Why MCP?
- **Standardized Protocol**: MCP provides a standard way for AI assistants to interact with external tools
- **Tool Discovery**: AI can discover available capabilities dynamically
- **Type Safety**: Strong typing for tool parameters and returns
- **Transport Agnostic**: Works over stdio, HTTP, WebSocket

### 2. Why SQLite?
- **Zero Configuration**: No separate database server needed
- **Portable**: Single file database, easy to backup/restore
- **Sufficient for Use Case**: Handles typical HR workloads efficiently
- **Container Friendly**: Easy to persist with Docker volumes

### 3. Why UV?
- **Fast**: 10-100x faster than pip
- **Reliable**: Deterministic dependency resolution
- **Modern**: Built for modern Python workflows
- **Lock Files**: Reproducible builds with `uv.lock`

### 4. Security Considerations
- Non-root container user
- Environment variable for sensitive data
- Input validation on all tools
- SQL parameterized queries (no injection)

### 5. Extensibility
The architecture supports easy extension:
- Add new tools by decorating functions with `@mcp.tool()`
- Add new resources with `@mcp.resource()`
- Add new prompts with `@mcp.prompt()`

---

## 📁 Project Structure

```
hr_leave_management_assistant/
├── src/
│   └── hr_leave_management_assistant/
│       ├── __init__.py          # Package initialization
│       ├── server.py            # MCP server implementation
│       └── client.py            # LangChain client
├── tests/
│   ├── __init__.py
│   └── test_server.py           # Test suite
├── pyproject.toml               # UV/Python project config
├── Dockerfile                   # Production container
├── Dockerfile.dev               # Development container
├── docker-compose.yml           # Container orchestration
├── .env.example                 # Environment template
└── README.md                    # This file
```

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Run tests: `uv run pytest tests/ -v`
5. Submit a pull request

---

## 📄 License

MIT License - See LICENSE file for details.

---

## 🙏 Acknowledgments

- [Model Context Protocol](https://modelcontextprotocol.io/) - The protocol specification
- [FastMCP](https://github.com/jlowin/fastmcp) - Python MCP framework
- [UV](https://github.com/astral-sh/uv) - Fast Python package manager
- [LangChain](https://langchain.com/) - LLM application framework

"""
HR Leave Management Assistant - MCP Server

An AI-powered leave management system using Model Context Protocol (MCP)
that provides tools, resources, and prompts for HR operations.
"""

__version__ = "1.0.0"
__author__ = "HR Tech Team"

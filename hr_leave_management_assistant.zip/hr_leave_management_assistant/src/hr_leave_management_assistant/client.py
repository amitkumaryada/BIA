"""
HR Leave Management MCP Client

This module provides a client interface to interact with the HR Leave Management
MCP Server using LangChain and LangGraph.
"""

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client
from langchain_mcp_adapters.tools import load_mcp_tools
from langgraph.prebuilt import create_react_agent
from langchain_groq import ChatGroq
import asyncio
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Get API key from environment
GROQ_API_KEY = os.environ.get("GROQ_API_KEY")

if not GROQ_API_KEY:
    print("⚠️  Warning: GROQ_API_KEY not set. Please set it in .env file or environment.")


def get_model():
    """Initialize the LLM model"""
    return ChatGroq(
        model=os.environ.get("GROQ_MODEL", "llama-3.1-70b-versatile"),
        temperature=0
    )


def get_server_params():
    """Get MCP server parameters"""
    server_script = os.path.join(
        os.path.dirname(os.path.abspath(__file__)),
        "server.py"
    )
    return StdioServerParameters(
        command="python",
        args=[server_script]
    )


async def run_agent(query: str) -> str:
    """
    Run the HR assistant agent with a given query.
    
    Args:
        query: The user's question or request
    
    Returns:
        The agent's response
    """
    server_params = get_server_params()
    model = get_model()
    
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            print("✅ MCP Session Initialized.")
            
            tools = await load_mcp_tools(session)
            print(f"🔧 Loaded Tools: {[tool.name for tool in tools]}")
            
            agent = create_react_agent(model, tools)
            print("🤖 ReAct Agent Created.")
            
            print(f"📝 Processing query: {query[:100]}...")
            
            response = await agent.ainvoke({
                "messages": [("user", query)]
            })
            
            print("✅ Agent invocation complete.")
            return response["messages"][-1].content


async def interactive_session():
    """
    Run an interactive session with the HR assistant.
    """
    server_params = get_server_params()
    model = get_model()
    
    print("\n" + "="*60)
    print("🏢 HR Leave Management Assistant")
    print("="*60)
    print("Type 'quit' or 'exit' to end the session.")
    print("Type 'help' for example queries.\n")
    
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            print("✅ Connected to HR MCP Server\n")
            
            tools = await load_mcp_tools(session)
            agent = create_react_agent(model, tools)
            
            while True:
                try:
                    query = input("\n👤 You: ").strip()
                    
                    if not query:
                        continue
                    
                    if query.lower() in ['quit', 'exit']:
                        print("\n👋 Goodbye!")
                        break
                    
                    if query.lower() == 'help':
                        print("""
📚 Example Queries:
- "List all employees"
- "Check leave balance for employee E001"
- "Apply leave for E001 on 2025-01-15 and 2025-01-16"
- "Show leave history for E002"
- "Get department summary for Engineering"
- "Show leave analytics for this year"
- "Check team availability for Engineering from 2025-01-01 to 2025-01-31"
- "Show employees with low leave balance"
- "Add new employee E010 named Alice Wonder in Marketing as Marketing Lead"
                        """)
                        continue
                    
                    response = await agent.ainvoke({
                        "messages": [("user", query)]
                    })
                    
                    print(f"\n🤖 Assistant:\n{response['messages'][-1].content}")
                    
                except KeyboardInterrupt:
                    print("\n\n👋 Session interrupted. Goodbye!")
                    break
                except Exception as e:
                    print(f"\n❌ Error: {str(e)}")


def main():
    """Main entry point for the client"""
    import sys
    
    if len(sys.argv) > 1:
        # Run with command line query
        query = " ".join(sys.argv[1:])
        result = asyncio.run(run_agent(query))
        print("\n🤖 Response:")
        print(result)
    else:
        # Run interactive session
        asyncio.run(interactive_session())


if __name__ == "__main__":
    main()

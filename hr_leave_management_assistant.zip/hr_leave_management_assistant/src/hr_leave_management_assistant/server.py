"""
HR Leave Management MCP Server

This module implements a comprehensive MCP server for HR leave management,
providing tools, resources, and prompts for managing employee leave.

Business Problem Mapping:
- Tools: CRUD operations for employees, leave applications, balance management
- Resources: Employee data, leave policies, department summaries
- Prompts: Pre-built templates for common HR queries
"""

from mcp.server.fastmcp import FastMCP
from typing import List, Optional
import sqlite3
import os
from datetime import datetime, date, timedelta
import json
from collections import defaultdict

DATABASE_PATH = os.environ.get(
    "HR_DATABASE_PATH",
    os.path.join(os.path.dirname(os.path.abspath(__file__)), "hr_leave_management.db")
)


def init_database():
    """Initialize the SQLite database with required tables"""
    try:
        db_dir = os.path.dirname(DATABASE_PATH)
        if db_dir:
            os.makedirs(db_dir, exist_ok=True)
        
        conn = sqlite3.connect(DATABASE_PATH)
        cursor = conn.cursor()
        
        # Create employees table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS employees (
                employee_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                email TEXT UNIQUE,
                department TEXT,
                position TEXT,
                hire_date DATE,
                leave_balance INTEGER DEFAULT 20,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Create leave_records table
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS leave_records (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id TEXT NOT NULL,
                leave_date DATE NOT NULL,
                leave_type TEXT DEFAULT 'Annual',
                status TEXT DEFAULT 'Approved',
                applied_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees (employee_id)
            )
        ''')
        
        # Create leave_balance_history table for tracking balance changes
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS leave_balance_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                employee_id TEXT NOT NULL,
                old_balance INTEGER,
                new_balance INTEGER,
                change_reason TEXT,
                changed_by TEXT,
                changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (employee_id) REFERENCES employees (employee_id)
            )
        ''')
        
        # NEW: Create leave_policies table for policy management
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS leave_policies (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                policy_name TEXT NOT NULL UNIQUE,
                leave_type TEXT NOT NULL,
                max_days INTEGER NOT NULL,
                carry_forward_allowed BOOLEAN DEFAULT 0,
                max_carry_forward INTEGER DEFAULT 0,
                description TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # NEW: Create team_calendar table for team leave visibility
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS team_calendar (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                department TEXT NOT NULL,
                date DATE NOT NULL,
                employee_count_on_leave INTEGER DEFAULT 0,
                UNIQUE(department, date)
            )
        ''')
    
        conn.commit()
        conn.close()
        print(f"Database initialized successfully at: {DATABASE_PATH}")
        
    except Exception as e:
        print(f"Error initializing database: {e}")
        raise


# Initialize database on module load
init_database()

# Create MCP server with name and instructions
mcp = FastMCP(
    "HRLeaveManager",
    instructions="""
    HR Leave Management Assistant - Your AI-powered HR companion.
    
    I can help you with:
    - Managing employee records (add, remove, update)
    - Processing leave applications
    - Checking leave balances
    - Generating reports and analytics
    - Team calendar and availability planning
    - Leave policy management
    
    Use the available tools to perform HR operations efficiently.
    """
)


# ============================================================================
# Helper Functions
# ============================================================================

def get_db_connection():
    """Get database connection"""
    return sqlite3.connect(DATABASE_PATH)


def employee_exists(employee_id: str) -> bool:
    """Check if employee exists"""
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT 1 FROM employees WHERE employee_id = ?", (employee_id,))
    exists = cursor.fetchone() is not None
    conn.close()
    return exists


# ============================================================================
# MCP TOOLS - Core HR Operations
# ============================================================================

@mcp.tool()
def add_employee(
    employee_id: str, 
    name: str, 
    email: str, 
    department: str, 
    position: str, 
    initial_leave_balance: int = 20
) -> str:
    """
    Add a new employee to the HR system.
    
    Args:
        employee_id: Unique identifier for the employee (e.g., E001)
        name: Full name of the employee
        email: Work email address
        department: Department name (e.g., Engineering, HR, Sales)
        position: Job title/position
        initial_leave_balance: Starting leave balance (default: 20 days)
    
    Returns:
        Success or error message
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if employee_exists(employee_id):
            conn.close()
            return f"Employee with ID {employee_id} already exists."
        
        cursor.execute('''
            INSERT INTO employees (employee_id, name, email, department, position, leave_balance, hire_date)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (employee_id, name, email, department, position, initial_leave_balance, date.today().isoformat()))
        
        cursor.execute('''
            INSERT INTO leave_balance_history (employee_id, old_balance, new_balance, change_reason, changed_by)
            VALUES (?, ?, ?, ?, ?)
        ''', (employee_id, 0, initial_leave_balance, "Initial balance", "HR System"))
        
        conn.commit()
        conn.close()
        
        return f"✅ Employee {name} (ID: {employee_id}) added successfully with {initial_leave_balance} leave days."
    
    except sqlite3.IntegrityError as e:
        if "UNIQUE constraint failed" in str(e):
            return f"❌ Email {email} is already registered to another employee."
        return f"❌ Database error: {str(e)}"
    except Exception as e:
        return f"❌ Error adding employee: {str(e)}"


@mcp.tool()
def remove_employee(employee_id: str) -> str:
    """
    Remove an employee from the system.
    
    Args:
        employee_id: The unique identifier of the employee to remove
    
    Returns:
        Success or error message
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if not employee_exists(employee_id):
            conn.close()
            return f"❌ Employee with ID {employee_id} not found."
        
        cursor.execute("SELECT name FROM employees WHERE employee_id = ?", (employee_id,))
        result = cursor.fetchone()
        employee_name = result[0] if result else "Unknown"
        
        cursor.execute("DELETE FROM leave_records WHERE employee_id = ?", (employee_id,))
        cursor.execute("DELETE FROM leave_balance_history WHERE employee_id = ?", (employee_id,))
        cursor.execute("DELETE FROM employees WHERE employee_id = ?", (employee_id,))
        
        conn.commit()
        conn.close()
        
        return f"✅ Employee {employee_name} (ID: {employee_id}) and all related records removed successfully."
    
    except Exception as e:
        return f"❌ Error removing employee: {str(e)}"


@mcp.tool()
def update_leave_balance(employee_id: str, new_balance: int, reason: str = "HR adjustment") -> str:
    """
    Update an employee's leave balance.
    
    Args:
        employee_id: The unique identifier of the employee
        new_balance: The new leave balance to set
        reason: Reason for the adjustment
    
    Returns:
        Success or error message with old and new balance
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if not employee_exists(employee_id):
            conn.close()
            return f"❌ Employee with ID {employee_id} not found."
        
        cursor.execute("SELECT leave_balance, name FROM employees WHERE employee_id = ?", (employee_id,))
        result = cursor.fetchone()
        old_balance = result[0]
        employee_name = result[1]
        
        cursor.execute("UPDATE employees SET leave_balance = ? WHERE employee_id = ?", (new_balance, employee_id))
        
        cursor.execute('''
            INSERT INTO leave_balance_history (employee_id, old_balance, new_balance, change_reason, changed_by)
            VALUES (?, ?, ?, ?, ?)
        ''', (employee_id, old_balance, new_balance, reason, "HR Manager"))
        
        conn.commit()
        conn.close()
        
        return f"✅ Leave balance updated for {employee_name} (ID: {employee_id}): {old_balance} → {new_balance} days. Reason: {reason}"
    
    except Exception as e:
        return f"❌ Error updating leave balance: {str(e)}"


@mcp.tool()
def list_employees(department: Optional[str] = None) -> str:
    """
    List all employees or filter by department.
    
    Args:
        department: Optional department name to filter by
    
    Returns:
        Formatted table of employees
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if department:
            cursor.execute('''
                SELECT employee_id, name, email, department, position, leave_balance, hire_date
                FROM employees WHERE department = ? ORDER BY name
            ''', (department,))
        else:
            cursor.execute('''
                SELECT employee_id, name, email, department, position, leave_balance, hire_date
                FROM employees ORDER BY name
            ''')
        
        employees = cursor.fetchall()
        conn.close()
        
        if not employees:
            dept_msg = f" in {department}" if department else ""
            return f"No employees found{dept_msg}."
        
        result = "📋 Employee List:\n" + "="*80 + "\n"
        result += f"{'ID':<8} {'Name':<20} {'Email':<25} {'Dept':<12} {'Position':<15} {'Balance':<8}\n"
        result += "-"*80 + "\n"
        
        for emp in employees:
            result += f"{emp[0]:<8} {emp[1]:<20} {emp[2]:<25} {emp[3]:<12} {emp[4]:<15} {emp[5]:<8}\n"
        
        result += "-"*80 + "\n"
        result += f"Total: {len(employees)} employee(s)"
        
        return result
    
    except Exception as e:
        return f"❌ Error listing employees: {str(e)}"


@mcp.tool()
def get_employee_details(employee_id: str) -> str:
    """
    Get detailed information about a specific employee.
    
    Args:
        employee_id: The unique identifier of the employee
    
    Returns:
        Detailed employee profile including leave history
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if not employee_exists(employee_id):
            conn.close()
            return f"❌ Employee with ID {employee_id} not found."
        
        cursor.execute('''
            SELECT employee_id, name, email, department, position, leave_balance, hire_date, created_at
            FROM employees WHERE employee_id = ?
        ''', (employee_id,))
        
        emp = cursor.fetchone()
        
        cursor.execute('''
            SELECT COUNT(*) FROM leave_records WHERE employee_id = ?
        ''', (employee_id,))
        leave_count = cursor.fetchone()[0]
        
        cursor.execute('''
            SELECT change_reason, old_balance, new_balance, changed_at
            FROM leave_balance_history WHERE employee_id = ?
            ORDER BY changed_at DESC LIMIT 5
        ''', (employee_id,))
        balance_history = cursor.fetchall()
        
        conn.close()
        
        result = f"👤 Employee Details for {emp[1]} (ID: {emp[0]})\n"
        result += "="*50 + "\n"
        result += f"📧 Email: {emp[2]}\n"
        result += f"🏢 Department: {emp[3]}\n"
        result += f"💼 Position: {emp[4]}\n"
        result += f"📅 Hire Date: {emp[6]}\n"
        result += f"🌴 Current Leave Balance: {emp[5]} days\n"
        result += f"📊 Total Leaves Taken: {leave_count} days\n\n"
        
        if balance_history:
            result += "📜 Recent Balance Changes:\n"
            result += "-"*30 + "\n"
            for change in balance_history:
                result += f"  • {change[0]}: {change[1]} → {change[2]} ({change[3]})\n"
        
        return result
    
    except Exception as e:
        return f"❌ Error getting employee details: {str(e)}"


@mcp.tool()
def get_leave_balance(employee_id: str) -> str:
    """
    Check remaining leave days for an employee.
    
    Args:
        employee_id: The unique identifier of the employee
    
    Returns:
        Current leave balance information
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if not employee_exists(employee_id):
            conn.close()
            return f"❌ Employee with ID {employee_id} not found."
        
        cursor.execute('''
            SELECT name, leave_balance FROM employees WHERE employee_id = ?
        ''', (employee_id,))
        
        result = cursor.fetchone()
        conn.close()
        
        if result:
            return f"🌴 {result[0]} (ID: {employee_id}) has {result[1]} leave days remaining."
        return "❌ Employee ID not found."
    
    except Exception as e:
        return f"❌ Error checking leave balance: {str(e)}"


@mcp.tool()
def apply_leave(employee_id: str, leave_dates: List[str], leave_type: str = "Annual") -> str:
    """
    Apply leave for specific dates.
    
    Args:
        employee_id: The unique identifier of the employee
        leave_dates: List of dates in YYYY-MM-DD format
        leave_type: Type of leave (Annual, Sick, Personal, Holiday)
    
    Returns:
        Success or error message with updated balance
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if not employee_exists(employee_id):
            conn.close()
            return f"❌ Employee with ID {employee_id} not found."
        
        cursor.execute('''
            SELECT leave_balance, name, department FROM employees WHERE employee_id = ?
        ''', (employee_id,))
        
        result = cursor.fetchone()
        available_balance = result[0]
        employee_name = result[1]
        department = result[2]
        requested_days = len(leave_dates)
        
        if available_balance < requested_days:
            return f"❌ Insufficient leave balance for {employee_name}. Requested: {requested_days} days, Available: {available_balance} days."
        
        valid_dates = []
        for date_str in leave_dates:
            try:
                datetime.strptime(date_str, '%Y-%m-%d')
                
                cursor.execute('''
                    SELECT 1 FROM leave_records WHERE employee_id = ? AND leave_date = ?
                ''', (employee_id, date_str))
                
                if cursor.fetchone():
                    continue
                
                valid_dates.append(date_str)
            except ValueError:
                continue
        
        if not valid_dates:
            return "❌ No valid dates provided or all dates are already taken."
        
        for leave_date in valid_dates:
            cursor.execute('''
                INSERT INTO leave_records (employee_id, leave_date, leave_type)
                VALUES (?, ?, ?)
            ''', (employee_id, leave_date, leave_type))
            
            # Update team calendar
            cursor.execute('''
                INSERT INTO team_calendar (department, date, employee_count_on_leave)
                VALUES (?, ?, 1)
                ON CONFLICT(department, date) DO UPDATE SET
                employee_count_on_leave = employee_count_on_leave + 1
            ''', (department, leave_date))
        
        new_balance = available_balance - len(valid_dates)
        cursor.execute('''
            UPDATE employees SET leave_balance = ? WHERE employee_id = ?
        ''', (new_balance, employee_id))
        
        cursor.execute('''
            INSERT INTO leave_balance_history (employee_id, old_balance, new_balance, change_reason, changed_by)
            VALUES (?, ?, ?, ?, ?)
        ''', (employee_id, available_balance, new_balance, f"Applied {len(valid_dates)} days {leave_type} leave", employee_name))
        
        conn.commit()
        conn.close()
        
        applied_days = len(valid_dates)
        return f"✅ Leave applied successfully for {employee_name}.\n📅 Applied: {applied_days} day(s) ({leave_type})\n🌴 Remaining balance: {new_balance} days"
    
    except Exception as e:
        return f"❌ Error applying leave: {str(e)}"


@mcp.tool()
def cancel_leave(employee_id: str, leave_dates: List[str]) -> str:
    """
    Cancel previously applied leave for specific dates.
    
    Args:
        employee_id: The unique identifier of the employee
        leave_dates: List of dates to cancel in YYYY-MM-DD format
    
    Returns:
        Success or error message with updated balance
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if not employee_exists(employee_id):
            conn.close()
            return f"❌ Employee with ID {employee_id} not found."
        
        cursor.execute('''
            SELECT leave_balance, name, department FROM employees WHERE employee_id = ?
        ''', (employee_id,))
        
        result = cursor.fetchone()
        current_balance = result[0]
        employee_name = result[1]
        department = result[2]
        
        cancelled_count = 0
        for date_str in leave_dates:
            cursor.execute('''
                DELETE FROM leave_records WHERE employee_id = ? AND leave_date = ?
            ''', (employee_id, date_str))
            
            if cursor.rowcount > 0:
                cancelled_count += 1
                # Update team calendar
                cursor.execute('''
                    UPDATE team_calendar SET employee_count_on_leave = employee_count_on_leave - 1
                    WHERE department = ? AND date = ?
                ''', (department, date_str))
        
        if cancelled_count == 0:
            conn.close()
            return f"❌ No matching leave records found for the specified dates."
        
        new_balance = current_balance + cancelled_count
        cursor.execute('''
            UPDATE employees SET leave_balance = ? WHERE employee_id = ?
        ''', (new_balance, employee_id))
        
        cursor.execute('''
            INSERT INTO leave_balance_history (employee_id, old_balance, new_balance, change_reason, changed_by)
            VALUES (?, ?, ?, ?, ?)
        ''', (employee_id, current_balance, new_balance, f"Cancelled {cancelled_count} days leave", employee_name))
        
        conn.commit()
        conn.close()
        
        return f"✅ Leave cancelled successfully for {employee_name}.\n📅 Cancelled: {cancelled_count} day(s)\n🌴 New balance: {new_balance} days"
    
    except Exception as e:
        return f"❌ Error cancelling leave: {str(e)}"


@mcp.tool()
def get_leave_history(employee_id: str) -> str:
    """
    Get list of leave dates for an employee.
    
    Args:
        employee_id: The unique identifier of the employee
    
    Returns:
        Formatted leave history
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if not employee_exists(employee_id):
            conn.close()
            return f"❌ Employee with ID {employee_id} not found."
        
        cursor.execute("SELECT name FROM employees WHERE employee_id = ?", (employee_id,))
        employee_name = cursor.fetchone()[0]
        
        cursor.execute('''
            SELECT leave_date, leave_type, status, applied_at
            FROM leave_records WHERE employee_id = ?
            ORDER BY leave_date DESC
        ''', (employee_id,))
        
        leave_records = cursor.fetchall()
        conn.close()
        
        if not leave_records:
            return f"📋 No leave records found for {employee_name} (ID: {employee_id})."
        
        result = f"📋 Leave History for {employee_name} (ID: {employee_id})\n"
        result += "="*60 + "\n"
        result += f"{'Date':<12} {'Type':<10} {'Status':<10} {'Applied At':<20}\n"
        result += "-"*60 + "\n"
        
        for record in leave_records:
            result += f"{record[0]:<12} {record[1]:<10} {record[2]:<10} {record[3]:<20}\n"
        
        result += "-"*60 + "\n"
        result += f"Total: {len(leave_records)} leave record(s)"
        
        return result
    
    except Exception as e:
        return f"❌ Error getting leave history: {str(e)}"


# ============================================================================
# MCP TOOLS - Analytics & Reporting (NEW CAPABILITY)
# ============================================================================

@mcp.tool()
def get_department_summary(department: Optional[str] = None) -> str:
    """
    Get leave summary by department or overall organization.
    
    Args:
        department: Optional department name to filter by
    
    Returns:
        Department-wise leave statistics
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        if department:
            cursor.execute('''
                SELECT COUNT(*) as emp_count, 
                       SUM(leave_balance) as total_balance,
                       AVG(leave_balance) as avg_balance
                FROM employees WHERE department = ?
            ''', (department,))
            
            result = cursor.fetchone()
            if not result or result[0] == 0:
                return f"❌ No employees found in {department} department."
            
            emp_count, total_balance, avg_balance = result
            
            summary = f"📊 Department Summary for {department}\n"
            summary += "="*40 + "\n"
            summary += f"👥 Total Employees: {emp_count}\n"
            summary += f"🌴 Total Leave Balance: {total_balance} days\n"
            summary += f"📈 Average Leave Balance: {avg_balance:.1f} days\n"
            
        else:
            cursor.execute('''
                SELECT department, COUNT(*) as emp_count, 
                       SUM(leave_balance) as total_balance,
                       AVG(leave_balance) as avg_balance
                FROM employees 
                GROUP BY department
                ORDER BY department
            ''')
            
            dept_summaries = cursor.fetchall()
            
            if not dept_summaries:
                return "❌ No employees found in the system."
            
            summary = "📊 Overall Leave Summary by Department\n"
            summary += "="*60 + "\n"
            summary += f"{'Department':<15} {'Employees':<10} {'Total Balance':<15} {'Avg Balance':<12}\n"
            summary += "-"*60 + "\n"
            
            total_employees = 0
            total_balance = 0
            
            for dept_data in dept_summaries:
                dept, emp_count, dept_total, dept_avg = dept_data
                summary += f"{dept:<15} {emp_count:<10} {dept_total:<15} {dept_avg:<12.1f}\n"
                total_employees += emp_count
                total_balance += dept_total
            
            summary += "-"*60 + "\n"
            overall_avg = total_balance / total_employees if total_employees > 0 else 0
            summary += f"{'TOTAL':<15} {total_employees:<10} {total_balance:<15} {overall_avg:<12.1f}\n"
        
        conn.close()
        return summary
    
    except Exception as e:
        return f"❌ Error generating summary: {str(e)}"


@mcp.tool()
def get_leave_analytics(year: Optional[int] = None, month: Optional[int] = None) -> str:
    """
    NEW CAPABILITY: Get comprehensive leave analytics and trends.
    
    Provides insights on:
    - Leave utilization rates
    - Peak leave periods
    - Department-wise trends
    - Leave type distribution
    
    Args:
        year: Optional year to filter (default: current year)
        month: Optional month to filter (1-12)
    
    Returns:
        Comprehensive analytics report
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        current_year = year or datetime.now().year
        
        # Build date filter
        if month:
            date_filter = f"strftime('%Y-%m', leave_date) = '{current_year:04d}-{month:02d}'"
            period_label = f"{datetime(current_year, month, 1).strftime('%B %Y')}"
        else:
            date_filter = f"strftime('%Y', leave_date) = '{current_year}'"
            period_label = f"Year {current_year}"
        
        report = f"📈 Leave Analytics Report - {period_label}\n"
        report += "="*60 + "\n\n"
        
        # 1. Overall Statistics
        cursor.execute(f'''
            SELECT COUNT(*) as total_leaves,
                   COUNT(DISTINCT employee_id) as unique_employees
            FROM leave_records
            WHERE {date_filter}
        ''')
        overall = cursor.fetchone()
        
        cursor.execute("SELECT COUNT(*) FROM employees")
        total_employees = cursor.fetchone()[0]
        
        report += "📊 Overall Statistics\n"
        report += "-"*30 + "\n"
        report += f"  Total Leave Days Taken: {overall[0]}\n"
        report += f"  Employees Who Took Leave: {overall[1]}\n"
        report += f"  Total Employees: {total_employees}\n"
        if total_employees > 0:
            utilization = (overall[1] / total_employees) * 100
            report += f"  Leave Utilization Rate: {utilization:.1f}%\n"
        report += "\n"
        
        # 2. Leave Type Distribution
        cursor.execute(f'''
            SELECT leave_type, COUNT(*) as count
            FROM leave_records
            WHERE {date_filter}
            GROUP BY leave_type
            ORDER BY count DESC
        ''')
        leave_types = cursor.fetchall()
        
        if leave_types:
            report += "🏷️ Leave Type Distribution\n"
            report += "-"*30 + "\n"
            for lt in leave_types:
                percentage = (lt[1] / overall[0] * 100) if overall[0] > 0 else 0
                bar = "█" * int(percentage / 5)
                report += f"  {lt[0]:<12}: {lt[1]:>3} days ({percentage:>5.1f}%) {bar}\n"
            report += "\n"
        
        # 3. Department-wise Leave Usage
        cursor.execute(f'''
            SELECT e.department, COUNT(lr.id) as leave_count
            FROM leave_records lr
            JOIN employees e ON lr.employee_id = e.employee_id
            WHERE {date_filter}
            GROUP BY e.department
            ORDER BY leave_count DESC
        ''')
        dept_usage = cursor.fetchall()
        
        if dept_usage:
            report += "🏢 Department-wise Leave Usage\n"
            report += "-"*30 + "\n"
            for dept in dept_usage:
                report += f"  {dept[0]:<15}: {dept[1]} days\n"
            report += "\n"
        
        # 4. Monthly Trend (if viewing yearly data)
        if not month:
            cursor.execute(f'''
                SELECT strftime('%m', leave_date) as month, COUNT(*) as count
                FROM leave_records
                WHERE strftime('%Y', leave_date) = '{current_year}'
                GROUP BY month
                ORDER BY month
            ''')
            monthly_trend = cursor.fetchall()
            
            if monthly_trend:
                report += "📅 Monthly Trend\n"
                report += "-"*30 + "\n"
                months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                         'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
                max_count = max(m[1] for m in monthly_trend) if monthly_trend else 1
                for m in monthly_trend:
                    month_idx = int(m[0]) - 1
                    bar_len = int((m[1] / max_count) * 20)
                    bar = "▓" * bar_len
                    report += f"  {months[month_idx]}: {m[1]:>3} {bar}\n"
                report += "\n"
        
        # 5. Top Leave Takers
        cursor.execute(f'''
            SELECT e.name, e.employee_id, COUNT(lr.id) as leave_count
            FROM leave_records lr
            JOIN employees e ON lr.employee_id = e.employee_id
            WHERE {date_filter}
            GROUP BY e.employee_id
            ORDER BY leave_count DESC
            LIMIT 5
        ''')
        top_takers = cursor.fetchall()
        
        if top_takers:
            report += "🏆 Top Leave Takers\n"
            report += "-"*30 + "\n"
            for i, emp in enumerate(top_takers, 1):
                report += f"  {i}. {emp[0]} ({emp[1]}): {emp[2]} days\n"
        
        conn.close()
        return report
    
    except Exception as e:
        return f"❌ Error generating analytics: {str(e)}"


@mcp.tool()
def get_team_availability(department: str, start_date: str, end_date: str) -> str:
    """
    NEW CAPABILITY: Check team availability for a date range.
    
    Helps managers plan projects by showing who's available.
    
    Args:
        department: Department name to check
        start_date: Start date in YYYY-MM-DD format
        end_date: End date in YYYY-MM-DD format
    
    Returns:
        Team availability calendar view
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get all employees in department
        cursor.execute('''
            SELECT employee_id, name FROM employees WHERE department = ?
        ''', (department,))
        employees = cursor.fetchall()
        
        if not employees:
            conn.close()
            return f"❌ No employees found in {department} department."
        
        # Get leave records for the date range
        cursor.execute('''
            SELECT lr.employee_id, lr.leave_date, lr.leave_type
            FROM leave_records lr
            JOIN employees e ON lr.employee_id = e.employee_id
            WHERE e.department = ? AND lr.leave_date BETWEEN ? AND ?
            ORDER BY lr.leave_date
        ''', (department, start_date, end_date))
        
        leave_records = cursor.fetchall()
        conn.close()
        
        # Build leave map
        leave_map = defaultdict(list)
        for record in leave_records:
            leave_map[record[1]].append((record[0], record[2]))
        
        result = f"📅 Team Availability - {department}\n"
        result += f"Period: {start_date} to {end_date}\n"
        result += "="*60 + "\n\n"
        
        result += f"👥 Team Size: {len(employees)} employees\n\n"
        
        # Parse dates
        start = datetime.strptime(start_date, '%Y-%m-%d')
        end = datetime.strptime(end_date, '%Y-%m-%d')
        
        result += "📋 Leave Schedule:\n"
        result += "-"*40 + "\n"
        
        current = start
        has_leaves = False
        while current <= end:
            date_str = current.strftime('%Y-%m-%d')
            if date_str in leave_map:
                has_leaves = True
                day_name = current.strftime('%a')
                result += f"\n{date_str} ({day_name}):\n"
                for emp_id, leave_type in leave_map[date_str]:
                    emp_name = next((e[1] for e in employees if e[0] == emp_id), emp_id)
                    result += f"  🚫 {emp_name} - {leave_type}\n"
                available = len(employees) - len(leave_map[date_str])
                result += f"  ✅ Available: {available}/{len(employees)}\n"
            current += timedelta(days=1)
        
        if not has_leaves:
            result += "✅ No leaves scheduled - Full team available!\n"
        
        return result
    
    except Exception as e:
        return f"❌ Error checking availability: {str(e)}"


@mcp.tool()
def get_low_balance_alerts(threshold: int = 5) -> str:
    """
    NEW CAPABILITY: Get alerts for employees with low leave balance.
    
    Helps HR proactively manage leave balances.
    
    Args:
        threshold: Balance threshold for alerts (default: 5 days)
    
    Returns:
        List of employees with low leave balance
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT employee_id, name, department, leave_balance
            FROM employees
            WHERE leave_balance <= ?
            ORDER BY leave_balance ASC, name
        ''', (threshold,))
        
        low_balance = cursor.fetchall()
        conn.close()
        
        if not low_balance:
            return f"✅ No employees with leave balance at or below {threshold} days."
        
        result = f"⚠️ Low Leave Balance Alert (≤{threshold} days)\n"
        result += "="*60 + "\n"
        result += f"{'ID':<8} {'Name':<20} {'Department':<15} {'Balance':<8}\n"
        result += "-"*60 + "\n"
        
        critical = []
        warning = []
        
        for emp in low_balance:
            if emp[3] <= 2:
                critical.append(emp)
                status = "🔴"
            else:
                warning.append(emp)
                status = "🟡"
            result += f"{status} {emp[0]:<6} {emp[1]:<20} {emp[2]:<15} {emp[3]:<8}\n"
        
        result += "-"*60 + "\n"
        result += f"🔴 Critical (≤2 days): {len(critical)} employees\n"
        result += f"🟡 Warning (≤{threshold} days): {len(warning)} employees\n"
        
        return result
    
    except Exception as e:
        return f"❌ Error getting alerts: {str(e)}"


@mcp.tool()
def get_recent_leave_activity(days: int = 30) -> str:
    """
    Get recent leave applications across the organization.
    
    Args:
        days: Number of days to look back (default: 30)
    
    Returns:
        Recent leave activity report
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT e.name, e.employee_id, lr.leave_date, lr.leave_type, lr.applied_at
            FROM leave_records lr
            JOIN employees e ON lr.employee_id = e.employee_id
            WHERE lr.applied_at >= datetime('now', '-' || ? || ' days')
            ORDER BY lr.applied_at DESC
        ''', (days,))
        
        recent_leaves = cursor.fetchall()
        conn.close()
        
        if not recent_leaves:
            return f"📋 No leave applications found in the last {days} days."
        
        result = f"📋 Recent Leave Activity (Last {days} days)\n"
        result += "="*70 + "\n"
        result += f"{'Employee':<20} {'ID':<8} {'Leave Date':<12} {'Type':<10} {'Applied At':<20}\n"
        result += "-"*70 + "\n"
        
        for leave in recent_leaves:
            result += f"{leave[0]:<20} {leave[1]:<8} {leave[2]:<12} {leave[3]:<10} {leave[4]:<20}\n"
        
        result += "-"*70 + "\n"
        result += f"Total: {len(recent_leaves)} leave record(s)"
        
        return result
    
    except Exception as e:
        return f"❌ Error getting recent activity: {str(e)}"


# ============================================================================
# MCP RESOURCES - Static Data Access
# ============================================================================

@mcp.resource("hr://policies/leave")
def get_leave_policies() -> str:
    """
    Resource: Company leave policies.
    
    Returns the official leave policy document.
    """
    return """
    📜 COMPANY LEAVE POLICIES
    ========================
    
    1. ANNUAL LEAVE
       - Entitlement: 20 days per year
       - Carry forward: Up to 5 days to next year
       - Minimum notice: 3 days for planned leave
    
    2. SICK LEAVE
       - Entitlement: 10 days per year
       - Medical certificate required for >2 consecutive days
       - No carry forward
    
    3. PERSONAL LEAVE
       - Entitlement: 3 days per year
       - For personal emergencies
       - No carry forward
    
    4. PUBLIC HOLIDAYS
       - As per company calendar
       - Compensatory off if working on holiday
    
    5. SPECIAL LEAVE
       - Maternity: 26 weeks
       - Paternity: 2 weeks
       - Bereavement: 5 days
    
    For questions, contact HR at hr@company.com
    """


@mcp.resource("hr://employees/directory")
def get_employee_directory() -> str:
    """
    Resource: Employee directory listing.
    
    Returns a formatted employee directory.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT employee_id, name, email, department, position
            FROM employees ORDER BY department, name
        ''')
        
        employees = cursor.fetchall()
        conn.close()
        
        if not employees:
            return "No employees in directory."
        
        result = "📒 EMPLOYEE DIRECTORY\n"
        result += "="*70 + "\n\n"
        
        current_dept = None
        for emp in employees:
            if emp[3] != current_dept:
                current_dept = emp[3]
                result += f"\n🏢 {current_dept}\n"
                result += "-"*40 + "\n"
            result += f"  {emp[0]} | {emp[1]}\n"
            result += f"       {emp[4]} | {emp[2]}\n"
        
        return result
    
    except Exception as e:
        return f"Error loading directory: {str(e)}"


@mcp.resource("hr://reports/summary")
def get_summary_report() -> str:
    """
    Resource: Quick summary report for dashboard.
    """
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Get counts
        cursor.execute("SELECT COUNT(*) FROM employees")
        emp_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT COUNT(*) FROM leave_records")
        leave_count = cursor.fetchone()[0]
        
        cursor.execute("SELECT SUM(leave_balance) FROM employees")
        total_balance = cursor.fetchone()[0] or 0
        
        cursor.execute("SELECT COUNT(DISTINCT department) FROM employees")
        dept_count = cursor.fetchone()[0]
        
        conn.close()
        
        return f"""
        📊 HR DASHBOARD SUMMARY
        ======================
        
        👥 Total Employees: {emp_count}
        🏢 Departments: {dept_count}
        📅 Total Leave Records: {leave_count}
        🌴 Total Leave Balance: {total_balance} days
        📈 Avg Balance/Employee: {total_balance/emp_count:.1f} days
        
        Last Updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        """
    
    except Exception as e:
        return f"Error generating summary: {str(e)}"


# ============================================================================
# MCP PROMPTS - Pre-built Query Templates
# ============================================================================

@mcp.prompt()
def onboard_employee() -> str:
    """
    Prompt template for onboarding a new employee.
    """
    return """
    I need to onboard a new employee. Please help me with the following:
    
    1. Add the employee to the system with these details:
       - Employee ID: [EMPLOYEE_ID]
       - Name: [FULL_NAME]
       - Email: [EMAIL]
       - Department: [DEPARTMENT]
       - Position: [POSITION]
       - Initial Leave Balance: [BALANCE] days
    
    2. Verify the employee was added successfully
    3. Show me the employee's details
    
    Please proceed with the onboarding.
    """


@mcp.prompt()
def process_leave_request() -> str:
    """
    Prompt template for processing a leave request.
    """
    return """
    I need to process a leave request:
    
    1. First, check the leave balance for employee [EMPLOYEE_ID]
    2. If sufficient balance, apply leave for dates: [DATE_LIST]
       Leave type: [LEAVE_TYPE]
    3. Show the updated leave history
    
    Please process this request.
    """


@mcp.prompt()
def generate_department_report() -> str:
    """
    Prompt template for generating department reports.
    """
    return """
    Generate a comprehensive report for [DEPARTMENT] department:
    
    1. List all employees in the department
    2. Show department leave summary
    3. Get leave analytics for the current year
    4. Identify any employees with low leave balance
    
    Please compile this report.
    """


@mcp.prompt()
def monthly_hr_review() -> str:
    """
    Prompt template for monthly HR review.
    """
    return """
    Conduct a monthly HR review:
    
    1. Get overall department summary
    2. Show recent leave activity (last 30 days)
    3. Generate leave analytics for this month
    4. List employees with low leave balance (threshold: 5 days)
    
    Please compile the monthly review.
    """


# ============================================================================
# Sample Data Initialization
# ============================================================================

def init_sample_data():
    """Initialize database with sample data for demo purposes"""
    conn = get_db_connection()
    cursor = conn.cursor()
    
    cursor.execute("SELECT COUNT(*) FROM employees")
    if cursor.fetchone()[0] > 0:
        conn.close()
        return
    
    sample_employees = [
        ("E001", "John Smith", "john.smith@company.com", "Engineering", "Senior Developer", 18),
        ("E002", "Sarah Johnson", "sarah.johnson@company.com", "HR", "HR Manager", 22),
        ("E003", "Mike Wilson", "mike.wilson@company.com", "Marketing", "Marketing Specialist", 20),
        ("E004", "Emily Brown", "emily.brown@company.com", "Engineering", "Junior Developer", 20),
        ("E005", "David Lee", "david.lee@company.com", "Sales", "Sales Manager", 15),
        ("E006", "Lisa Chen", "lisa.chen@company.com", "Engineering", "Tech Lead", 12),
        ("E007", "Robert Taylor", "robert.taylor@company.com", "Finance", "Financial Analyst", 18),
        ("E008", "Jennifer Martinez", "jennifer.martinez@company.com", "HR", "Recruiter", 3),
    ]
    
    for emp_data in sample_employees:
        cursor.execute('''
            INSERT INTO employees (employee_id, name, email, department, position, leave_balance, hire_date)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ''', (*emp_data, date.today().isoformat()))
        
        cursor.execute('''
            INSERT INTO leave_balance_history (employee_id, old_balance, new_balance, change_reason, changed_by)
            VALUES (?, ?, ?, ?, ?)
        ''', (emp_data[0], 0, emp_data[5], "Initial balance", "System"))
    
    sample_leaves = [
        ("E001", "2024-12-25", "Holiday"),
        ("E001", "2024-12-26", "Holiday"),
        ("E002", "2024-12-30", "Personal"),
        ("E005", "2024-12-31", "Personal"),
        ("E003", "2024-12-20", "Annual"),
        ("E006", "2024-12-23", "Sick"),
        ("E006", "2024-12-24", "Sick"),
    ]
    
    for leave_data in sample_leaves:
        cursor.execute('''
            INSERT INTO leave_records (employee_id, leave_date, leave_type)
            VALUES (?, ?, ?)
        ''', leave_data)
    
    # Initialize leave policies
    policies = [
        ("Annual Leave", "Annual", 20, 1, 5, "Standard annual leave entitlement"),
        ("Sick Leave", "Sick", 10, 0, 0, "Medical leave with certificate"),
        ("Personal Leave", "Personal", 3, 0, 0, "Personal emergency leave"),
    ]
    
    for policy in policies:
        cursor.execute('''
            INSERT OR IGNORE INTO leave_policies 
            (policy_name, leave_type, max_days, carry_forward_allowed, max_carry_forward, description)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', policy)
    
    conn.commit()
    conn.close()
    print("Sample data initialized successfully.")


# Initialize sample data
init_sample_data()


def main():
    """Main entry point for the MCP server"""
    print("🚀 Starting HR Leave Management MCP Server...")
    print(f"📁 Database: {DATABASE_PATH}")
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()

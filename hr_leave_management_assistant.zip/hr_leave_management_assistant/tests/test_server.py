"""
Test suite for HR Leave Management MCP Server

Run with: uv run pytest tests/ -v
"""

import pytest
import sqlite3
import os
import sys
import tempfile

# Add src to path for imports
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

# Set test database path before importing server
TEST_DB = tempfile.mktemp(suffix='.db')
os.environ['HR_DATABASE_PATH'] = TEST_DB


class TestHRLeaveManagement:
    """Test class for HR Leave Management functionality"""
    
    @pytest.fixture(autouse=True)
    def setup_teardown(self):
        """Setup and teardown for each test"""
        # Setup: Import and initialize
        from hr_leave_management_assistant import server
        
        # Re-initialize database for clean state
        if os.path.exists(TEST_DB):
            os.remove(TEST_DB)
        server.init_database()
        
        yield server
        
        # Teardown: Clean up
        if os.path.exists(TEST_DB):
            os.remove(TEST_DB)
    
    def test_add_employee(self, setup_teardown):
        """Test adding a new employee"""
        server = setup_teardown
        
        result = server.add_employee(
            employee_id="T001",
            name="Test User",
            email="test@company.com",
            department="Testing",
            position="QA Engineer",
            initial_leave_balance=20
        )
        
        assert "successfully" in result.lower() or "✅" in result
        assert "T001" in result
    
    def test_add_duplicate_employee(self, setup_teardown):
        """Test adding duplicate employee fails"""
        server = setup_teardown
        
        # Add first time
        server.add_employee(
            employee_id="T001",
            name="Test User",
            email="test@company.com",
            department="Testing",
            position="QA Engineer"
        )
        
        # Try to add again
        result = server.add_employee(
            employee_id="T001",
            name="Test User 2",
            email="test2@company.com",
            department="Testing",
            position="Developer"
        )
        
        assert "already exists" in result.lower()
    
    def test_get_leave_balance(self, setup_teardown):
        """Test checking leave balance"""
        server = setup_teardown
        
        # Add employee first
        server.add_employee(
            employee_id="T002",
            name="Balance Test",
            email="balance@company.com",
            department="Testing",
            position="Tester",
            initial_leave_balance=15
        )
        
        result = server.get_leave_balance("T002")
        
        assert "15" in result
        assert "Balance Test" in result
    
    def test_apply_leave(self, setup_teardown):
        """Test applying for leave"""
        server = setup_teardown
        
        # Add employee
        server.add_employee(
            employee_id="T003",
            name="Leave Test",
            email="leave@company.com",
            department="Testing",
            position="Tester",
            initial_leave_balance=20
        )
        
        # Apply leave
        result = server.apply_leave(
            employee_id="T003",
            leave_dates=["2025-01-15", "2025-01-16"],
            leave_type="Annual"
        )
        
        assert "successfully" in result.lower() or "✅" in result
        assert "18" in result  # 20 - 2 = 18
    
    def test_apply_leave_insufficient_balance(self, setup_teardown):
        """Test applying leave with insufficient balance"""
        server = setup_teardown
        
        # Add employee with low balance
        server.add_employee(
            employee_id="T004",
            name="Low Balance",
            email="low@company.com",
            department="Testing",
            position="Tester",
            initial_leave_balance=1
        )
        
        # Try to apply more leave than available
        result = server.apply_leave(
            employee_id="T004",
            leave_dates=["2025-01-15", "2025-01-16", "2025-01-17"],
            leave_type="Annual"
        )
        
        assert "insufficient" in result.lower() or "❌" in result
    
    def test_cancel_leave(self, setup_teardown):
        """Test cancelling leave"""
        server = setup_teardown
        
        # Add employee and apply leave
        server.add_employee(
            employee_id="T005",
            name="Cancel Test",
            email="cancel@company.com",
            department="Testing",
            position="Tester",
            initial_leave_balance=20
        )
        
        server.apply_leave(
            employee_id="T005",
            leave_dates=["2025-02-01"],
            leave_type="Annual"
        )
        
        # Cancel leave
        result = server.cancel_leave(
            employee_id="T005",
            leave_dates=["2025-02-01"]
        )
        
        assert "cancelled" in result.lower() or "✅" in result
        assert "20" in result  # Balance restored
    
    def test_list_employees(self, setup_teardown):
        """Test listing employees"""
        server = setup_teardown
        
        # Add employees
        server.add_employee("T006", "User One", "one@company.com", "Engineering", "Dev", 20)
        server.add_employee("T007", "User Two", "two@company.com", "Engineering", "Dev", 20)
        
        result = server.list_employees(department="Engineering")
        
        assert "User One" in result
        assert "User Two" in result
    
    def test_get_department_summary(self, setup_teardown):
        """Test department summary"""
        server = setup_teardown
        
        # Add employees
        server.add_employee("T008", "Eng One", "eng1@company.com", "Engineering", "Dev", 20)
        server.add_employee("T009", "Eng Two", "eng2@company.com", "Engineering", "Dev", 15)
        
        result = server.get_department_summary("Engineering")
        
        assert "Engineering" in result
        assert "2" in result  # 2 employees
    
    def test_get_leave_analytics(self, setup_teardown):
        """Test leave analytics"""
        server = setup_teardown
        
        # Add employee and apply leave
        server.add_employee("T010", "Analytics Test", "analytics@company.com", "Testing", "Tester", 20)
        server.apply_leave("T010", ["2025-01-10"], "Annual")
        
        result = server.get_leave_analytics(year=2025)
        
        assert "Analytics" in result or "analytics" in result.lower()
    
    def test_get_low_balance_alerts(self, setup_teardown):
        """Test low balance alerts"""
        server = setup_teardown
        
        # Add employee with low balance
        server.add_employee("T011", "Low Alert", "lowalert@company.com", "Testing", "Tester", 3)
        
        result = server.get_low_balance_alerts(threshold=5)
        
        assert "Low Alert" in result
        assert "3" in result
    
    def test_remove_employee(self, setup_teardown):
        """Test removing employee"""
        server = setup_teardown
        
        # Add employee
        server.add_employee("T012", "Remove Test", "remove@company.com", "Testing", "Tester", 20)
        
        # Remove employee
        result = server.remove_employee("T012")
        
        assert "removed" in result.lower() or "✅" in result
        
        # Verify removed
        balance_result = server.get_leave_balance("T012")
        assert "not found" in balance_result.lower() or "❌" in balance_result
    
    def test_update_leave_balance(self, setup_teardown):
        """Test updating leave balance"""
        server = setup_teardown
        
        # Add employee
        server.add_employee("T013", "Update Test", "update@company.com", "Testing", "Tester", 20)
        
        # Update balance
        result = server.update_leave_balance("T013", 25, "Annual bonus")
        
        assert "25" in result
        assert "Annual bonus" in result or "updated" in result.lower()
    
    def test_employee_not_found(self, setup_teardown):
        """Test operations on non-existent employee"""
        server = setup_teardown
        
        result = server.get_leave_balance("NONEXISTENT")
        
        assert "not found" in result.lower() or "❌" in result


if __name__ == "__main__":
    pytest.main([__file__, "-v"])

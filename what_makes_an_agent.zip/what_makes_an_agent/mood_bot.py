"""
Mood Bot Agent

A teaching implementation of a simple AI agent loop:
Observe -> Think -> Act -> Observe.

The core implementation is deliberately plain Python so the architecture is visible:
- Perception: classify the user's mood from text.
- Memory: remember recent turns.
- Policy/controller: choose the next action.
- Tools/actions: call small Python functions that produce useful responses.

This is an educational example, not a mental-health service.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Callable, Dict, List, Optional, Tuple


SUPPORTED_MOODS = (
    "anxious",
    "sad",
    "frustrated",
    "tired",
    "confident",
    "confused",
    "neutral",
    "urgent_support",
)

MOOD_KEYWORDS: Dict[str, Tuple[str, ...]] = {
    "urgent_support": (
        "kill myself",
        "suicide",
        "self harm",
        "self-harm",
        "end my life",
        "hurt myself",
        "can't go on",
    ),
    "anxious": (
        "anxious",
        "anxiety",
        "panic",
        "worried",
        "nervous",
        "scared",
        "afraid",
        "overwhelmed",
        "stress",
        "stressed",
        "interview",
        "exam",
    ),
    "sad": (
        "sad",
        "down",
        "depressed",
        "lonely",
        "hopeless",
        "crying",
        "empty",
        "worthless",
    ),
    "frustrated": (
        "angry",
        "frustrated",
        "annoyed",
        "irritated",
        "stuck",
        "blocked",
        "fed up",
        "hate",
        "bug",
        "error",
    ),
    "tired": (
        "tired",
        "exhausted",
        "sleepy",
        "drained",
        "burnout",
        "burned out",
        "no energy",
        "fatigue",
    ),
    "confident": (
        "confident",
        "ready",
        "excited",
        "motivated",
        "great",
        "good",
        "proud",
        "calm",
    ),
    "confused": (
        "confused",
        "lost",
        "unclear",
        "don't understand",
        "do not understand",
        "not sure",
        "uncertain",
    ),
}


@dataclass
class MoodSignal:
    """Structured output from the perception step.

    Params:
        mood: The detected mood label.
        confidence: A simple confidence score from 0.0 to 1.0.
        matched_keywords: Keywords that triggered the classification.
        raw_text: Original user input.
    Returns:
        MoodSignal dataclass instance.
    """

    mood: str
    confidence: float
    matched_keywords: List[str]
    raw_text: str


@dataclass
class AgentTrace:
    """Human-readable trace of one agent-loop turn.

    Params:
        observe: What the agent received.
        think: How the controller interpreted the situation.
        act: Which tool/action was selected.
        observe_result: What came back from the action.
    Returns:
        AgentTrace dataclass instance.
    """

    observe: str
    think: str
    act: str
    observe_result: str


@dataclass
class AgentResponse:
    """Response returned by the agent after one turn.

    Params:
        message: User-facing message.
        mood_signal: Structured mood signal from perception.
        selected_tool: Name of the tool/action selected by policy.
        trace: Trace of the Observe -> Think -> Act -> Observe loop.
        memory_snapshot: Compact memory state after the turn.
    Returns:
        AgentResponse dataclass instance.
    """

    message: str
    mood_signal: MoodSignal
    selected_tool: str
    trace: AgentTrace
    memory_snapshot: Dict[str, object]


@dataclass
class MoodMemory:
    """Short-term memory for a teaching mood-bot agent.

    Params:
        max_turns: Maximum number of recent turns to remember.
        history: Stored history of user text, mood signal, and selected tool.
    Returns:
        MoodMemory instance with update and summary helpers.
    """

    max_turns: int = 6
    history: List[Dict[str, object]] = field(default_factory=list)

    def add_turn(self, user_text: str, mood_signal: MoodSignal, selected_tool: str) -> None:
        """Store one recent turn and trim old turns.

        Params:
            user_text: Raw user message.
            mood_signal: Mood classification result.
            selected_tool: Tool/action chosen by the controller.
        Returns:
            None.
        """

        self.history.append(
            {
                "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                "user_text": user_text,
                "mood": mood_signal.mood,
                "confidence": mood_signal.confidence,
                "selected_tool": selected_tool,
                "matched_keywords": list(mood_signal.matched_keywords),
            }
        )
        if len(self.history) > self.max_turns:
            self.history = self.history[-self.max_turns :]

    def recent_moods(self, limit: int = 3) -> List[str]:
        """Return recent mood labels.

        Params:
            limit: Maximum number of recent labels to return.
        Returns:
            List of mood labels, newest last.
        """

        return [str(item["mood"]) for item in self.history[-limit:]]

    def repeated_mood_count(self, mood: str, limit: int = 3) -> int:
        """Count how often a mood appears in the recent window.

        Params:
            mood: Mood label to count.
            limit: Recent-turn window size.
        Returns:
            Count of matching recent moods.
        """

        return sum(1 for recent_mood in self.recent_moods(limit=limit) if recent_mood == mood)

    def snapshot(self) -> Dict[str, object]:
        """Return a compact memory summary for printing/debugging.

        Params:
            None.
        Returns:
            Dictionary with turn count, recent moods, and last tool.
        """

        return {
            "turn_count": len(self.history),
            "recent_moods": self.recent_moods(limit=4),
            "last_tool": self.history[-1]["selected_tool"] if self.history else None,
        }


def normalize_text(text: str) -> str:
    """Normalize user text before keyword matching.

    Params:
        text: Raw text from the user.
    Returns:
        Lowercased, whitespace-normalized text.
    """

    return " ".join(text.lower().strip().split())


def detect_mood_keywords(user_text: str) -> MoodSignal:
    """Detect a mood using transparent keyword rules.

    Params:
        user_text: Raw user message.
    Returns:
        MoodSignal containing mood, confidence, and matched keywords.
    """

    normalized = normalize_text(user_text)
    if not normalized:
        return MoodSignal(
            mood="neutral",
            confidence=0.2,
            matched_keywords=[],
            raw_text=user_text,
        )

    best_mood = "neutral"
    best_matches: List[str] = []

    # Priority matters: urgent_support is checked first because safety beats normal routing.
    for mood, keywords in MOOD_KEYWORDS.items():
        matches = [keyword for keyword in keywords if keyword in normalized]
        if matches and len(matches) > len(best_matches):
            best_mood = mood
            best_matches = matches

    if not best_matches:
        return MoodSignal(
            mood="neutral",
            confidence=0.35,
            matched_keywords=[],
            raw_text=user_text,
        )

    # Simple, explainable confidence for teaching purposes.
    confidence = min(0.95, 0.55 + 0.15 * len(best_matches))
    return MoodSignal(
        mood=best_mood,
        confidence=round(confidence, 2),
        matched_keywords=best_matches,
        raw_text=user_text,
    )


def breathing_exercise_tool() -> str:
    """Return a short grounding exercise.

    Params:
        None.
    Returns:
        User-facing grounding exercise.
    """

    return (
        "Try a 30-second reset: inhale for 4 counts, hold for 2, exhale for 6. "
        "Repeat this three times, then name one next action you can take."
    )


def focus_plan_tool() -> str:
    """Return a tiny focus plan.

    Params:
        None.
    Returns:
        User-facing focus plan.
    """

    return (
        "Use a 10-minute focus sprint: pick one task, remove one distraction, "
        "work for 10 minutes, then write down the next smallest step."
    )


def journal_prompt_tool() -> str:
    """Return a reflective journaling prompt.

    Params:
        None.
    Returns:
        User-facing journaling prompt.
    """

    return (
        "Write three lines: What am I feeling? What triggered it? "
        "What is one kind action I can take for myself right now?"
    )


def encouragement_tool() -> str:
    """Return a positive reinforcement response.

    Params:
        None.
    Returns:
        User-facing encouragement.
    """

    return (
        "Good signal. Use that momentum: choose one meaningful next step and make it visible, "
        "such as opening the file, writing the first sentence, or scheduling the next block."
    )


def clarification_tool() -> str:
    """Return a clarification prompt.

    Params:
        None.
    Returns:
        User-facing clarification question.
    """

    return (
        "Let's make the uncertainty smaller. Name the exact part that feels unclear, "
        "then ask: is this a concept problem, a tool problem, or a next-step problem?"
    )


def supportive_checkin_tool() -> str:
    """Return a general supportive response.

    Params:
        None.
    Returns:
        User-facing neutral check-in.
    """

    return (
        "I hear you. Let's slow the situation down: describe the current state in one sentence, "
        "then choose one next action that takes less than two minutes."
    )


def urgent_support_tool() -> str:
    """Return a safety-oriented support message for urgent self-harm language.

    Params:
        None.
    Returns:
        User-facing urgent support message.
    """

    return (
        "I'm really sorry you're feeling this much pain. This demo is not a crisis service. "
        "Please contact local emergency services now if you may be in immediate danger, "
        "or reach out to someone you trust and tell them you need support right away."
    )


TOOL_REGISTRY: Dict[str, Callable[[], str]] = {
    "breathing_exercise_tool": breathing_exercise_tool,
    "focus_plan_tool": focus_plan_tool,
    "journal_prompt_tool": journal_prompt_tool,
    "encouragement_tool": encouragement_tool,
    "clarification_tool": clarification_tool,
    "supportive_checkin_tool": supportive_checkin_tool,
    "urgent_support_tool": urgent_support_tool,
}


def choose_tool(mood_signal: MoodSignal, memory: MoodMemory) -> str:
    """Choose an action/tool based on current signal and memory.

    Params:
        mood_signal: Current mood classification.
        memory: Short-term memory object.
    Returns:
        Tool name from TOOL_REGISTRY.
    """

    mood = mood_signal.mood

    if mood == "urgent_support":
        return "urgent_support_tool"

    # Memory-aware rule: repeated anxiety or sadness gets a grounding/journaling tool.
    projected_repetition = memory.repeated_mood_count(mood, limit=3) + 1
    if mood == "anxious":
        return "breathing_exercise_tool"
    if mood == "sad":
        return "journal_prompt_tool" if projected_repetition >= 2 else "supportive_checkin_tool"
    if mood == "frustrated":
        return "focus_plan_tool"
    if mood == "tired":
        return "focus_plan_tool"
    if mood == "confident":
        return "encouragement_tool"
    if mood == "confused":
        return "clarification_tool"

    return "supportive_checkin_tool"


def explain_policy_choice(mood_signal: MoodSignal, selected_tool: str, memory: MoodMemory) -> str:
    """Create a trainer-friendly explanation of the controller decision.

    Params:
        mood_signal: Current mood classification.
        selected_tool: Tool chosen by the policy.
        memory: Short-term memory object before storing the current turn.
    Returns:
        Explanation string for the trace.
    """

    keyword_part = (
        f"matched keywords {mood_signal.matched_keywords}"
        if mood_signal.matched_keywords
        else "no strong keywords matched"
    )
    repetition = memory.repeated_mood_count(mood_signal.mood, limit=3)
    return (
        f"Detected mood='{mood_signal.mood}' with confidence={mood_signal.confidence}; "
        f"{keyword_part}; recent same-mood count before this turn={repetition}; "
        f"selected action='{selected_tool}'."
    )


class MoodBotAgent:
    """A small agent that demonstrates perception, memory, policy, tools, and tracing.

    Params:
        memory: Optional MoodMemory object. A new one is created when omitted.
    Returns:
        MoodBotAgent instance ready to process turns.
    """

    def __init__(self, memory: Optional[MoodMemory] = None) -> None:
        """Create a MoodBotAgent.

        Params:
            memory: Optional existing memory store.
        Returns:
            None.
        """

        self.memory = memory or MoodMemory()

    def run_turn(self, user_text: str) -> AgentResponse:
        """Run one full Observe -> Think -> Act -> Observe cycle.

        Params:
            user_text: Raw user message.
        Returns:
            AgentResponse with message, selected tool, trace, and memory snapshot.
        """

        if not user_text or not user_text.strip():
            user_text = "I am not sure what to say."

        observe = f"User said: {user_text}"
        mood_signal = detect_mood_keywords(user_text)
        selected_tool = choose_tool(mood_signal, self.memory)
        think = explain_policy_choice(mood_signal, selected_tool, self.memory)

        tool_function = TOOL_REGISTRY[selected_tool]
        action_result = tool_function()

        self.memory.add_turn(
            user_text=user_text,
            mood_signal=mood_signal,
            selected_tool=selected_tool,
        )

        trace = AgentTrace(
            observe=observe,
            think=think,
            act=f"Called {selected_tool}()",
            observe_result=f"Tool returned: {action_result}",
        )

        return AgentResponse(
            message=action_result,
            mood_signal=mood_signal,
            selected_tool=selected_tool,
            trace=trace,
            memory_snapshot=self.memory.snapshot(),
        )


def run_scripted_demo(inputs: List[str]) -> List[AgentResponse]:
    """Run a list of inputs through a fresh MoodBotAgent.

    Params:
        inputs: List of user messages.
    Returns:
        List of AgentResponse objects.
    """

    agent = MoodBotAgent()
    return [agent.run_turn(user_text) for user_text in inputs]

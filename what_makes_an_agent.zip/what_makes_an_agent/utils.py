"""
Utility helpers for the What Makes an Agent practical notebook.

This file keeps notebook cells readable while preserving the core agent logic
in mood_bot.py.
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

from dotenv import load_dotenv

from mood_bot import AgentResponse, AgentTrace


def trace_to_markdown(trace: AgentTrace) -> str:
    """Format an AgentTrace as Markdown.

    Params:
        trace: AgentTrace object from a MoodBotAgent turn.
    Returns:
        Markdown string showing Observe -> Think -> Act -> Observe.
    """

    return "\n".join(
        [
            "### Agent Loop Trace",
            f"**Observe:** {trace.observe}",
            f"**Think:** {trace.think}",
            f"**Act:** {trace.act}",
            f"**Observe result:** {trace.observe_result}",
        ]
    )


def response_to_dict(response: AgentResponse) -> Dict[str, Any]:
    """Convert an AgentResponse into a notebook-friendly dictionary.

    Params:
        response: AgentResponse returned by MoodBotAgent.
    Returns:
        Dictionary with key fields for display.
    """

    return {
        "message": response.message,
        "detected_mood": response.mood_signal.mood,
        "confidence": response.mood_signal.confidence,
        "matched_keywords": response.mood_signal.matched_keywords,
        "selected_tool": response.selected_tool,
        "memory_snapshot": response.memory_snapshot,
    }


def print_response(response: AgentResponse, show_trace: bool = True) -> None:
    """Print a readable response and optional trace.

    Params:
        response: AgentResponse returned by MoodBotAgent.
        show_trace: Whether to print the loop trace.
    Returns:
        None.
    """

    print("USER-FACING MESSAGE")
    print(response.message)
    print("\nSTRUCTURED STATE")
    print(json.dumps(response_to_dict(response), indent=2))
    if show_trace:
        print("\nTRACE")
        print(f"Observe: {response.trace.observe}")
        print(f"Think: {response.trace.think}")
        print(f"Act: {response.trace.act}")
        print(f"Observe result: {response.trace.observe_result}")


def load_sample_inputs(path: str | Path = "data/sample_inputs.json") -> List[str]:
    """Load sample user inputs for scripted demo runs.

    Params:
        path: Path to JSON file containing sample inputs.
    Returns:
        List of input strings.
    """

    data_path = Path(path)
    if not data_path.exists():
        raise FileNotFoundError(
            f"Could not find {data_path}. Run this from the package root."
        )

    payload = json.loads(data_path.read_text(encoding="utf-8"))
    return [str(item["text"]) for item in payload["samples"]]


def extract_json_object(text: str) -> Optional[Dict[str, Any]]:
    """Extract the first JSON object from model output.

    Params:
        text: Raw model output.
    Returns:
        Parsed JSON object, or None if parsing fails.
    """

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if not match:
            return None
        try:
            return json.loads(match.group(0))
        except json.JSONDecodeError:
            return None


def classify_mood_with_openai(user_text: str, model_name: Optional[str] = None) -> Dict[str, Any]:
    """Optionally classify mood using OpenAI's Responses API.

    Params:
        user_text: Raw user message.
        model_name: Optional model override. Uses OPENAI_MODEL when omitted.
    Returns:
        Dictionary with either classification fields or a clear error message.
    """

    load_dotenv()

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return {
            "ok": False,
            "error": (
                "OPENAI_API_KEY is not set. The core practical does not require an API key; "
                "set OPENAI_API_KEY in .env only for the optional LLM controller demo."
            ),
        }

    try:
        from openai import OpenAI
    except ImportError:
        return {
            "ok": False,
            "error": "The openai package is not installed. Run: pip install -r requirements.txt",
        }

    selected_model = model_name or os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    client = OpenAI(api_key=api_key)

    prompt = f"""
You are the perception component of a teaching mood-bot agent.

Classify the user's message into exactly one mood:
anxious, sad, frustrated, tired, confident, confused, neutral, urgent_support.

Return only JSON with:
{{
  "mood": "...",
  "confidence": 0.0,
  "reason": "short reason"
}}

Do not provide therapy, diagnosis, or advice. Classify only.

User message:
{user_text}
""".strip()

    try:
        # COST NOTE: This optional cell usually costs far below $0.01 for a few short classifications
        # when using a small model such as gpt-4o-mini.
        response = client.responses.create(
            model=selected_model,
            input=prompt,
        )
    except Exception as exc:  # noqa: BLE001 - teaching-friendly failure message
        return {
            "ok": False,
            "error": f"OpenAI request failed: {exc}",
        }

    output_text = getattr(response, "output_text", "")
    parsed = extract_json_object(output_text)
    if parsed is None:
        return {
            "ok": False,
            "error": "Model response was not valid JSON.",
            "raw_output": output_text,
        }

    parsed["ok"] = True
    parsed["model"] = selected_model
    return parsed


def print_table(rows: Iterable[Dict[str, Any]]) -> None:
    """Print a small aligned text table without external dependencies.

    Params:
        rows: Iterable of dictionaries with identical or similar keys.
    Returns:
        None.
    """

    materialized = list(rows)
    if not materialized:
        print("(no rows)")
        return

    headers = list(materialized[0].keys())
    widths = {
        header: max(len(str(header)), *(len(str(row.get(header, ""))) for row in materialized))
        for header in headers
    }

    header_line = " | ".join(str(header).ljust(widths[header]) for header in headers)
    separator = "-+-".join("-" * widths[header] for header in headers)
    print(header_line)
    print(separator)
    for row in materialized:
        print(" | ".join(str(row.get(header, "")).ljust(widths[header]) for header in headers))

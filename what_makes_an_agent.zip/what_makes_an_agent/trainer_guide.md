# Trainer Guide — What Makes an Agent Practical

## Demo goal

Use a simple mood-bot to make the agent loop concrete:

```text
Observe → Think → Act → Observe
```

The practical is deliberately plain Python. The goal is not to impress learners with a framework. The goal is to let them see the architecture: perception, memory, controller, tool/action, and trace.

## Recommended practical timing

Total practical block: about 65 minutes.

### 0–5 min — Set context

Remind the class:

- A chatbot generates a reply.
- A workflow follows fixed steps.
- An agent chooses what to do next from state, goal, memory, and tools.

Show the package structure before opening the notebook.

### 5–15 min — Perception: keyword mood detection

Open the first perception section.

Teaching points:

- Perception does not have to mean computer vision or sensors.
- In text agents, perception often means turning unstructured user input into structured state.
- A simple rule-based classifier is useful because everyone can inspect it.

Run:

```python
detect_mood_keywords("I am nervous about tomorrow's interview")
```

Ask the class what could go wrong with keyword rules.

### 15–25 min — Controller/policy

Show `choose_tool()`.

Teaching points:

- The policy/controller decides the next action.
- The LLM is not always the controller.
- Rules, state machines, planners, and LLMs can all serve as controllers.

Use the phrase: “Policy is the decision logic. The LLM is only one possible implementation.”

### 25–35 min — Tools/actions

Show the tool registry.

Teaching points:

- A tool is just something the agent can call.
- Today it is a Python function.
- Later it could be search, calculator, database query, calendar, email, or code interpreter.

Point out that framework tool abstractions are wrappers around this basic idea.

### 35–45 min — Memory

Show `MoodMemory`.

Teaching points:

- Memory changes future behavior.
- Without memory, every turn is isolated.
- Short-term memory is enough for this beginner agent.

Run two sad inputs in a row and show the action changing because memory changed.

### 45–55 min — Full agent loop

Run:

```python
agent = MoodBotAgent()
response = agent.run_turn("I am nervous about tomorrow's interview and I cannot focus.")
print_response(response)
```

Emphasize the trace:

- Observe: raw user input.
- Think: mood + confidence + memory-aware decision.
- Act: selected tool call.
- Observe result: tool output returned to the agent/user.

### 55–60 min — Optional LLM-backed perception

Use this only if the API key is already configured.

Teaching points:

- The LLM can replace the perception module.
- This does not automatically make the whole system agentic.
- The agent is still the surrounding loop and architecture.

Skip this section if keys are not ready.

### 60–65 min — Exercise briefing

Assign one of the notebook exercises:

1. Add a new mood.
2. Add a new tool.
3. Make memory influence the controller more strongly.

## Likely questions and ideal answers

### 1. Is this really an agent if it is rule-based?

Yes, for teaching purposes. An agent is defined by the loop and architecture: it observes state, reasons using a policy, acts, and updates/uses memory. The reasoning can be simple rules or an LLM.

### 2. Why not start with LangChain?

Because this is the first agent session. Frameworks hide the loop. First make the loop visible, then use frameworks when the architecture is understood.

### 3. Is the mood-bot a mental-health chatbot?

No. It is a safe educational toy example. It must not diagnose, treat, or replace human support. It includes a basic urgent-support route to show that real agents need safety-aware routing.

### 4. Why use keyword rules if LLMs are better?

Keyword rules are transparent. Learners can see where the decision comes from. Later, an LLM can replace the classifier, but the architecture remains the same.

### 5. What is the difference between memory and chat history?

Chat history is raw past conversation. Memory is selected, structured state extracted from history. In this example, recent mood labels are the memory.

### 6. What is a tool in this practical?

A normal Python function. In production, the same idea can wrap APIs, databases, file systems, web search, code execution, or business systems.

### 7. What makes this different from a normal if-else program?

The beginner version is intentionally close to an if-else program. The difference is the architectural framing: explicit observation, state, policy, action, memory, and trace. This scaffolds the mental model before LLM-driven agents.

### 8. Where does planning fit?

Planning is the next level above this reflex agent. Instead of directly mapping input to one action, a planner decomposes a goal into multiple steps and chooses the sequence.

### 9. Does the agent learn over time?

Not in the machine-learning sense. It adapts within a short session using memory, but it does not update model weights or permanently learn from data.

### 10. Why show the trace?

Traces are how agent systems become debuggable. Later production sessions introduce formal observability, but this practical starts the habit early.

## Common errors and fixes

### `ModuleNotFoundError: mood_bot`

The notebook is being run from the wrong folder. Start Jupyter from the package root.

### API key error

Only the optional LLM cell needs `OPENAI_API_KEY`. Skip it if the class is not configured.

### The notebook kernel uses the wrong Python environment

In Jupyter, choose the kernel linked to the virtual environment created for this package.

### Mood classification seems wrong

Use this as a teaching moment. Ask how the perception step could be improved:
- More keywords
- Weighted keywords
- LLM classifier
- Fine-tuned classifier
- User confirmation question

## What to skip if running short

Skip the optional OpenAI classifier. The essential practical is the plain-Python agent loop.

Also skip the full scripted demo table if time is tight; run one anxious example and two repeated sad examples instead.

## Extension ideas

- Add a `study_overload` mood.
- Add a `mock_interview_tool()`.
- Add long-term memory by writing memory to JSON.
- Add a simple planning graph for interview preparation.
- Replace the keyword detector with an LLM classifier.
- Add a safety policy that blocks tool calls for unsupported requests.
- Add structured logging of every trace to a `.jsonl` file.

## Live-coding recommendation

Do not live-code every line of `mood_bot.py`. Walk through the architecture first, then modify one small part live:

- Add a new keyword to `MOOD_KEYWORDS`.
- Add a new tool function.
- Update `choose_tool()` to route a mood to that tool.

This creates visible learner participation without risking too much demo time.

## Practical handoff to the next session

Close by saying:

“Today we built a visible agent loop in plain Python. In the LLM Anatomy session, we look inside the model that often powers the reasoning step. In Agent Architectures in Practice, these same pieces become a framework-based agent with memory and tools.”

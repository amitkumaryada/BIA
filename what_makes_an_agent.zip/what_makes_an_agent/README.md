# What Makes an Agent — Practical Code Package

Build a simple mood-bot agent in Python to make the agent loop visible: Observe → Think → Act → Observe.

This practical teaches how an agent is more than a language model. You will build a small system with perception, memory, a controller, tools/actions, and a trace of every decision.

## Prerequisites

- Python 3.10 or 3.11
- VS Code, Jupyter Notebook, or JupyterLab
- Basic Python knowledge: functions, dictionaries, classes
- OpenAI account/key only for the optional LLM-backed controller demo

The core practical is local and free. It does not require GPU, LangChain, or any paid API.

## Setup

### 1. Download or open the folder

Open this folder in VS Code or a terminal:

```bash
cd what_makes_an_agent
```

### 2. Create a virtual environment

Using `venv`:

```bash
python -m venv .venv
```

Activate it on macOS/Linux:

```bash
source .venv/bin/activate
```

Activate it on Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Using Conda instead:

```bash
conda create -n what-makes-an-agent python=3.11 -y
conda activate what-makes-an-agent
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure `.env`

The core practical does not require an API key. For the optional LLM-backed perception demo:

```bash
cp .env.sample .env
```

On Windows PowerShell:

```powershell
Copy-Item .env.sample .env
```

Then add your OpenAI key to `.env`:

```text
OPENAI_API_KEY=sk-your-key-here
OPENAI_MODEL=gpt-4o-mini
```

## How to run

### Option A — Notebook-first teaching flow

```bash
jupyter notebook notebook.ipynb
```

Then choose **Kernel → Restart & Run All**.

### Option B — Import from Python

```python
from mood_bot import MoodBotAgent
from utils import print_response

agent = MoodBotAgent()
response = agent.run_turn("I am nervous about tomorrow's interview")
print_response(response)
```

## What each file does

- `notebook.ipynb` — main teaching notebook with concept explanation, progressive builds, integration, and exercises.
- `mood_bot.py` — core agent implementation: perception, memory, controller, tools, and trace objects.
- `utils.py` — notebook display helpers and optional OpenAI classifier demo.
- `data/sample_inputs.json` — sample messages for scripted runs.
- `.env.sample` — safe template for optional API configuration.
- `requirements.txt` — pinned dependencies for Python 3.10/3.11.
- `trainer_guide.md` — delivery plan, timing, likely questions, errors, and extension ideas.

## Expected output

By the end of the notebook, you should see:

1. A rule-based perception step that detects moods from text.
2. A memory object that stores recent mood states.
3. A controller that chooses tools/actions based on mood and memory.
4. A complete agent turn printed as:
   - Observe
   - Think
   - Act
   - Observe result
5. A scripted demo showing multiple turns and changing memory.
6. Optional LLM-backed mood classification if `OPENAI_API_KEY` is configured.

Example output:

```text
USER-FACING MESSAGE
Try a 30-second reset: inhale for 4 counts, hold for 2, exhale for 6...

STRUCTURED STATE
{
  "detected_mood": "anxious",
  "confidence": 0.85,
  "selected_tool": "breathing_exercise_tool",
  "memory_snapshot": {
    "turn_count": 1,
    "recent_moods": ["anxious"]
  }
}

TRACE
Observe: User said: I am nervous about tomorrow's interview
Think: Detected mood='anxious'...
Act: Called breathing_exercise_tool()
Observe result: Tool returned: Try a 30-second reset...
```

## Estimated API cost

- Core practical: ₹0 / $0 because it runs locally.
- Optional OpenAI classifier demo: typically far below $0.05 for a few short examples with `gpt-4o-mini`.

The optional model name is parameterized through `OPENAI_MODEL`, so trainers can swap models without editing code.

## Troubleshooting

### `ModuleNotFoundError: No module named 'mood_bot'`

Run the notebook from the package root:

```bash
cd what_makes_an_agent
jupyter notebook notebook.ipynb
```

### `OPENAI_API_KEY is not set`

This is expected unless you are running the optional LLM controller cell. The core practical works without an API key.

### `pip install -r requirements.txt` fails

Confirm that the environment uses Python 3.10 or 3.11:

```bash
python --version
```

Then upgrade pip:

```bash
python -m pip install --upgrade pip
```

### The mood detection feels simplistic

That is intentional. The first build uses transparent rules so the agent loop is visible. The optional LLM classifier demonstrates how a model can replace part of the perception/controller logic later.

## Further reading

- OpenAI Responses API documentation
- OpenAI Function Calling guide
- Russell & Norvig, *Artificial Intelligence: A Modern Approach* — agent types and rational agents
- LangChain documentation — agents and tools
- LangGraph documentation — stateful graph-based agents

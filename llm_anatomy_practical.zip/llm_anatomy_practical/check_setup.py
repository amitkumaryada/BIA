"""
Quick local setup check for the LLM Anatomy practical lab.
Run: python check_setup.py
"""

from __future__ import annotations

import json
from pathlib import Path

from utils import (
    calculate_context_budget,
    decoding_distribution,
    make_embedding_table,
    lookup_embeddings,
    scaled_dot_product_attention,
    tokenize_examples,
    train_toy_bpe,
)


def main() -> None:
    """Run a lightweight smoke test for core local functions."""
    data_dir = Path("data")
    examples = json.loads((data_dir / "token_examples.json").read_text(encoding="utf-8"))
    records = tokenize_examples(examples[:2])
    assert records and records[0]["token_count"] > 0

    corpus = (data_dir / "tiny_bpe_corpus.txt").read_text(encoding="utf-8")
    bpe = train_toy_bpe(corpus, num_merges=5)
    assert "merges" in bpe

    table = make_embedding_table(256, 8)
    embeds = lookup_embeddings([1, 2, 3], table)
    attn = scaled_dot_product_attention(embeds)
    assert attn["weights"].shape == (3, 3)

    probs = decoding_distribution([2.0, 1.0, 0.5], temperature=0.8, top_k=2)
    assert abs(float(probs.sum()) - 1.0) < 1e-8

    segments = json.loads((data_dir / "agent_context_segments.json").read_text(encoding="utf-8"))
    budget = calculate_context_budget(segments, context_limit=8192, reserved_output_tokens=500)
    assert budget.used_input_tokens > 0

    print("Setup check passed. Core local lab functions are working.")


if __name__ == "__main__":
    main()

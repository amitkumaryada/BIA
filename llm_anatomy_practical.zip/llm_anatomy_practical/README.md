# LLM Anatomy Practical Lab

Hands-on teaching material for understanding how a language model turns text into tokens, vectors, attention patterns, and next-token probabilities.

## Prerequisites

- Python 3.10 or 3.11
- VS Code, JupyterLab, or classic Jupyter Notebook
- No GPU required
- OpenAI API key is optional. The main practical runs locally; the final parameter experiment can use `gpt-4o-mini`.

## Setup

### Option A: venv

```bash
cd llm_anatomy_practical
python -m venv .venv

# Windows
.venv\Scripts\activate

# macOS/Linux
source .venv/bin/activate

pip install --upgrade pip
pip install -r requirements.txt
```

### Option B: conda

```bash
cd llm_anatomy_practical
conda create -n llm-anatomy python=3.11 -y
conda activate llm-anatomy
pip install --upgrade pip
pip install -r requirements.txt
```

### Configure environment variables

```bash
cp .env.sample .env
```

Fill `OPENAI_API_KEY` only when running the optional live LLM generation cells. The local tokenizer, BPE, embedding, attention, decoding, and context-window sections do not need a key.

## How to run

```bash
jupyter notebook notebook.ipynb
```

Then run the notebook top to bottom. The optional OpenAI cell checks for `OPENAI_API_KEY`; when the key is missing, it prints a friendly skip message.

## What each file does

| File | Purpose |
|---|---|
| `notebook.ipynb` | Main guided practical lab with explanations, code, interpretation, and exercises. |
| `utils.py` | Small transparent helper functions for tokenisation, toy BPE, embeddings, attention, decoding, context budgeting, and alignment preview. |
| `data/token_examples.json` | Text examples used to compare tokenisation behavior. |
| `data/tiny_bpe_corpus.txt` | Tiny corpus for the toy BPE training demo. |
| `data/agent_context_segments.json` | Sample agent prompt segments for context-window budgeting. |
| `.env.sample` | Environment variable template with no real secrets. |
| `requirements.txt` | Fully pinned dependencies. |
| `trainer_guide.md` | Minute-by-minute teaching flow, likely questions, common errors, and extension ideas. |

## Expected output

By the end of the lab, you should see:

1. A table comparing character counts and token counts across English, code, multilingual text, emojis, and typo-heavy input.
2. A toy BPE merge history showing how frequent character pairs become reusable sub-word chunks.
3. A small embedding matrix showing how token IDs retrieve vector rows.
4. A causal self-attention matrix where future tokens receive zero attention weight.
5. Probability tables showing how temperature, top-k, and top-p change next-token selection.
6. A context-window budget report showing how system instructions, history, retrieved context, and tool output compete for available space.
7. Optional live OpenAI outputs comparing deterministic and creative decoding settings.

## Estimated API cost

The local sections cost **$0**.

The optional OpenAI section sends a few short prompts to `gpt-4o-mini`; a typical full run should be well under **$0.05**, depending on the account pricing and model settings. Keep outputs short during live demos.

## Troubleshooting

**`ModuleNotFoundError: No module named 'tiktoken'`**  
Run `pip install -r requirements.txt` inside the activated environment.

**`OPENAI_API_KEY not found`**  
The notebook is still usable. Only the optional live generation section needs the key. To enable it, copy `.env.sample` to `.env` and add your key.

**Matplotlib plot does not display**  
Restart the kernel and rerun the cell. In VS Code, choose the correct Python environment from the top-right kernel selector.

**Token pieces look strange or begin with spaces**  
That is expected. Modern tokenizers often encode leading spaces as part of the next token.

## Further reading

- OpenAI tiktoken project page and educational BPE examples
- The original Transformer paper: *Attention Is All You Need*
- OpenAI platform documentation for text generation parameters
- Hugging Face tokenizer documentation
- Direct Preference Optimization paper for the alignment preview

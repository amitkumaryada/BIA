"""
Utility functions for the LLM Anatomy practical lab.

The functions are intentionally small and transparent so they can be
walked through live during class.
"""

from __future__ import annotations

import math
import os
import re
from collections import Counter
from dataclasses import dataclass
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np


TokenizedText = Dict[str, Any]


def simple_fallback_tokens(text: str) -> List[str]:
    """Split text into a simple word/punctuation fallback token list.

    Parameters
    ----------
    text:
        Raw text to split.

    Returns
    -------
    list[str]
        Regex-based tokens. This is not BPE, but it keeps the lab runnable
        even when tiktoken is not installed.
    """
    return re.findall(r"\w+|[^\w\s]", text, flags=re.UNICODE)


def get_tiktoken_encoding(encoding_name: str = "o200k_base") -> Optional[Any]:
    """Load a tiktoken encoding if tiktoken is installed.

    Parameters
    ----------
    encoding_name:
        Encoding name such as "o200k_base" or "cl100k_base".

    Returns
    -------
    Optional[Any]
        A tiktoken encoding object, or None if tiktoken is unavailable.
    """
    try:
        import tiktoken  # type: ignore

        return tiktoken.get_encoding(encoding_name)
    except Exception:
        return None


def count_tokens(text: str, encoding_name: str = "o200k_base") -> int:
    """Count tokens using tiktoken when available, otherwise a fallback split.

    Parameters
    ----------
    text:
        Text to count.
    encoding_name:
        tiktoken encoding name.

    Returns
    -------
    int
        Token count.
    """
    encoding = get_tiktoken_encoding(encoding_name)
    if encoding is None:
        return len(simple_fallback_tokens(text))
    return len(encoding.encode(text))


def tokenize_examples(
    examples: Sequence[Dict[str, str]],
    encoding_name: str = "o200k_base",
) -> List[TokenizedText]:
    """Tokenize labelled examples and return counts plus decoded pieces.

    Parameters
    ----------
    examples:
        Sequence of dictionaries with "label" and "text".
    encoding_name:
        tiktoken encoding name.

    Returns
    -------
    list[dict[str, Any]]
        Tokenisation records for display.
    """
    encoding = get_tiktoken_encoding(encoding_name)
    records: List[TokenizedText] = []

    for item in examples:
        text = item["text"]
        if encoding is None:
            token_strings = simple_fallback_tokens(text)
            token_ids = list(range(len(token_strings)))
        else:
            token_ids = encoding.encode(text)
            token_strings = [encoding.decode([token_id]) for token_id in token_ids]

        records.append(
            {
                "label": item["label"],
                "text": text,
                "chars": len(text),
                "token_count": len(token_ids),
                "token_ids": token_ids,
                "token_strings": token_strings,
            }
        )
    return records


def word_to_symbol_tuple(word: str) -> Tuple[str, ...]:
    """Represent a word as character symbols plus an end-of-word marker.

    Parameters
    ----------
    word:
        A single word.

    Returns
    -------
    tuple[str, ...]
        Symbols used by the toy BPE trainer.
    """
    return tuple(word) + ("</w>",)


def get_pair_counts(vocab: Counter[Tuple[str, ...]]) -> Counter[Tuple[str, str]]:
    """Count adjacent symbol pairs in the toy BPE vocabulary.

    Parameters
    ----------
    vocab:
        Counter mapping symbol tuples to frequencies.

    Returns
    -------
    Counter[tuple[str, str]]
        Adjacent pair frequencies.
    """
    pairs: Counter[Tuple[str, str]] = Counter()
    for symbols, freq in vocab.items():
        for idx in range(len(symbols) - 1):
            pairs[(symbols[idx], symbols[idx + 1])] += freq
    return pairs


def merge_pair(
    symbols: Tuple[str, ...],
    pair: Tuple[str, str],
) -> Tuple[str, ...]:
    """Merge one symbol pair wherever it appears.

    Parameters
    ----------
    symbols:
        Current symbol tuple.
    pair:
        Pair to merge.

    Returns
    -------
    tuple[str, ...]
        Updated symbol tuple.
    """
    merged: List[str] = []
    i = 0
    while i < len(symbols):
        if i < len(symbols) - 1 and (symbols[i], symbols[i + 1]) == pair:
            merged.append(symbols[i] + symbols[i + 1])
            i += 2
        else:
            merged.append(symbols[i])
            i += 1
    return tuple(merged)


def train_toy_bpe(corpus: str, num_merges: int = 12) -> Dict[str, Any]:
    """Train a toy byte-pair encoding model on a tiny corpus.

    Parameters
    ----------
    corpus:
        Whitespace-separated toy training text.
    num_merges:
        Number of pair merges to perform.

    Returns
    -------
    dict[str, Any]
        Merge history and the final vocabulary.
    """
    words = re.findall(r"\S+", corpus.lower())
    vocab: Counter[Tuple[str, ...]] = Counter(word_to_symbol_tuple(word) for word in words)
    merges: List[Dict[str, Any]] = []

    for step in range(num_merges):
        pair_counts = get_pair_counts(vocab)
        if not pair_counts:
            break

        best_pair, frequency = pair_counts.most_common(1)[0]
        if frequency < 2:
            break

        new_vocab: Counter[Tuple[str, ...]] = Counter()
        for symbols, freq in vocab.items():
            new_vocab[merge_pair(symbols, best_pair)] += freq

        vocab = new_vocab
        merges.append(
            {
                "step": step + 1,
                "merge": " + ".join(best_pair) + " → " + "".join(best_pair),
                "frequency": frequency,
                "vocab_snapshot": {" ".join(k): v for k, v in vocab.items()},
            }
        )

    return {
        "merges": merges,
        "final_vocab": {" ".join(k): v for k, v in vocab.items()},
    }


def apply_toy_bpe(word: str, merge_history: Sequence[Dict[str, Any]]) -> List[str]:
    """Apply the toy BPE merge history to one word.

    Parameters
    ----------
    word:
        Word to segment.
    merge_history:
        Merge records returned by train_toy_bpe.

    Returns
    -------
    list[str]
        Segmented symbols without the end-of-word marker.
    """
    symbols = word_to_symbol_tuple(word.lower())
    for merge_record in merge_history:
        left_right, merged = merge_record["merge"].split(" → ")
        left, right = left_right.split(" + ")
        symbols = merge_pair(symbols, (left, right))
    return [symbol for symbol in symbols if symbol != "</w>"]


def make_embedding_table(
    vocab_size: int,
    embedding_dim: int = 8,
    seed: int = 42,
) -> np.ndarray:
    """Create a small random embedding table for demonstration.

    Parameters
    ----------
    vocab_size:
        Number of vocabulary rows.
    embedding_dim:
        Number of vector dimensions.
    seed:
        Random seed for reproducibility.

    Returns
    -------
    np.ndarray
        Shape: (vocab_size, embedding_dim).
    """
    rng = np.random.default_rng(seed)
    return rng.normal(loc=0.0, scale=0.35, size=(vocab_size, embedding_dim))


def lookup_embeddings(token_ids: Sequence[int], embedding_table: np.ndarray) -> np.ndarray:
    """Look up rows from an embedding table.

    Parameters
    ----------
    token_ids:
        Token IDs to look up.
    embedding_table:
        Matrix of token vectors.

    Returns
    -------
    np.ndarray
        Embedding matrix for the input sequence.
    """
    max_id = embedding_table.shape[0] - 1
    safe_ids = [int(token_id) % (max_id + 1) for token_id in token_ids]
    return embedding_table[safe_ids]


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    """Calculate cosine similarity between two vectors.

    Parameters
    ----------
    a:
        First vector.
    b:
        Second vector.

    Returns
    -------
    float
        Cosine similarity.
    """
    denominator = np.linalg.norm(a) * np.linalg.norm(b)
    if denominator == 0:
        return 0.0
    return float(np.dot(a, b) / denominator)


def softmax(values: np.ndarray, axis: int = -1) -> np.ndarray:
    """Compute a numerically stable softmax.

    Parameters
    ----------
    values:
        Input logits or scores.
    axis:
        Axis over which to normalize.

    Returns
    -------
    np.ndarray
        Probability distribution along the selected axis.
    """
    values = np.asarray(values, dtype=float)
    max_values = np.max(values, axis=axis, keepdims=True)
    exp_values = np.exp(values - max_values)
    exp_values = np.where(np.isfinite(values), exp_values, 0.0)
    sums = np.sum(exp_values, axis=axis, keepdims=True)
    return np.divide(exp_values, sums, out=np.zeros_like(exp_values), where=sums != 0)


def scaled_dot_product_attention(
    embeddings: np.ndarray,
    causal: bool = True,
    seed: int = 7,
) -> Dict[str, np.ndarray]:
    """Run a transparent single-head self-attention calculation.

    This creates demonstration Q/K/V projection matrices and calculates
    attention weights from an input embedding matrix.

    Parameters
    ----------
    embeddings:
        Sequence embedding matrix with shape (tokens, embedding_dim).
    causal:
        Whether to apply a causal mask.
    seed:
        Random seed for repeatable projection matrices.

    Returns
    -------
    dict[str, np.ndarray]
        Q, K, V, scores, masked_scores, weights, and output.
    """
    rng = np.random.default_rng(seed)
    embedding_dim = embeddings.shape[1]
    projection_scale = 1 / math.sqrt(embedding_dim)

    w_q = rng.normal(scale=projection_scale, size=(embedding_dim, embedding_dim))
    w_k = rng.normal(scale=projection_scale, size=(embedding_dim, embedding_dim))
    w_v = rng.normal(scale=projection_scale, size=(embedding_dim, embedding_dim))

    q = embeddings @ w_q
    k = embeddings @ w_k
    v = embeddings @ w_v

    scores = (q @ k.T) / math.sqrt(embedding_dim)
    masked_scores = scores.copy()

    if causal:
        future_mask = np.triu(np.ones_like(masked_scores, dtype=bool), k=1)
        masked_scores[future_mask] = -np.inf

    weights = softmax(masked_scores, axis=-1)
    output = weights @ v

    return {
        "Q": q,
        "K": k,
        "V": v,
        "scores": scores,
        "masked_scores": masked_scores,
        "weights": weights,
        "output": output,
    }


def apply_temperature(logits: np.ndarray, temperature: float) -> np.ndarray:
    """Scale logits by temperature before softmax.

    Parameters
    ----------
    logits:
        Raw model scores.
    temperature:
        Positive value. Lower is more deterministic; higher is more random.

    Returns
    -------
    np.ndarray
        Temperature-adjusted logits.
    """
    if temperature <= 0:
        raise ValueError("temperature must be greater than 0")
    return np.asarray(logits, dtype=float) / temperature


def filter_top_k(probabilities: np.ndarray, k: Optional[int]) -> np.ndarray:
    """Keep only the k highest-probability items and renormalize.

    Parameters
    ----------
    probabilities:
        Probability distribution.
    k:
        Number of candidates to keep. None keeps all.

    Returns
    -------
    np.ndarray
        Filtered probability distribution.
    """
    probs = np.asarray(probabilities, dtype=float)
    if k is None or k >= len(probs):
        return probs / probs.sum()
    if k <= 0:
        raise ValueError("k must be positive or None")

    keep_indices = np.argsort(probs)[-k:]
    filtered = np.zeros_like(probs)
    filtered[keep_indices] = probs[keep_indices]
    return filtered / filtered.sum()


def filter_top_p(probabilities: np.ndarray, p: Optional[float]) -> np.ndarray:
    """Keep the smallest set of top tokens whose cumulative probability reaches p.

    Parameters
    ----------
    probabilities:
        Probability distribution.
    p:
        Nucleus threshold. None keeps all.

    Returns
    -------
    np.ndarray
        Filtered probability distribution.
    """
    probs = np.asarray(probabilities, dtype=float)
    if p is None or p >= 1.0:
        return probs / probs.sum()
    if p <= 0:
        raise ValueError("p must be greater than 0 or None")

    sorted_indices = np.argsort(probs)[::-1]
    sorted_probs = probs[sorted_indices]
    cumulative = np.cumsum(sorted_probs)

    keep_sorted = cumulative <= p
    keep_sorted[0] = True
    if not keep_sorted.all():
        first_above = int(np.argmax(cumulative > p))
        keep_sorted[first_above] = True

    keep_indices = sorted_indices[keep_sorted]
    filtered = np.zeros_like(probs)
    filtered[keep_indices] = probs[keep_indices]
    return filtered / filtered.sum()


def decoding_distribution(
    logits: Sequence[float],
    temperature: float = 1.0,
    top_k: Optional[int] = None,
    top_p: Optional[float] = None,
) -> np.ndarray:
    """Convert logits into a probability distribution after decoding controls.

    Parameters
    ----------
    logits:
        Raw scores for candidate tokens.
    temperature:
        Temperature value.
    top_k:
        Optional top-k cutoff.
    top_p:
        Optional nucleus sampling cutoff.

    Returns
    -------
    np.ndarray
        Final probability distribution.
    """
    adjusted = apply_temperature(np.array(logits, dtype=float), temperature)
    probs = softmax(adjusted)
    probs = filter_top_k(probs, top_k)
    probs = filter_top_p(probs, top_p)
    return probs


def sample_token(
    candidates: Sequence[str],
    probabilities: Sequence[float],
    seed: int = 123,
) -> str:
    """Sample one token from a candidate distribution.

    Parameters
    ----------
    candidates:
        Candidate token strings.
    probabilities:
        Probability distribution.
    seed:
        Random seed.

    Returns
    -------
    str
        Selected token.
    """
    rng = np.random.default_rng(seed)
    return str(rng.choice(np.array(candidates), p=np.array(probabilities, dtype=float)))


@dataclass
class ContextBudget:
    """Summary of context-window usage."""

    context_limit: int
    reserved_output_tokens: int
    used_input_tokens: int
    available_input_tokens: int
    remaining_input_tokens: int
    utilization_percent: float
    segment_counts: Dict[str, int]


def calculate_context_budget(
    segments: Dict[str, str],
    context_limit: int = 128_000,
    reserved_output_tokens: int = 1_000,
    encoding_name: str = "o200k_base",
) -> ContextBudget:
    """Calculate how much of a context window is consumed by prompt segments.

    Parameters
    ----------
    segments:
        Named text segments, such as system instructions and retrieved context.
    context_limit:
        Total model context limit.
    reserved_output_tokens:
        Tokens reserved for the model's answer.
    encoding_name:
        Tokenizer encoding name.

    Returns
    -------
    ContextBudget
        Context-window usage summary.
    """
    if reserved_output_tokens >= context_limit:
        raise ValueError("reserved_output_tokens must be smaller than context_limit")

    segment_counts = {
        name: count_tokens(text, encoding_name=encoding_name)
        for name, text in segments.items()
    }
    used_input_tokens = sum(segment_counts.values())
    available_input_tokens = context_limit - reserved_output_tokens
    remaining_input_tokens = available_input_tokens - used_input_tokens
    utilization = (used_input_tokens / available_input_tokens) * 100

    return ContextBudget(
        context_limit=context_limit,
        reserved_output_tokens=reserved_output_tokens,
        used_input_tokens=used_input_tokens,
        available_input_tokens=available_input_tokens,
        remaining_input_tokens=remaining_input_tokens,
        utilization_percent=utilization,
        segment_counts=segment_counts,
    )


def choose_llm_customization_strategy(
    requirement: str,
    has_private_knowledge: bool,
    needs_style_change: bool,
    needs_new_skill_pattern: bool,
    has_many_examples: bool,
) -> str:
    """Suggest whether prompting, RAG, or fine-tuning is the better fit.

    Parameters
    ----------
    requirement:
        Short description of the desired change.
    has_private_knowledge:
        Whether the model needs access to private/fresh facts.
    needs_style_change:
        Whether tone/format/persona consistency is the main goal.
    needs_new_skill_pattern:
        Whether the desired behavior is a repeated task pattern.
    has_many_examples:
        Whether enough high-quality input/output examples exist.

    Returns
    -------
    str
        Practical recommendation with a short reason.
    """
    if has_private_knowledge:
        return f"Use RAG first for '{requirement}' because the issue is external knowledge, not model weights."
    if needs_new_skill_pattern and has_many_examples:
        return f"Consider PEFT/fine-tuning for '{requirement}' because the model must learn a repeated behavior pattern."
    if needs_style_change and has_many_examples:
        return f"Prompting may work; PEFT is worth testing for '{requirement}' if consistency is critical."
    return f"Start with prompting/evaluation for '{requirement}' before modifying model weights."


def alignment_stage_lookup(stage: str) -> str:
    """Explain the role of a training/alignment stage.

    Parameters
    ----------
    stage:
        One of "pretraining", "instruction_tuning", "rlhf", or "dpo".

    Returns
    -------
    str
        Plain-English description.
    """
    normalized = stage.strip().lower().replace("-", "_").replace(" ", "_")
    descriptions = {
        "pretraining": "Learns broad language patterns by predicting the next token across huge text corpora.",
        "instruction_tuning": "Learns to follow task-style prompts using curated instruction-response examples.",
        "rlhf": "Uses human preference feedback and a reward model to push outputs toward preferred behavior.",
        "dpo": "Optimizes directly from preference pairs without training a separate reward model.",
    }
    return descriptions.get(normalized, "Unknown stage. Try pretraining, instruction_tuning, RLHF, or DPO.")

# Trainer Guide — LLM Anatomy Practical Lab

## Teaching flow

**0–5 min: Set the lab frame**  
Position the notebook as a microscope for the LLM backbone. The goal is not to train a model; the goal is to see each internal stage with small, inspectable examples.

**5–20 min: Tokenizer visualisation**  
Run the token example table. Ask: "Which input becomes surprisingly expensive?" Highlight code, multilingual text, IDs, and typos.

**20–35 min: Toy BPE**  
Train the toy BPE tokenizer and inspect merge history. Keep the explanation concrete: frequent chunks become reusable pieces. Avoid over-claiming that this is exactly how every production tokenizer is trained.

**35–50 min: Embedding lookup**  
Show token IDs becoming rows from a table. Emphasize that the notebook uses random vectors for transparency; real model embeddings are learned from training.

**50–75 min: Self-attention**  
Run the attention section slowly. First show the unmasked score matrix, then the causal mask, then the final attention weights. The key learning is that every output token becomes a weighted mixture of prior token information.

**75–90 min: Decoding controls**  
Use the fake logits table before the API call. This lets the group understand temperature, top-k, and top-p without treating the API as magic.

**90–105 min: Context-window budgeting**  
Use the agent prompt segments to show why agents lose useful information when prompts become crowded. Connect this to memory, retrieval, and tool output management in the next architecture session.

**105–120 min: Fine-tuning and alignment preview**  
Run the lightweight strategy and alignment helper functions. Keep it preview-level. Do not turn this into a fine-tuning session.

**120–145 min: Optional OpenAI experiment**  
Run only when the environment key is ready. Compare low temperature vs high temperature with the same prompt. Skip without penalty if setup time is tight.

**145–160 min: Exercises and recap**  
Have the group attempt one exercise in pairs, then summarize the full path: text → tokens → IDs → embeddings → attention → logits → next token.

## Likely questions and ideal answers

**Why do tokenizers split simple words in odd ways?**  
Because the vocabulary is optimized for frequent reusable chunks, not for human-looking words.

**Are embedding dimensions like "fluffiness" real?**  
No. That is only an analogy. Real dimensions are distributed and not usually human-interpretable one by one.

**Does attention mean the model understands language?**  
Attention is a mechanism for mixing information across tokens. Understanding is an emergent behavior from training, architecture, data, and decoding.

**Why does a model sometimes change answers at higher temperature?**  
Higher temperature flattens the probability distribution, making less likely tokens more likely to be sampled.

**Is top-k better than top-p?**  
Neither is universally better. Top-k fixes the number of candidates; top-p adapts the candidate set based on cumulative probability.

**Why not always use the largest context window?**  
Longer context can increase cost and latency, and irrelevant context can distract the model. Good context selection still matters.

**Is fine-tuning the answer to hallucination?**  
Not usually. If the problem is missing or fresh knowledge, retrieval and evaluation are usually better first steps.

**What is DPO in one sentence?**  
DPO trains from preference pairs directly, pushing preferred answers up and rejected answers down without a separate reward model.

## Common errors and fixes

**Notebook imports fail**  
Confirm the active kernel uses the same environment where `pip install -r requirements.txt` was run.

**tiktoken cannot load an encoding**  
Switch `TOKEN_ENCODING` in `.env` to `cl100k_base`, restart the kernel, and rerun.

**OpenAI call fails with authentication error**  
Check that `.env` is in the project root and that the key has no quotes or trailing spaces.

**Rate limit or quota error**  
Skip the optional API section. All core concepts are local.

**Plots appear blank**  
Rerun the cell after restarting the kernel. In some IDEs, output may appear below the cell only after execution completes.

## Demo timing

The full notebook is designed for ~55 minutes of practical time if the trainer runs selected cells and explains outputs. It can expand to ~75 minutes if all exercises are attempted live.

## What to skip if running short

1. Skip the optional OpenAI live generation calls.
2. Skip the second BPE application example.
3. Keep only one context-window scenario.
4. Assign exercises as post-class practice.

Do not skip the tokenizer table, causal attention matrix, or decoding controls. Those are the practical anchors.

## Extension ideas

- Replace the sample prompt segments with a real customer-support policy.
- Compare `o200k_base` with `cl100k_base`.
- Add a second attention head and compare attention patterns.
- Build a mini "prompt budget linter" that warns when retrieved context is too long.
- Try the optional OpenAI experiment with three different business tasks: support, sales copy, and technical explanation.

# VoiceBot with Avatar

A **real-time voice bot** using **LiveKit** infrastructure with an animated avatar.

## Architecture

```
┌─────────────────┐      ┌──────────────┐      ┌────────────────────┐
│   index.html    │─────▶│   api.py     │      │  LiveKit Cloud     │
│  (Browser UI)   │      │  (Flask API) │      │  (wss://...)       │
└────────┬────────┘      └──────────────┘      └─────────┬──────────┘
         │                      │                        │
         │  1. Get JWT Token    │                        │
         └──────────────────────┘                        │
         │                                               │
         │  2. Connect via WebSocket ───────────────────▶│
         │                                               │
         │  3. Audio streams both ways ◀─────────────────│
         │                                    ┌──────────┴──────────┐
         │                                    │      agent.py       │
         │                                    │  (Voice AI Agent)   │
         └────────────────────────────────────┴─────────────────────┘
```

## Components

### 1. `agent.py` – Voice AI Agent
The brain of the bot, using LiveKit Agents SDK:
- **STT** – OpenAI Whisper for speech-to-text
- **LLM** – GPT-4o-mini for responses
- **TTS** – Cartesia Sonic-2 for text-to-speech (high quality voice)
- **VAD** – Silero for voice activity detection
- **Noise Cancellation** – Filters background noise

### 2. `api.py` – Token Server (Flask)
- Generates **JWT tokens** for authenticated LiveKit access
- Endpoint: `GET /getToken?name=guest` → returns `{token, room, identity}`

### 3. `index.html` – Web UI
- Simple browser interface with Join/Leave buttons
- Connects to LiveKit Cloud via WebSocket
- Captures user's microphone, plays bot's audio response
- Shows animated avatar GIF when connected

### 4. `Dockerfile` – Containerization
Packages everything for deployment with Python 3.12.

## Required Environment Variables

Create a `.env` file:

```bash
LIVEKIT_API_KEY=your_api_key
LIVEKIT_API_SECRET=your_api_secret
OPENAI_API_KEY=your_openai_key
CARTESIA_API_KEY=your_cartesia_key
LIVEKIT_URL=wss://your-server.livekit.cloud
```

## Setup & Run

### 1. Create Virtual Environment

```bash
# Option A: virtualenv
virtualenv venv
source venv/bin/activate

# Option B: conda
conda create -n voicebot python=3.11 -y
conda activate voicebot
```

### 2. Install Dependencies

```bash
pip install -r requirements.txt
pip install "livekit-agents[openai,cartesia,silero,turn-detector]~=1.0" "livekit-plugins-noise-cancellation~=0.2" "python-dotenv"
```

### 3. Download Required Model Files

```bash
python agent.py download-files
```

### 4. Run the Application

**Terminal 1** – Start the token server:
```bash
python api.py
```

**Terminal 2** – Start the voice agent:
```bash
python agent.py start
```

### 5. Open in Browser

Open `index.html` in your browser and click **Join** to start talking to the bot.

# run this to stop all services
pkill -f "python api.py" ; pkill -f "python agent.py" ; pkill -f "python -m http.server 8080"
## Docker Deployment

```bash
docker build -t voicebot-avatar .
docker run -p 5001:5001 -p 8080:8080 --env-file .env voicebot-avatar
```
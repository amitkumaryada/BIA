# Voicebot with RAG

A **voice-enabled AI assistant** that uses **Retrieval-Augmented Generation (RAG)** to answer questions from your own documents. It combines vector search with OpenAI's Realtime API for voice conversations.

## Architecture Overview

```
PDF Documents → Chunks → Embeddings → FIASS Vector Store: KB
                                          ↓
User Voice Input → Transcription → Query → RAG Retrieval → GPT-4o → Audio Response
```

## Key Components

### 1. Knowledge Base Setup
- **FAISS Vector Store** - Local vector store 
- **SentenceTransformers** (`all-MiniLM-L6-v2`) - Creates 384-dim embeddings
- **PyPDF2** - Extracts text from PDFs
- Chunks PDFs into 1000-char segments with 200-char overlap

### 2. RAG Pipeline
- `retrieve_documents()` - Semantic search against FAISS with cosine similarity
- Returns top-k documents with score threshold of 0.6
- Combines retrieved context with user query for GPT-4o

### 3. Voice Bot
- Uses **OpenAI Realtime API** (`gpt-4o-realtime-preview`) via WebSocket
- **PyAudio** for microphone input/speaker output
- Whisper for speech-to-text transcription
- Real-time audio streaming with base64 encoding

## Dependencies

| Package | Purpose |
|---------|---------|
| `openai` | GPT-4o and Realtime API |
| `FAISS` | Vector database |
| `sentence-transformers` | Embeddings |
| `pyaudio` | Audio I/O |
| `PyPDF2` | PDF parsing |
| `websocket-client` | WebSocket connection |

## Setup & Run

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

<!-- 2. **Start Qdrant:**
   ```bash
   docker run -p 6333:6333 -p 6334:6334 \
     -v "$(pwd)/qdrant_storage:/qdrant/storage:z" \
     qdrant/qdrant
   ``` -->

3. **Upload PDFs** to populate the knowledge base (run cells 1-3 in the notebook). keep all the pdf files in the data folder 

4. **Set your OpenAI API key** in the notebook

5. **Run the VoiceBot** - Execute the `GPT4oVoiceBot` class to start voice conversations

## How It Works

The bot listens to your voice, transcribes it using Whisper, retrieves relevant document chunks from faiss, and responds with synthesized speech—all enhanced by your uploaded course materials.

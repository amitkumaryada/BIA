"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

import argparse
import json
from datetime import datetime
from pathlib import Path

from playwright.sync_api import sync_playwright

from .apply_orchestrator import run_apply_flow
from .config import ROOT, load_blocklist, load_candidate_profile, load_env, load_role_overrides, load_search_prefs
from .db import Database
from .job_discovery import discover_jobs
from .job_scoring import score_job
from .reporting import send_email_summary, write_applications_csv, write_jobs_csv, write_run_log
from .resume_ingestion import extract_resume_profile, read_resume_text
from .role_inference import infer_role_families
from .scheduler import start_scheduler


def execute_run() -> None:
    env = load_env()
    run_id = datetime.now().strftime("%Y%m%d_%H%M")

    db = Database(ROOT / "state" / "job_agent.db")
    if not env["automation_enabled"]:
        db.set_run_status(run_id, "skipped", "AUTOMATION_ENABLED=false")
        return

    candidate = load_candidate_profile()
    prefs = load_search_prefs()
    role_overrides = load_role_overrides(prefs)

    resume_path_pdf = ROOT / "data" / "resume.pdf"
    resume_path_docx = ROOT / "data" / "resume.docx"
    resume_path = resume_path_pdf if resume_path_pdf.exists() else resume_path_docx

    resume_profile = {"skills": [], "titles": [], "years_experience": 0, "domains": []}
    if resume_path.exists():
        resume_profile = extract_resume_profile(read_resume_text(resume_path))

    role_families = infer_role_families(candidate, resume_profile, role_overrides)

    company_blocklist = load_blocklist(ROOT / "config" / "company_blocklist.txt")
    domain_blocklist = load_blocklist(ROOT / "config" / "domain_blocklist.txt")

    negative_keywords = prefs.get("negative_keywords", [])
    min_score = float(prefs.get("min_score_to_qualify", 55))
    max_jobs_per_role = int(prefs.get("max_jobs_per_role", 50))
    location = prefs.get("preferred_locations", ["India"])[0]

    all_scored = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        context = browser.new_context()
        page = context.new_page()

        for role in role_families:
            jobs = discover_jobs(page, role, location, max_jobs_per_role)
            for j in jobs:
                if j.company.lower() in company_blocklist:
                    continue
                if any(dom in j.url.lower() for dom in domain_blocklist):
                    continue
                scored = score_job(j, role, candidate, negative_keywords, min_score)
                all_scored.append(scored)

        all_scored.sort(key=lambda x: x.score, reverse=True)

        results, run_status, run_reason = run_apply_flow(
            page=page,
            db=db,
            run_id=run_id,
            candidate=candidate,
            scored_jobs=all_scored,
            dry_run=env["dry_run"],
            max_daily_submissions=env["max_daily_submissions"],
            dedupe_window_days=env["dedupe_window_days"],
        )

        context.close()
        browser.close()

    db.set_run_status(run_id, run_status, run_reason)

    ts = datetime.now().strftime("%Y%m%d_%H%M")
    jobs_csv = ROOT / "out" / f"jobs_found_{ts}.csv"
    apps_csv = ROOT / "out" / f"applications_{ts}.csv"
    log_json = ROOT / "out" / f"run_log_{ts}.json"

    write_jobs_csv(jobs_csv, all_scored)
    write_applications_csv(apps_csv, results)
    write_run_log(
        log_json,
        {
            "run_id": run_id,
            "status": run_status,
            "reason": run_reason,
            "dry_run": env["dry_run"],
            "jobs_found": len(all_scored),
            "qualified": sum(1 for x in all_scored if x.qualified),
            "applications": len(results),
        },
    )
    send_email_summary(env, run_id, all_scored, results, run_status, run_reason)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mode", choices=["run-once", "scheduler"], default="run-once")
    args = parser.parse_args()

    if args.mode == "run-once":
        execute_run()
    else:
        env = load_env()
        start_scheduler(execute_run, env)


if __name__ == "__main__":
    main()

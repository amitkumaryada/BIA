"""Module for LinkedIn job agent functionality."""

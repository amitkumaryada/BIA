"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

import csv
import json
import smtplib
from collections import Counter
from datetime import datetime
from email.mime.text import MIMEText
from pathlib import Path

from .models import ApplicationResult, JobPosting, ScoredJob


def write_jobs_csv(path: Path, jobs: list[ScoredJob]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["job_id", "title", "company", "location", "url", "score", "qualified", "reasons"])
        for item in jobs:
            w.writerow([
                item.job.job_id,
                item.job.title,
                item.job.company,
                item.job.location,
                item.job.url,
                f"{item.score:.2f}",
                item.qualified,
                " | ".join(item.reasons),
            ])


def write_applications_csv(path: Path, results: list[ApplicationResult]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["run_id", "timestamp", "job_id", "title", "company", "status", "reason", "score", "url"])
        for r in results:
            w.writerow([r.run_id, r.timestamp.isoformat(), r.job_id, r.title, r.company, r.status, r.reason, r.score, r.url])


def write_run_log(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def send_email_summary(env: dict, run_id: str, jobs: list[ScoredJob], results: list[ApplicationResult], run_status: str, reason: str = "") -> None:
    if not env.get("smtp_username") or not env.get("smtp_app_password"):
        return

    status_counts = Counter(r.status for r in results)
    body = (
        f"Run ID: {run_id}\n"
        f"Status: {run_status}\n"
        f"Reason: {reason}\n\n"
        f"Found: {len(jobs)}\n"
        f"Qualified: {sum(1 for j in jobs if j.qualified)}\n"
        f"Attempted: {len(results)}\n"
        f"Submitted: {status_counts.get('submitted', 0) + status_counts.get('dry_run_submitted', 0)}\n"
        f"Skipped: {status_counts.get('skipped', 0)}\n"
        f"Failed: {status_counts.get('failed', 0)}\n"
    )

    msg = MIMEText(body)
    msg["Subject"] = f"Job Agent Summary {datetime.utcnow().strftime('%Y-%m-%d %H:%M')}"
    msg["From"] = env.get("email_from")
    msg["To"] = env.get("email_to")

    with smtplib.SMTP(env["smtp_host"], env["smtp_port"]) as server:
        server.starttls()
        server.login(env["smtp_username"], env["smtp_app_password"])
        server.sendmail(env.get("email_from"), [env.get("email_to")], msg.as_string())

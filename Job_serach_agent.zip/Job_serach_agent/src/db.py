"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

from .models import ApplicationResult, JobPosting


SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs_seen (
  job_id TEXT PRIMARY KEY,
  company TEXT NOT NULL,
  title TEXT NOT NULL,
  seen_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS applications (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id TEXT NOT NULL,
  job_id TEXT NOT NULL,
  company TEXT NOT NULL,
  title TEXT NOT NULL,
  status TEXT NOT NULL,
  reason TEXT,
  score REAL,
  url TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS run_status (
  run_id TEXT PRIMARY KEY,
  status TEXT NOT NULL,
  reason TEXT,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS failures (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id TEXT NOT NULL,
  job_id TEXT,
  stage TEXT NOT NULL,
  message TEXT NOT NULL,
  created_at TEXT NOT NULL
);
"""


class Database:
    def __init__(self, db_path: Path):
        db_path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    def mark_job_seen(self, job: JobPosting) -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO jobs_seen(job_id, company, title, seen_at) VALUES(?,?,?,?)",
            (job.job_id, job.company, job.title, datetime.now(timezone.utc).isoformat()),
        )
        self.conn.commit()

    def already_applied_within_days(self, job: JobPosting, days: int) -> bool:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        row = self.conn.execute(
            """
            SELECT 1 FROM applications
            WHERE company = ? AND title = ?
              AND status IN ('submitted', 'dry_run_submitted')
              AND created_at >= ?
            LIMIT 1
            """,
            (job.company, job.title, cutoff),
        ).fetchone()
        return row is not None

    def count_submissions_today(self) -> int:
        start = datetime.now(timezone.utc).strftime("%Y-%m-%d")
        row = self.conn.execute(
            """
            SELECT COUNT(*) AS c FROM applications
            WHERE (status = 'submitted' OR status = 'dry_run_submitted')
              AND substr(created_at,1,10) = ?
            """,
            (start,),
        ).fetchone()
        return int(row["c"])

    def add_application(self, result: ApplicationResult) -> None:
        self.conn.execute(
            """
            INSERT INTO applications(run_id, job_id, company, title, status, reason, score, url, created_at)
            VALUES(?,?,?,?,?,?,?,?,?)
            """,
            (
                result.run_id,
                result.job_id,
                result.company,
                result.title,
                result.status,
                result.reason,
                result.score,
                result.url,
                result.timestamp.isoformat(),
            ),
        )
        self.conn.commit()

    def add_failure(self, run_id: str, stage: str, message: str, job_id: str = "") -> None:
        self.conn.execute(
            "INSERT INTO failures(run_id, job_id, stage, message, created_at) VALUES(?,?,?,?,?)",
            (run_id, job_id, stage, message, datetime.now(timezone.utc).isoformat()),
        )
        self.conn.commit()

    def set_run_status(self, run_id: str, status: str, reason: str = "") -> None:
        self.conn.execute(
            "INSERT OR REPLACE INTO run_status(run_id, status, reason, created_at) VALUES(?,?,?,?)",
            (run_id, status, reason, datetime.now(timezone.utc).isoformat()),
        )
        self.conn.commit()

"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

import re
from pathlib import Path

import docx
import pdfplumber


SKILL_CANDIDATES = {
    "python", "sql", "excel", "power bi", "tableau", "pandas", "machine learning",
    "deep learning", "nlp", "aws", "azure", "gcp", "spark", "airflow", "docker",
}

TITLE_CANDIDATES = {
    "data analyst", "business analyst", "software engineer", "machine learning engineer",
    "data scientist", "ai engineer", "backend engineer", "product analyst",
}


def _read_pdf(path: Path) -> str:
    text_chunks = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            text_chunks.append(page.extract_text() or "")
    return "\n".join(text_chunks)


def _read_docx(path: Path) -> str:
    doc = docx.Document(path)
    return "\n".join(p.text for p in doc.paragraphs)


def read_resume_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return _read_pdf(path)
    if suffix == ".docx":
        return _read_docx(path)
    raise ValueError(f"Unsupported resume format: {suffix}")


def extract_resume_profile(text: str) -> dict:
    lower = text.lower()
    skills = sorted({s for s in SKILL_CANDIDATES if s in lower})
    titles = sorted({t for t in TITLE_CANDIDATES if t in lower})
    years = 0
    year_matches = re.findall(r"(\d+)\+?\s+years", lower)
    if year_matches:
        years = max(int(y) for y in year_matches)

    domains = []
    for d in ["fintech", "healthcare", "ecommerce", "saas", "banking"]:
        if d in lower:
            domains.append(d)

    return {
        "skills": skills,
        "titles": titles,
        "years_experience": years,
        "domains": domains,
    }

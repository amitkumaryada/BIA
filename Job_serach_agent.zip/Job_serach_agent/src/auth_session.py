"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

from pathlib import Path

from cryptography.fernet import Fernet
from playwright.sync_api import Browser, Page


def _fernet(key: str) -> Fernet:
    return Fernet(key.encode("utf-8"))


def save_encrypted_session(storage_state_json: str, out_file: Path, key: str) -> None:
    out_file.parent.mkdir(parents=True, exist_ok=True)
    payload = _fernet(key).encrypt(storage_state_json.encode("utf-8"))
    out_file.write_bytes(payload)


def load_encrypted_session(in_file: Path, key: str) -> str:
    payload = in_file.read_bytes()
    return _fernet(key).decrypt(payload).decode("utf-8")


def ensure_login(page: Page, session_ready: bool = False) -> bool:
    # Manual login handoff for first run.
    if session_ready:
        return True
    page.goto("https://www.linkedin.com/login", wait_until="domcontentloaded")
    return False

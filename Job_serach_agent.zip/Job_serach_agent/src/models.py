"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class CandidateProfile:
    name: str
    email: str
    phone: str
    years_experience: int
    education: str
    notice_period_days: int
    work_authorization_country: str
    work_authorized: bool
    default_answers: dict[str, Any] = field(default_factory=dict)
    skills: list[str] = field(default_factory=list)
    titles: list[str] = field(default_factory=list)
    domains: list[str] = field(default_factory=list)


@dataclass
class RoleFamily:
    name: str
    title_aliases: list[str]
    must_have_skills: list[str]


@dataclass
class JobPosting:
    job_id: str
    title: str
    company: str
    location: str
    url: str
    posted_text: str = ""
    easy_apply: bool = True
    description: str = ""
    source_role: str = ""


@dataclass
class ScoredJob:
    job: JobPosting
    score: float
    qualified: bool
    reasons: list[str] = field(default_factory=list)


@dataclass
class ApplicationResult:
    run_id: str
    timestamp: datetime
    job_id: str
    title: str
    company: str
    status: str
    reason: str = ""
    score: float = 0.0
    url: str = ""

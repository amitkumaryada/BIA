"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

from .models import CandidateProfile, RoleFamily


def infer_role_families(
    candidate: CandidateProfile,
    resume_profile: dict,
    role_overrides: list[RoleFamily],
) -> list[RoleFamily]:
    inferred: list[RoleFamily] = []

    title_pool = set(candidate.titles) | set(resume_profile.get("titles", []))
    skill_pool = set(candidate.skills) | set(resume_profile.get("skills", []))

    for t in sorted(title_pool):
        inferred.append(
            RoleFamily(
                name=t.title(),
                title_aliases=[t],
                must_have_skills=sorted(skill_pool)[:6],
            )
        )

    if not inferred and role_overrides:
        return role_overrides[:5]

    if inferred and len(inferred) < 3 and role_overrides:
        # Keep inferred roles first, then backfill up to 5 from overrides.
        existing = {r.name.lower() for r in inferred}
        for r in role_overrides:
            if r.name.lower() not in existing:
                inferred.append(r)
            if len(inferred) >= 5:
                break

    return inferred[:5]

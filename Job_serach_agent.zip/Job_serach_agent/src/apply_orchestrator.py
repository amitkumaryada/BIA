"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

import random
from datetime import datetime, timezone

from tenacity import RetryError, retry, stop_after_attempt, wait_random

from .db import Database
from .form_filler import fill_easy_apply_form
from .models import ApplicationResult, CandidateProfile, ScoredJob


class CaptchaCheckpointDetected(Exception):
    pass


def _detect_checkpoint(page) -> bool:
    # Use URL + targeted text hints; broad keyword-only checks create false positives.
    url = (page.url or "").lower()
    if "checkpoint" in url or "challenge" in url:
        return True
    flags = ["verify your identity", "security verification", "captcha challenge"]
    body = page.content().lower()
    return any(x in body for x in flags)


def _is_captcha_retry_error(exc: Exception) -> bool:
    if not isinstance(exc, RetryError):
        return False
    try:
        last_exc = exc.last_attempt.exception()
    except Exception:  # noqa: BLE001
        return False
    return isinstance(last_exc, CaptchaCheckpointDetected)


@retry(stop=stop_after_attempt(2), wait=wait_random(min=1, max=3))
def _attempt_submit(page, candidate: CandidateProfile, scored: ScoredJob, dry_run: bool) -> str:
    page.goto(scored.job.url, wait_until="domcontentloaded")
    page.wait_for_timeout(random.randint(900, 2200))

    if _detect_checkpoint(page):
        raise CaptchaCheckpointDetected("LinkedIn checkpoint/captcha detected")

    apply_btn = page.locator("button:has-text('Easy Apply')")
    if not apply_btn.count():
        return "skipped"

    apply_btn.first.click()
    page.wait_for_timeout(random.randint(600, 1200))
    return fill_easy_apply_form(page, candidate, scored.job, dry_run)


def run_apply_flow(
    page,
    db: Database,
    run_id: str,
    candidate: CandidateProfile,
    scored_jobs: list[ScoredJob],
    dry_run: bool,
    max_daily_submissions: int,
    dedupe_window_days: int,
) -> tuple[list[ApplicationResult], str, str]:
    results: list[ApplicationResult] = []
    submitted_today = db.count_submissions_today()

    for sj in scored_jobs:
        if not sj.qualified:
            continue
        if submitted_today >= max_daily_submissions:
            break
        if db.already_applied_within_days(sj.job, dedupe_window_days):
            continue

        try:
            status = _attempt_submit(page, candidate, sj, dry_run)
            if status in {"submitted", "dry_run_submitted"}:
                submitted_today += 1
            reason = ""
        except CaptchaCheckpointDetected as e:
            db.add_failure(run_id, "apply", str(e), sj.job.job_id)
            return results, "blocked", str(e)
        except RetryError as e:
            if _is_captcha_retry_error(e):
                reason = "LinkedIn checkpoint/captcha detected after retries"
                db.add_failure(run_id, "apply", reason, sj.job.job_id)
                return results, "blocked", reason
            status = "failed"
            reason = f"RetryError: {e}"
            db.add_failure(run_id, "apply", reason, sj.job.job_id)
        except Exception as e:  # noqa: BLE001
            status = "failed"
            reason = str(e)
            db.add_failure(run_id, "apply", reason, sj.job.job_id)

        record = ApplicationResult(
            run_id=run_id,
            timestamp=datetime.now(timezone.utc),
            job_id=sj.job.job_id,
            title=sj.job.title,
            company=sj.job.company,
            status=status,
            reason=reason,
            score=sj.score,
            url=sj.job.url,
        )
        db.add_application(record)
        db.mark_job_seen(sj.job)
        results.append(record)

    return results, "success", ""

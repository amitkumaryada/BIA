"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

from rapidfuzz import fuzz

from .models import CandidateProfile, JobPosting, RoleFamily, ScoredJob


def score_job(
    job: JobPosting,
    role: RoleFamily,
    candidate: CandidateProfile,
    negative_keywords: list[str],
    min_score: float,
) -> ScoredJob:
    text_blob = f"{job.title} {job.description}".lower()
    title_score = max((fuzz.token_set_ratio(job.title.lower(), alias) for alias in role.title_aliases), default=0)

    matched_skills = sum(1 for s in set(candidate.skills + role.must_have_skills) if s and s in text_blob)
    skill_score = min(100, matched_skills * 12)

    location_score = 100 if "india" in job.location.lower() else 40

    seniority_score = 80
    if candidate.years_experience <= 2 and any(x in text_blob for x in ["senior", "lead", "principal"]):
        seniority_score = 30

    penalty = 0
    for neg in negative_keywords:
        if neg.lower() in text_blob:
            penalty += 20

    final = 0.35 * title_score + 0.35 * skill_score + 0.2 * location_score + 0.1 * seniority_score - penalty
    final = max(0.0, min(100.0, final))

    reasons = [
        f"title={title_score:.1f}",
        f"skills={skill_score:.1f}",
        f"location={location_score:.1f}",
        f"seniority={seniority_score:.1f}",
        f"penalty={penalty:.1f}",
    ]

    return ScoredJob(job=job, score=final, qualified=final >= min_score, reasons=reasons)

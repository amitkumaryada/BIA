"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

import os
from pathlib import Path

import yaml
from dotenv import load_dotenv

from .models import CandidateProfile, RoleFamily


ROOT = Path(__file__).resolve().parent.parent


def _read_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_candidate_profile(path: Path | None = None) -> CandidateProfile:
    path = path or ROOT / "config" / "candidate_profile.yaml"
    data = _read_yaml(path)
    auth = data.get("work_authorization", {})
    return CandidateProfile(
        name=data.get("name", ""),
        email=data.get("email", ""),
        phone=data.get("phone", ""),
        years_experience=int(data.get("years_experience", 0)),
        education=data.get("education", ""),
        notice_period_days=int(data.get("notice_period_days", 0)),
        work_authorization_country=auth.get("country", "India"),
        work_authorized=bool(auth.get("authorized", True)),
        default_answers=data.get("default_answers", {}),
        skills=[str(s).lower() for s in data.get("skills", [])],
        titles=[str(t).lower() for t in data.get("titles", [])],
        domains=[str(d).lower() for d in data.get("domains", [])],
    )


def load_search_prefs(path: Path | None = None) -> dict:
    path = path or ROOT / "config" / "search_prefs.yaml"
    return _read_yaml(path)


def load_role_overrides(search_prefs: dict) -> list[RoleFamily]:
    overrides = search_prefs.get("role_overrides", [])
    return [
        RoleFamily(
            name=entry.get("name", ""),
            title_aliases=[str(x).lower() for x in entry.get("title_aliases", [])],
            must_have_skills=[str(x).lower() for x in entry.get("must_have_skills", [])],
        )
        for entry in overrides
        if entry.get("name")
    ]


def load_env() -> dict:
    load_dotenv(ROOT / ".env")
    return {
        "automation_enabled": os.getenv("AUTOMATION_ENABLED", "true").lower() == "true",
        "dry_run": os.getenv("DRY_RUN", "true").lower() == "true",
        "max_daily_submissions": int(os.getenv("MAX_DAILY_SUBMISSIONS", "20")),
        "dedupe_window_days": int(os.getenv("DEDUPE_WINDOW_DAYS", "7")),
        "retry_max_attempts": int(os.getenv("RETRY_MAX_ATTEMPTS", "2")),
        "timezone": os.getenv("TIMEZONE", "Asia/Kolkata"),
        "schedule_hour_1": int(os.getenv("SCHEDULE_HOUR_1", "9")),
        "schedule_min_1": int(os.getenv("SCHEDULE_MIN_1", "0")),
        "schedule_hour_2": int(os.getenv("SCHEDULE_HOUR_2", "18")),
        "schedule_min_2": int(os.getenv("SCHEDULE_MIN_2", "0")),
        "smtp_host": os.getenv("SMTP_HOST", "smtp.gmail.com"),
        "smtp_port": int(os.getenv("SMTP_PORT", "587")),
        "smtp_username": os.getenv("SMTP_USERNAME", ""),
        "smtp_app_password": os.getenv("SMTP_APP_PASSWORD", ""),
        "email_from": os.getenv("EMAIL_FROM", ""),
        "email_to": os.getenv("EMAIL_TO", ""),
        "session_encryption_key": os.getenv("SESSION_ENCRYPTION_KEY", ""),
    }


def load_blocklist(path: Path) -> set[str]:
    if not path.exists():
        return set()
    return {
        line.strip().lower()
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.strip() and not line.strip().startswith("#")
    }

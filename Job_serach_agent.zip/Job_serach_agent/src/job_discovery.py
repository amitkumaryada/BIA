"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

import random
from urllib.parse import quote_plus

from playwright.sync_api import Page

from .models import JobPosting, RoleFamily


def _linkedin_search_url(query: str, location: str) -> str:
    return (
        "https://www.linkedin.com/jobs/search/?"
        f"keywords={quote_plus(query)}&location={quote_plus(location)}&f_AL=true"
    )


def discover_jobs(
    page: Page,
    role: RoleFamily,
    location: str,
    max_jobs: int,
) -> list[JobPosting]:
    query = role.title_aliases[0] if role.title_aliases else role.name
    page.goto(_linkedin_search_url(query, location), wait_until="domcontentloaded")
    page.wait_for_timeout(random.randint(1200, 2500))

    cards = page.locator("li div.base-card").all()
    jobs: list[JobPosting] = []

    for c in cards[:max_jobs]:
        title = c.locator("h3").inner_text(timeout=1000) if c.locator("h3").count() else ""
        company = c.locator("h4").inner_text(timeout=1000) if c.locator("h4").count() else ""
        loc = c.locator(".job-search-card__location").inner_text(timeout=1000) if c.locator(".job-search-card__location").count() else location
        link = c.locator("a.base-card__full-link").get_attribute("href") or ""
        job_id = link.split("currentJobId=")[-1] if "currentJobId=" in link else f"{company}-{title}".lower().replace(" ", "-")

        jobs.append(
            JobPosting(
                job_id=job_id,
                title=title.strip(),
                company=company.strip(),
                location=loc.strip(),
                url=link,
                easy_apply=True,
                source_role=role.name,
            )
        )

    return jobs

"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

from playwright.sync_api import Page

from .models import CandidateProfile, JobPosting


def fill_easy_apply_form(page: Page, candidate: CandidateProfile, job: JobPosting, dry_run: bool) -> str:
    # This covers common patterns and intentionally keeps safe defaults.
    if page.locator("input[type='tel']").count():
        page.locator("input[type='tel']").first.fill(candidate.phone)

    if page.locator("input[aria-label*='years of experience' i]").count():
        page.locator("input[aria-label*='years of experience' i]").first.fill(str(candidate.years_experience))

    if page.locator("textarea").count() and candidate.default_answers.get("cover_letter_template"):
        page.locator("textarea").first.fill(candidate.default_answers["cover_letter_template"])

    if dry_run:
        return "dry_run_submitted"

    submit_btn = page.locator("button:has-text('Submit application')")
    if submit_btn.count():
        submit_btn.first.click()
        return "submitted"

    return "skipped"

"""Module for LinkedIn job agent functionality."""
from __future__ import annotations

from apscheduler.schedulers.blocking import BlockingScheduler


def start_scheduler(run_once, env: dict) -> None:
    scheduler = BlockingScheduler(timezone=env["timezone"])
    scheduler.add_job(
        run_once,
        "cron",
        hour=env["schedule_hour_1"],
        minute=env["schedule_min_1"],
        id="run_1",
        replace_existing=True,
    )
    scheduler.add_job(
        run_once,
        "cron",
        hour=env["schedule_hour_2"],
        minute=env["schedule_min_2"],
        id="run_2",
        replace_existing=True,
    )
    scheduler.start()

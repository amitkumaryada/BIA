# LinkedIn Resume-to-Apply Agent (V1)

Automates LinkedIn `Easy Apply` job search and application flow using a resume and candidate profile.

## Features
- Resume parsing (`PDF`/`DOCX`, English-only)
- Role inference from resume + profile
- LinkedIn job discovery (`Easy Apply`, India-focused)
- Relevance scoring (title, skills, seniority, location, negative keywords)
- Auto-apply orchestration with:
  - dry-run mode
  - daily submission cap
  - retry policy
  - duplicate suppression window
  - captcha/checkpoint stop behavior
- SQLite persistence for jobs, applications, failures, and run status
- CSV/JSON run outputs and Gmail summary email
- Twice-daily scheduler support

## Project Structure
- `src/` core implementation
- `config/` YAML and blocklists
- `data/` resume input
- `state/` SQLite + session artifacts
- `out/` run outputs
- `tests/` unit/integration-style tests

## Prerequisites
- Python `3.11+`
- Install dependencies:

```bash
python3 -m pip install -r requirements.txt
```

- Install Playwright browser:

```bash
python3 -m playwright install chromium
```

## Configuration
1. Create env file:

```bash
cp .env.example .env
```

2. Fill `.env` values:
- `AUTOMATION_ENABLED`
- `DRY_RUN=true` for rollout start
- Gmail SMTP credentials (`SMTP_USERNAME`, `SMTP_APP_PASSWORD`)
- `SESSION_ENCRYPTION_KEY`

3. Update:
- `config/candidate_profile.yaml`
- `config/search_prefs.yaml`
- `config/company_blocklist.txt`
- `config/domain_blocklist.txt` (optional)

4. Add resume:
- `data/resume.pdf` or `data/resume.docx`

## Run
- Single run:

```bash
python3 -m src.main --mode run-once
```

- Scheduler mode (twice daily based on `.env`):

```bash
python3 -m src.main --mode scheduler
```

## Testing
```bash
pytest
```

## Output Artifacts
Per run, files are generated under `out/`:
- `jobs_found_YYYYMMDD_HHMM.csv`
- `applications_YYYYMMDD_HHMM.csv`
- `run_log_YYYYMMDD_HHMM.json`

## Notes
- V1 is scoped to LinkedIn `Easy Apply` only.
- Captcha/checkpoint detection halts run and marks status as blocked.
- Keep `DRY_RUN=true` for initial rollout before real submissions.

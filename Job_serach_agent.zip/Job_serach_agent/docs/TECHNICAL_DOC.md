# Technical Documentation: Job Search Agent (LinkedIn Easy Apply V1)

## 1. Purpose
The Job Search Agent automates job discovery and application submission on LinkedIn (`Easy Apply` only) using resume-derived role targeting and profile-based form responses.

V1 objectives:
- Parse resume (`PDF`/`DOCX`, English-only).
- Infer relevant role families.
- Discover Easy Apply roles in India.
- Score and qualify jobs.
- Auto-submit qualified jobs with safety controls.
- Persist state and generate audit outputs (CSV/JSON/email).

## 2. Scope and Constraints
In scope:
- LinkedIn job search pages.
- Easy Apply form handling for common fields.
- Scheduled and one-off execution.
- Dry-run and real-submit modes.

Out of scope (V1):
- External ATS workflows.
- Complex custom assessments.
- Advanced anti-bot bypass mechanisms.
- Multi-language resume parsing.

## 3. High-Level Architecture
Pipeline stages:
1. Config + environment load
2. Resume ingestion
3. Role inference
4. Job discovery
5. Job scoring
6. Apply orchestration
7. Persistence + reporting
8. Optional email summary

```mermaid
flowchart TD
    A[Scheduler / Run Once Trigger] --> B[main.py]
    B --> C[config.py<br/>Load .env + YAML + blocklists]
    B --> D[resume_ingestion.py<br/>Parse PDF/DOCX]
    D --> E[role_inference.py<br/>Build role families]
    C --> E
    E --> F[job_discovery.py<br/>LinkedIn Easy Apply search]
    F --> G[job_scoring.py<br/>Relevance scoring]
    G --> H[apply_orchestrator.py<br/>Dedupe + cap + retry + captcha stop]
    H --> I[form_filler.py<br/>Fill Easy Apply fields]
    H --> J[(SQLite: state/job_agent.db)]
    H --> K[reporting.py<br/>CSV/JSON outputs]
    K --> L[Email Summary<br/>Gmail SMTP]
    M[auth_session.py<br/>Encrypted session helpers] --> B
```

Primary runtime entrypoint:
- `src/main.py`

Core components:
- `src/config.py`: config/env loading and blocklists
- `src/resume_ingestion.py`: resume text extraction + profile extraction
- `src/role_inference.py`: role family generation/fallback
- `src/job_discovery.py`: LinkedIn listings scrape via Playwright
- `src/job_scoring.py`: weighted relevance scoring
- `src/apply_orchestrator.py`: apply flow, retries, limits, stop conditions
- `src/form_filler.py`: Easy Apply field population
- `src/db.py`: SQLite schema and persistence access
- `src/reporting.py`: CSV/JSON artifacts + email summary
- `src/scheduler.py`: APScheduler cron configuration
- `src/auth_session.py`: encrypted session helpers

## 4. Data Contracts
### 4.1 Candidate Profile (`config/candidate_profile.yaml`)
Required fields:
- `name`, `email`, `phone`
- `years_experience`, `education`, `notice_period_days`
- `work_authorization.country`, `work_authorization.authorized`
- `default_answers` (key-value map)
- `skills`, `titles`, `domains`

### 4.2 Search Preferences (`config/search_prefs.yaml`)
Expected keys:
- `preferred_locations`
- `seniority`
- `exclude_keywords`
- `negative_keywords`
- `role_overrides` (list of role family definitions)
- `min_score_to_qualify`
- `max_jobs_per_role`
- `recency_hours`

### 4.3 Role Family (internal)
`RoleFamily` fields:
- `name`
- `title_aliases`
- `must_have_skills`

### 4.4 Job Object (internal)
`JobPosting` fields:
- `job_id`, `title`, `company`, `location`, `url`
- `posted_text`, `easy_apply`, `description`, `source_role`

### 4.5 Application Result (internal)
`ApplicationResult` fields:
- `run_id`, `timestamp`
- `job_id`, `title`, `company`
- `status`, `reason`, `score`, `url`

## 5. Scoring Model
Implemented in `src/job_scoring.py`.

Weighted components:
- Title similarity: 35%
- Skill overlap: 35%
- Location fit: 20%
- Seniority fit: 10%
- Negative keyword penalty: subtractive

Qualification rule:
- Job is qualified if `score >= min_score_to_qualify`.

Notes:
- Location currently boosts India matches.
- Seniority heuristic penalizes senior titles for low experience profiles.

## 6. Persistence Layer (SQLite)
Database file:
- `state/job_agent.db`

Tables:
- `jobs_seen(job_id, company, title, seen_at)`
- `applications(run_id, job_id, company, title, status, reason, score, url, created_at)`
- `run_status(run_id, status, reason, created_at)`
- `failures(run_id, job_id, stage, message, created_at)`

Key behaviors:
- Daily submission count from `applications`.
- Dedupe check over recent successful submissions.
- Run status marked `success`, `blocked`, or `skipped`.

## 7. Orchestration and Safety Controls
Implemented primarily in `src/apply_orchestrator.py` and `src/main.py`.

Controls:
- `AUTOMATION_ENABLED=false` halts execution safely.
- `DRY_RUN=true` simulates submission status (`dry_run_submitted`).
- Daily submission cap (`MAX_DAILY_SUBMISSIONS`).
- Duplicate suppression window (`DEDUPE_WINDOW_DAYS`, default 7).
- Retry attempts for transient failures (`RETRY_MAX_ATTEMPTS`, currently logic uses 2).
- Randomized action delays.
- Captcha/checkpoint detection triggers immediate run block.

Blocked run behavior:
- Failure recorded.
- Run status set to `blocked`.
- Reason included in run log/email.

## 8. Scheduling
Implemented in `src/scheduler.py`.

Scheduler:
- APScheduler `BlockingScheduler`.
- Two cron jobs/day from env values:
  - `SCHEDULE_HOUR_1`, `SCHEDULE_MIN_1`
  - `SCHEDULE_HOUR_2`, `SCHEDULE_MIN_2`
- Timezone controlled by `TIMEZONE` (default `Asia/Kolkata`).

## 9. Reporting and Artifacts
Per-run outputs under `out/`:
- `jobs_found_YYYYMMDD_HHMM.csv`
- `applications_YYYYMMDD_HHMM.csv`
- `run_log_YYYYMMDD_HHMM.json`

Email summary via Gmail SMTP includes:
- Found / qualified / attempted
- Submitted / skipped / failed
- Run status and reason

## 10. Runtime Modes
CLI from `src/main.py`:
- `python3 -m src.main --mode run-once`
- `python3 -m src.main --mode scheduler`

Execution steps (`run-once`):
1. Load env + configs.
2. Validate automation switch.
3. Parse resume (if present).
4. Infer roles.
5. Launch Playwright Chromium context.
6. Discover + score jobs.
7. Apply to qualified jobs with controls.
8. Persist run/application data.
9. Write CSV/JSON outputs.
10. Send summary email (if SMTP configured).

## 11. Session and Authentication
- Current implementation includes encrypted session helper utilities in `src/auth_session.py`.
- First login/manual session bootstrap should be integrated into operational workflow.
- `SESSION_ENCRYPTION_KEY` is required for encrypted session storage.

## 12. Configuration Reference (.env)
Key environment variables:
- `AUTOMATION_ENABLED`
- `DRY_RUN`
- `MAX_DAILY_SUBMISSIONS`
- `DEDUPE_WINDOW_DAYS`
- `RETRY_MAX_ATTEMPTS`
- `TIMEZONE`
- `SCHEDULE_HOUR_1`, `SCHEDULE_MIN_1`
- `SCHEDULE_HOUR_2`, `SCHEDULE_MIN_2`
- `SMTP_HOST`, `SMTP_PORT`
- `SMTP_USERNAME`, `SMTP_APP_PASSWORD`
- `EMAIL_FROM`, `EMAIL_TO`
- `SESSION_ENCRYPTION_KEY`

## 13. Testing Strategy
Current tests in `tests/` cover:
- Resume profile extraction
- Role inference fallback behavior
- Scoring behavior
- Dedupe logic
- Basic pipeline-like integration scenario (non-browser)

Run tests:
```bash
pytest
```

## 14. Known Limitations (Current Implementation)
- LinkedIn selectors are heuristic and may break with UI changes.
- External apply flows are not handled.
- Session bootstrap integration is partial (helper exists; full lifecycle can be hardened).
- Form handling covers common patterns, not all custom question variants.
- Retry count in orchestrator is fixed at 2 in decorator; can be made fully env-driven.

## 15. Hardening Roadmap (Recommended)
1. Replace fragile selectors with resilient locator strategy and fallback chains.
2. Capture screenshots and HTML snapshots for every failed apply attempt.
3. Add explicit config/schema validation with strict typed models.
4. Integrate full session persistence lifecycle into main runtime.
5. Add browser-mocked integration tests for discovery/apply paths.
6. Add metrics export for run quality and failure trends.

## 16. Security and Operations Notes
- Use Gmail App Password, not account password.
- Keep `.env` and session artifacts out of version control.
- Rotate credentials periodically.
- Restrict access to `state/` and `logs/` directories.
- Keep kill switch (`AUTOMATION_ENABLED`) as immediate stop mechanism.

"""Module for LinkedIn job agent functionality."""
from src.job_scoring import score_job
from src.models import CandidateProfile, JobPosting, RoleFamily


def test_pipeline_like_flow_without_browser():
    candidate = CandidateProfile(
        name="A",
        email="a@a.com",
        phone="1",
        years_experience=4,
        education="BTech",
        notice_period_days=30,
        work_authorization_country="India",
        work_authorized=True,
        skills=["python", "sql", "power bi"],
        titles=["data analyst"],
    )
    role = RoleFamily(name="Data Analyst", title_aliases=["data analyst"], must_have_skills=["sql", "excel"])
    jobs = [
        JobPosting(job_id="1", title="Data Analyst", company="A", location="India", url="https://a", description="sql excel dashboard"),
        JobPosting(job_id="2", title="Graphic Designer", company="B", location="India", url="https://b", description="figma photoshop"),
    ]

    scored = [score_job(j, role, candidate, negative_keywords=["internship"], min_score=55) for j in jobs]
    qualified = [s for s in scored if s.qualified]
    assert len(qualified) == 1
    assert qualified[0].job.job_id == "1"

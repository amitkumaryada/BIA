"""Module for LinkedIn job agent functionality."""
from datetime import datetime, timezone

from src.db import Database
from src.models import ApplicationResult, JobPosting


def test_dedupe_blocks_recent_application(tmp_path):
    db = Database(tmp_path / "job_agent.db")
    job = JobPosting(job_id="j1", title="Data Analyst", company="ACME", location="India", url="https://x")

    db.add_application(
        ApplicationResult(
            run_id="r1",
            timestamp=datetime.now(timezone.utc),
            job_id="j1",
            title="Data Analyst",
            company="ACME",
            status="submitted",
        )
    )

    assert db.already_applied_within_days(job, 7) is True

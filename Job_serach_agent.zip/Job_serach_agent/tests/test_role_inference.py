"""Module for LinkedIn job agent functionality."""
from src.models import CandidateProfile, RoleFamily
from src.role_inference import infer_role_families


def _candidate() -> CandidateProfile:
    return CandidateProfile(
        name="A",
        email="a@a.com",
        phone="1",
        years_experience=3,
        education="BTech",
        notice_period_days=30,
        work_authorization_country="India",
        work_authorized=True,
        skills=["python", "sql"],
        titles=["data analyst"],
    )


def test_role_inference_prefers_inferred_titles():
    roles = infer_role_families(
        _candidate(),
        {"titles": ["machine learning engineer"], "skills": ["python"]},
        [RoleFamily(name="Fallback", title_aliases=["fallback"], must_have_skills=["sql"])],
    )
    names = [r.name.lower() for r in roles]
    assert any("data analyst" in n for n in names)


def test_role_inference_uses_overrides_when_sparse():
    c = _candidate()
    c.titles = []
    roles = infer_role_families(
        c,
        {"titles": [], "skills": []},
        [RoleFamily(name="Fallback", title_aliases=["fallback"], must_have_skills=["sql"])],
    )
    assert roles[0].name == "Fallback"

"""Module for LinkedIn job agent functionality."""
from src.job_scoring import score_job
from src.models import CandidateProfile, JobPosting, RoleFamily


def _candidate() -> CandidateProfile:
    return CandidateProfile(
        name="A",
        email="a@a.com",
        phone="1",
        years_experience=5,
        education="BTech",
        notice_period_days=30,
        work_authorization_country="India",
        work_authorized=True,
        skills=["python", "sql", "machine learning"],
    )


def test_job_scoring_relevant_job_scores_higher():
    role = RoleFamily(name="ML Engineer", title_aliases=["machine learning engineer"], must_have_skills=["python", "machine learning"])

    relevant = JobPosting(job_id="1", title="Machine Learning Engineer", company="X", location="Bengaluru, India", url="https://x", description="python machine learning sql")
    irrelevant = JobPosting(job_id="2", title="PHP Developer", company="Y", location="Austin, US", url="https://y", description="php laravel")

    r1 = score_job(relevant, role, _candidate(), ["php"], min_score=55)
    r2 = score_job(irrelevant, role, _candidate(), ["php"], min_score=55)

    assert r1.score > r2.score
    assert r1.qualified is True

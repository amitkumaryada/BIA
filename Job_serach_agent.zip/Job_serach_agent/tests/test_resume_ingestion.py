"""Module for LinkedIn job agent functionality."""
from src.resume_ingestion import extract_resume_profile


def test_extract_resume_profile_basic():
    text = """
    Data Analyst with 5 years experience in fintech and ecommerce.
    Skilled in Python, SQL, Excel and Tableau.
    """
    profile = extract_resume_profile(text)
    assert profile["years_experience"] == 5
    assert "python" in profile["skills"]
    assert "sql" in profile["skills"]
    assert "data analyst" in profile["titles"]
    assert "fintech" in profile["domains"]

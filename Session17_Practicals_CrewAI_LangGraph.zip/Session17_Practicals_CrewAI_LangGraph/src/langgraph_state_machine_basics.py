
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal, Optional

from langgraph.graph import StateGraph, END
from rich.console import Console
from rich.panel import Panel

console = Console()

@dataclass
class FSMState:
    status: Literal["START", "DRAFT", "REVIEW", "DONE"]
    draft: Optional[str] = None
    notes: Optional[str] = None

def make_draft(state: FSMState) -> FSMState:
    return FSMState(status="DRAFT", draft="Draft itinerary created.", notes=state.notes)

def review(state: FSMState) -> FSMState:
    notes = "Add buffer time + clarify budget split."
    return FSMState(status="REVIEW", draft=state.draft, notes=notes)

def finalize(state: FSMState) -> FSMState:
    return FSMState(status="DONE", draft=(state.draft or "") + " ✅ Finalized.", notes=state.notes)

def route_after_review(state: FSMState) -> str:
    return "finalize" if state.notes else END

def main():
    g = StateGraph(FSMState)

    g.add_node("draft", make_draft)
    g.add_node("review", review)
    g.add_node("finalize", finalize)

    g.set_entry_point("draft")
    g.add_edge("draft", "review")
    g.add_conditional_edges("review", route_after_review, {"finalize": "finalize", END: END})
    g.add_edge("finalize", END)

    app = g.compile()

    out = app.invoke(FSMState(status="START"))

    console.print(Panel(str(out), title="Tiny FSM Output"))
    console.print("Teaching note: state schema + routing function controls the workflow.")

if __name__ == "__main__":
    main()

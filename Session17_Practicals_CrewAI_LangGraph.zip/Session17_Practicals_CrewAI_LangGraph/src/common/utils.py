
from __future__ import annotations

import json
from typing import Any
from rich.console import Console
from rich.panel import Panel

console = Console()

def pretty(title: str, obj: Any) -> None:
    if isinstance(obj, (dict, list)):
        content = json.dumps(obj, indent=2, ensure_ascii=False)
    else:
        content = str(obj)
    console.print(Panel.fit(content, title=title))

def safe_int(value: str, default: int) -> int:
    try:
        return int(value)
    except Exception:
        return default


from __future__ import annotations

import os
from dotenv import load_dotenv

load_dotenv()

def get_chat_model():
    """
    Returns a chat model for LangGraph examples.

    Priority:
      1) Ollama (free/local) via ChatOllama if LANGGRAPH_OLLAMA_MODEL is set
      2) OpenAI via ChatOpenAI if OPENAI_API_KEY is set

    Notes:
      - Ollama must be running on http://localhost:11434
      - For OpenAI, set OPENAI_API_KEY and (optionally) OPENAI_MODEL
    """
    ollama_model = os.getenv("LANGGRAPH_OLLAMA_MODEL", "").strip()
    if ollama_model:
        try:
            from langchain_ollama import ChatOllama
        except Exception as e:  # pragma: no cover
            raise RuntimeError(
                "langchain-ollama not installed. Run: pip install -r requirements.txt"
            ) from e

        # Optional override (useful if Ollama runs remotely or on a non-default port)
        base_url = os.getenv("LANGGRAPH_OLLAMA_BASE_URL", "").strip() or None
        try:
            # Newer langchain-ollama supports base_url
            return ChatOllama(model=ollama_model, base_url=base_url) if base_url else ChatOllama(model=ollama_model)
        except TypeError:
            # Older versions may not accept base_url
            return ChatOllama(model=ollama_model)

    openai_key = os.getenv("OPENAI_API_KEY", "").strip()
    if openai_key:
        try:
            from langchain_openai import ChatOpenAI
        except Exception as e:  # pragma: no cover
            raise RuntimeError(
                "langchain-openai not installed. Install it if you want OpenAI:\n"
                "  pip install langchain-openai"
            ) from e

        model = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
        # Cross-version compatibility: some versions expect openai_api_key, some accept api_key
        try:
            return ChatOpenAI(model=model, openai_api_key=openai_key)
        except TypeError:
            return ChatOpenAI(model=model, api_key=openai_key)

    raise RuntimeError(
        "No LLM configured. Either:\n"
        "  - Set LANGGRAPH_OLLAMA_MODEL (recommended) and run Ollama, or\n"
        "  - Set OPENAI_API_KEY (paid).\n"
        "See .env.example"
    )

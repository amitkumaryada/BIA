from __future__ import annotations

import os
from dotenv import load_dotenv

from crewai import Agent, Task, Crew, Process, LLM
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

from .common.utils import safe_int

load_dotenv()
console = Console()


def build_llm() -> LLM:
    """
    CrewAI uses LiteLLM under the hood.

    Supported patterns:
      - Ollama:
          CREWAI_MODEL="ollama/llama3.2"
          CREWAI_BASE_URL="http://localhost:11434"
      - OpenAI:
          CREWAI_MODEL="gpt-4o-mini" OR "openai/gpt-4o-mini"
          OPENAI_API_KEY must be set
    """

    model = os.getenv("CREWAI_MODEL", "ollama/llama3.2").strip()
    base_url = os.getenv("CREWAI_BASE_URL", "http://localhost:11434").strip()

    # If user provided a model without provider prefix, infer provider safely.
    # Rule: prefer Ollama unless OPENAI_API_KEY is present.
    if not model.startswith(("ollama/", "openai/")):
        if os.getenv("OPENAI_API_KEY"):
            model = f"openai/{model}"
        else:
            model = f"ollama/{model}"

    # Keep kwargs minimal for cross-version compatibility.
    kwargs = {"model": model, "temperature": 0.3}

    if model.startswith("ollama/"):
        kwargs["base_url"] = base_url
    elif model.startswith("openai/"):
        # Validate API key early to avoid confusing runtime errors
        if not os.getenv("OPENAI_API_KEY"):
            raise RuntimeError(
                "OPENAI_API_KEY is missing. Set OPENAI_API_KEY in your environment/.env "
                "to use OpenAI models with CrewAI."
            )

    try:
        return LLM(**kwargs)
    except Exception as e:
        raise RuntimeError(
            f"Failed to initialize CrewAI LLM with model='{model}'. "
            f"Check CREWAI_MODEL/CREWAI_BASE_URL/OPENAI_API_KEY. Original error: {e}"
        ) from e


def main() -> None:
    destination = os.getenv("TRIP_DESTINATION", "Goa")
    days = safe_int(os.getenv("TRIP_DAYS", "3"), 3)
    budget = safe_int(os.getenv("TRIP_BUDGET_INR", "35000"), 35000)

    llm = build_llm()

    researcher = Agent(
        role="Local Travel Researcher",
        goal="Create a compact, reliable list of attractions, best local food, and transport tips.",
        backstory="You are a practical researcher who prefers safe and realistic travel advice.",
        llm=llm,
        verbose=True,
    )

    planner = Agent(
        role="Itinerary Planner",
        goal="Convert research into a day-by-day itinerary within constraints (days, budget).",
        backstory="You optimize plans to fit time and budget while keeping the experience fun.",
        llm=llm,
        verbose=True,
    )

    critic = Agent(
        role="Quality & Risk Reviewer",
        goal="Identify gaps, safety issues, unrealistic timings, and propose fixes.",
        backstory="You are strict about feasibility and clarity; you rewrite parts that are vague.",
        llm=llm,
        verbose=True,
    )

    task_research = Task(
        description=(
            f"Destination: {destination}\n"
            f"Trip length: {days} days\n"
            f"Budget: INR {budget}\n\n"
            "Produce:\n"
            "1) Top 8–10 attractions/experiences\n"
            "2) 5 local food recommendations\n"
            "3) 5 local transport + safety tips\n"
            "Be concise, factual, and avoid hallucinated pricing."
        ),
        expected_output="A structured bullet list with attractions, food, and tips.",
        agent=researcher,
    )

    task_plan = Task(
        description=(
            f"Using the research, produce a {days}-day itinerary for {destination}.\n"
            "Constraints:\n"
            f"- Keep total spend within INR {budget} (rough estimates OK)\n"
            "- Add travel time buffers\n"
            "- Provide a short budget split: stay, food, local transport, activities\n"
            "- Output in a table-like format"
        ),
        expected_output="Day-by-day itinerary + budget split + brief notes.",
        agent=planner,
        context=[task_research],
    )

    task_review = Task(
        description=(
            "Review the itinerary for feasibility and clarity.\n"
            "Do:\n"
            "- Identify at least 5 improvements\n"
            "- Fix the plan with those improvements applied\n"
            "- Add a 'Plan B (bad weather)' section"
        ),
        expected_output="Revised itinerary + improvements list + Plan B section.",
        agent=critic,
        context=[task_plan],
    )

    crew = Crew(
        agents=[researcher, planner, critic],
        tasks=[task_research, task_plan, task_review],
        process=Process.sequential,
        verbose=True,
    )

    console.print(Panel.fit(f"Running CrewAI Trip Planner for {destination} ({days} days)", title="CrewAI Demo"))
    result = crew.kickoff()

    # Robust rendering: result can be non-string (object). Prefer .raw if available.
    text = getattr(result, "raw", None) or str(result)
    console.print(Panel(Markdown(text), title="Final Output"))


if __name__ == "__main__":
    main()
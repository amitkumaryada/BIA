from __future__ import annotations

import os
from typing import Optional, TypedDict, Dict, Any

from dotenv import load_dotenv
from langgraph.graph import StateGraph, END
from langchain_core.messages import HumanMessage, SystemMessage
from rich.console import Console
from rich.panel import Panel
from rich.markdown import Markdown

from .common.llm_factory import get_chat_model
from .common.utils import safe_int

load_dotenv()
console = Console()


class TravelState(TypedDict):
    destination: str
    days: int
    budget_inr: int
    research: Optional[str]
    itinerary: Optional[str]
    critique: Optional[str]
    iteration: int
    max_iterations: int


def node_research(state: TravelState) -> Dict[str, Any]:
    llm = get_chat_model()

    prompt = (
        "You are a travel researcher. Produce concise, factual bullets.\n"
        f"Destination: {state['destination']}\n"
        f"Days: {state['days']}\n"
        f"Budget: INR {state['budget_inr']}\n\n"
        "Return:\n"
        "1) Attractions (8 bullets)\n"
        "2) Local food (5 bullets)\n"
        "3) Local transport/safety tips (5 bullets)\n"
        "Avoid making up exact prices; use ranges if needed."
    )

    res = llm.invoke(
        [
            SystemMessage(content="You are a careful assistant."),
            HumanMessage(content=prompt),
        ]
    ).content

    # Return partial state update (LangGraph-safe)
    return {"research": res}


def node_plan(state: TravelState) -> Dict[str, Any]:
    llm = get_chat_model()

    prompt = (
        "You are an itinerary planner.\n"
        f"Destination: {state['destination']}\n"
        f"Days: {state['days']}\n"
        f"Budget: INR {state['budget_inr']}\n\n"
        "Use this research:\n"
        f"{state.get('research', '')}\n\n"
        "Create a day-by-day itinerary with:\n"
        "- Morning / Afternoon / Evening\n"
        "- Travel buffer time\n"
        "- Rough budget split (stay/food/transport/activities)\n"
        "Keep it readable."
    )

    itinerary = llm.invoke([HumanMessage(content=prompt)]).content
    return {"itinerary": itinerary}


def node_critique(state: TravelState) -> Dict[str, Any]:
    llm = get_chat_model()

    prompt = (
        "You are a strict reviewer.\n"
        "Critique the itinerary for feasibility, missing details, safety and budget realism.\n"
        "Return:\n"
        "A) 5–8 critique bullets\n"
        "B) A single line verdict: VERDICT: PASS or VERDICT: REVISE\n\n"
        f"ITINERARY:\n{state.get('itinerary', '')}"
    )

    critique = llm.invoke([HumanMessage(content=prompt)]).content
    return {"critique": critique, "iteration": state.get("iteration", 0) + 1}


def node_revise(state: TravelState) -> Dict[str, Any]:
    llm = get_chat_model()

    prompt = (
        "Revise the itinerary by applying the critique.\n"
        "Keep the same day count and budget.\n\n"
        f"CRITIQUE:\n{state.get('critique', '')}\n\n"
        f"CURRENT ITINERARY:\n{state.get('itinerary', '')}"
    )

    revised = llm.invoke([HumanMessage(content=prompt)]).content
    return {"itinerary": revised}


def route_after_critique(state: TravelState) -> str:
    text = (state.get("critique") or "").upper()

    if "VERDICT: PASS" in text:
        return END

    if state.get("iteration", 0) < state.get("max_iterations", 2):
        return "revise"

    return END


def main() -> None:
    destination = os.getenv("TRIP_DESTINATION", "Goa")
    days = safe_int(os.getenv("TRIP_DAYS", "3"), 3)
    budget = safe_int(os.getenv("TRIP_BUDGET_INR", "35000"), 35000)

    graph = StateGraph(TravelState)
    graph.add_node("research", node_research)
    graph.add_node("plan", node_plan)
    graph.add_node("critique", node_critique)
    graph.add_node("revise", node_revise)

    graph.set_entry_point("research")
    graph.add_edge("research", "plan")
    graph.add_edge("plan", "critique")
    graph.add_conditional_edges("critique", route_after_critique, {"revise": "revise", END: END})
    graph.add_edge("revise", "critique")

    app = graph.compile()

    init_state: TravelState = {
        "destination": destination,
        "days": days,
        "budget_inr": budget,
        "research": None,
        "itinerary": None,
        "critique": None,
        "iteration": 0,
        "max_iterations": 2,
    }

    # LangGraph returns a dict-like state -> ALWAYS access via keys
    final_state: TravelState = app.invoke(init_state)

    console.print(Panel(Markdown(final_state.get("research") or ""), title="Research"))
    console.print(Panel(Markdown(final_state.get("itinerary") or ""), title="Itinerary (final)"))
    console.print(Panel(Markdown(final_state.get("critique") or ""), title="Last Critique"))

    console.print("Teaching note: conditional edges + shared state enable loops (revise → critique).")


if __name__ == "__main__":
    main()
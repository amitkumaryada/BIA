# Mini Travel KB (Offline)

Use this file if you want students to run without internet.
They can paste snippets into prompts (or you can load it into context).

## Goa (India) quick notes
- Best season: Nov–Feb (cooler, less humid)
- Popular areas: North Goa (Baga/Calangute/Anjuna), Panaji, Old Goa, South Goa (Palolem/Agonda)
- Common activities: beaches, forts (Aguada/Chapora), churches (Basilica of Bom Jesus), spice plantation, river cruise
- Transport: scooter rental/taxi; beware of late-night driving; keep license/helmet
- Food: Goan fish curry, prawn balchão, pork vindaloo, bebinca, poi (bread)

## Safety + practical
- Keep cash + card, avoid isolated beaches at night
- Sun protection + hydration
- Check local regulations for rental vehicles

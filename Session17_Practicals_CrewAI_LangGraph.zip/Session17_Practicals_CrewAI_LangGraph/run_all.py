
from __future__ import annotations

import subprocess
import sys

def run(mod: str) -> None:
    print(f"\n=== Running: {mod} ===")
    subprocess.check_call([sys.executable, "-m", mod])

def main():
    run("src.langgraph_state_machine_basics")
    run("src.langgraph_travel_agent")
    run("src.crewai_trip_planner")

if __name__ == "__main__":
    main()

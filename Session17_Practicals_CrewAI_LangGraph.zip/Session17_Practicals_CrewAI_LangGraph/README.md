# Session 17 Practicals (CrewAI + LangGraph)

This folder contains **ready-to-run** practical exercises for Session 17:
- **CrewAI**: declarative *DAG-style* workflows (tasks) executed by a "crew" of role-based agents.
- **LangGraph**: explicit **state machines** + **graphs** (nodes + edges), including conditional routing and loops.

## 0) Prerequisites
- **Python 3.10+**
- (Recommended) **Ollama** for a free local LLM:
  - Install Ollama, then pull a small model:
    - `ollama pull llama3.2`
  - Ensure Ollama is running on: `http://localhost:11434`

> Why Ollama? It avoids paid APIs. If you *do* want OpenAI, you can set `OPENAI_API_KEY`.

## 1) Setup

### Option A — venv (simple)
```bash
python -m venv .venv
# mac/linux:
source .venv/bin/activate
# windows:
# .venv\Scripts\activate

pip install -r requirements.txt
cp .env.example .env
```

### Option B — uv (fast)
```bash
pip install uv
uv venv
# activate venv, then:
uv pip install -r requirements.txt
cp .env.example .env
```

## 2) Run the demos

### A) CrewAI: Multi-agent trip planning (offline-friendly)
```bash
python -m src.crewai_trip_planner
```

### B) LangGraph: Travel planning agent (state machine with conditional edges)
```bash
python -m src.langgraph_travel_agent
```

### C) LangGraph: Tiny FSM (good for teaching state transitions)
```bash
python -m src.langgraph_state_machine_basics
```

## 3) Switching LLM providers

### Recommended (free): Ollama
In `.env`:
```
CREWAI_MODEL=ollama/llama3.2
CREWAI_BASE_URL=http://localhost:11434
LANGGRAPH_OLLAMA_MODEL=llama3.2
LANGGRAPH_OLLAMA_BASE_URL=http://localhost:11434
```

### Optional: OpenAI (paid)
In `.env`:
```
OPENAI_API_KEY=...
OPENAI_MODEL=gpt-4o-mini
```

## 4) What to teach in-class (suggested)
1. **CrewAI mental model**: agents + tasks + process = declarative pipeline.
2. **LangGraph mental model**: state schema + nodes mutate state + edges route.
3. **Refactor exercise**: port the CrewAI workflow into LangGraph, then add retries/guards (Session 18).

---

If anything fails on student machines:
- First check Python version + venv activated
- Then check Ollama: `ollama list` and `curl http://localhost:11434`

# Fraud Detection ML Pipeline

A comprehensive end-to-end machine learning system for detecting fraudulent transactions using classical ML algorithms.

## Project Structure

```
fraud_detection_project/
├── README.md
├── requirements.txt
├── config/
│   └── config.yaml           # Pipeline configuration
├── data/
│   ├── raw/
│   ├── processed/
│   └── synthetic/            # Generated fraud data
├── src/
│   ├── data/
│   │   ├── data_generator.py # Synthetic data creation
│   │   ├── data_loader.py    # Data loading utilities
│   │   └── data_validator.py # Data validation
│   ├── features/
│   │   └── feature_engineering.py
│   ├── models/
│   │   ├── classical_models.py      # ML model implementations
│   │   ├── model_evaluation.py      # Evaluation metrics
│   │   └── hyperparameter_tuning.py # Optuna/Grid search
│   ├── utils/
│   │   └── visualization.py
│   └── deployment/
│       ├── api.py            # FastAPI REST service
│       ├── gradio_app.py     # Gradio web UI
│       └── monitoring.py     # Drift detection
├── notebooks/
│   ├── 01_data_generation.ipynb
│   └── 02_eda_analysis.ipynb
├── models/
│   └── trained/              # Saved model artifacts
└── test_api.py               # API test suite
```

---

## Prerequisites

- **Python**: 3.9+ recommended
- **pip**: Package manager
- **Virtual environment**: Recommended (venv or conda)

---

## Setup Instructions

### 1. Clone the Repository

```bash
git clone <repository-url>
cd classical_ML_agents-fraud_detection_project
```

### 2. Create Virtual Environment

```bash
# Using venv
python -m venv venv
source venv/bin/activate        # macOS/Linux
# venv\Scripts\activate         # Windows

# Or using conda
conda create -n fraud-detection python=3.10
conda activate fraud-detection
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

**Core dependencies include:**
- `pandas`, `numpy`, `scikit-learn` - Data processing & ML
- `xgboost`, `lightgbm` - Gradient boosting models
- `imbalanced-learn` - Handling class imbalance
- `optuna` - Hyperparameter optimization
- `fastapi`, `uvicorn` - REST API
- `gradio` - Web UI
- `mlflow`, `evidently` - Experiment tracking & monitoring

### 4. Configure the Pipeline

Edit `config/config.yaml` to customize:
- **Data generation**: Sample size, fraud rate, output path
- **Feature engineering**: Time windows, feature flags
- **Model training**: Test/validation splits, models to train
- **Hyperparameter tuning**: Method (optuna/grid_search), trials, timeout
- **API settings**: Host, port, model path

---

## Project Execution

### Step 1: Generate Synthetic Data

```bash
python src/data/data_generator.py
```

This creates `data/synthetic/fraud_transactions.csv` with:
- 100,000 transactions (configurable)
- ~2% fraud rate
- Realistic transaction patterns

### Step 2: Validate Data

```bash
python src/data/data_validator.py
```

### Step 3: Exploratory Data Analysis

Launch Jupyter and open the EDA notebook:

```bash
jupyter notebook notebooks/02_eda_analysis.ipynb
```

### Step 4: Preprocess & Split Data

```bash
python src/data/data_loader.py
```

Creates train/validation/test splits in `data/processed/`.

### Step 5: Train Models

```bash
python src/models/classical_models.py
```

Trains multiple models:
- Random Forest
- XGBoost
- LightGBM
- Logistic Regression
- SVM

### Step 6: Hyperparameter Tuning

```bash
python src/models/hyperparameter_tuning.py
```

Uses Optuna for Bayesian optimization with configurable trials and timeout.

### Step 7: Model Evaluation

```bash
python src/models/model_evaluation.py
```

Generates metrics: Accuracy, Precision, Recall, F1, ROC-AUC, PR-AUC.

---

## Deployment

### Option A: FastAPI REST Service

```bash
# Start the API server
python -m uvicorn src.deployment.api:app --host 0.0.0.0 --port 8000 --reload
```

**API Endpoints:**
| Endpoint | Method | Description |
|----------|--------|-------------|
| `/docs` | GET | Swagger UI documentation |
| `/redoc` | GET | ReDoc documentation |
| `/predict` | POST | Single transaction prediction |
| `/predict/batch` | POST | Batch predictions |
| `/health` | GET | Health check |

**Example Request:**
```bash
curl -X POST "http://localhost:8000/predict" \
  -H "Content-Type: application/json" \
  -d '{"amount": 500.0, "merchant_category": "online", "hour": 14}'
```

### Option B: Gradio Web Interface

```bash
python src/deployment/gradio_app.py
```

Opens an interactive web UI at `http://localhost:7860` for testing predictions.

### Test the API

```bash
python test_api.py
```

---

## Monitoring

```bash
python src/deployment/monitoring.py
```

Features:
- Model performance tracking
- Data drift detection with Evidently
- Alerting based on configurable thresholds

---

## ML Pipeline Stages

1. **Data Generation** - Synthetic fraud detection dataset creation
2. **Data Validation** - Schema and quality checks
3. **EDA** - Exploratory data analysis
4. **Feature Engineering** - Time-based, aggregation, statistical features
5. **Data Splitting** - Stratified train/validation/test splits
6. **Model Building** - Multiple classical ML algorithms
7. **Evaluation** - Comprehensive performance assessment
8. **Hyperparameter Tuning** - Optuna/Grid search optimization
9. **Deployment** - REST API and Gradio UI
10. **Monitoring** - Drift detection and performance tracking

---

## Configuration Reference

Key settings in `config/config.yaml`:

```yaml
data_generation:
  num_samples: 100000
  fraud_rate: 0.02
  output_path: "data/synthetic/fraud_transactions.csv"

model_training:
  test_size: 0.2
  validation_size: 0.15
  models: ["random_forest", "xgboost", "lightgbm", "logistic_regression", "svm"]

hyperparameter_tuning:
  method: "optuna"
  n_trials: 100
  timeout: 3600

api:
  host: "0.0.0.0"
  port: 8000
```

---

## Features

- **Realistic Synthetic Data**: Generates transaction data with fraud patterns
- **Multiple ML Models**: Random Forest, XGBoost, LightGBM, SVM, Logistic Regression
- **Advanced Feature Engineering**: Time-based, aggregation, and statistical features
- **Comprehensive Evaluation**: Precision, Recall, F1, AUC-ROC, Confusion Matrix
- **Hyperparameter Optimization**: Optuna Bayesian optimization with cross-validation
- **Model Deployment**: FastAPI REST service + Gradio web interface
- **Monitoring**: MLflow tracking and Evidently drift detection

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Module not found | Ensure you're in the project root and venv is activated |
| Model file not found | Run training step first to generate `models/trained/` artifacts |
| Port already in use | Change port in config or use `--port <PORT>` flag |
| CUDA errors | XGBoost/LightGBM will fall back to CPU automatically |
| XGBoost `libomp` error (macOS) | Run `brew install libomp` |
| `train.csv` not found | Run `python src/data/data_loader.py` first to create splits |
| imbalanced-learn import error | Run `pip install scikit-learn==1.5.2` for compatibility |

---

## License

MIT License 
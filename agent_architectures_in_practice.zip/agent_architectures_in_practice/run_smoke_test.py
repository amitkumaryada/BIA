"""Offline smoke tests for the Session 5 practical package.

This script verifies deterministic tools and file-backed memory without calling
an LLM API. It is safe to run before setting OPENAI_API_KEY.
"""

from __future__ import annotations

from pathlib import Path
from tempfile import TemporaryDirectory

from memory_store import ProfileMemoryStore
from tools import safe_calculate, search_corpus


def main() -> None:
    """Run simple package checks.

    Parameters:
        None.

    Returns:
        None.
    """
    assert safe_calculate("20000 * 0.08") == "1600"
    assert "LangGraph" in search_corpus("stateful retry loops human approval", top_k=2)

    with TemporaryDirectory() as temp_dir:
        memory_path = Path(temp_dir) / "profile_memory.json"
        store = ProfileMemoryStore(memory_path)
        assert "No saved" in store.as_context()
        store.add_preference("Prefer open-source tools where practical")
        assert "open-source" in store.as_context()

    print("Offline smoke test passed: calculator, corpus search, and profile memory work.")


if __name__ == "__main__":
    main()

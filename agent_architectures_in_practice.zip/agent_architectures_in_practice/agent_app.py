"""Command-line app for the Agent Architectures in Practice demo.

The app builds a LangChain agent with:
- OpenAI chat model configured from environment variables
- Local deterministic tools: calculator + corpus search
- Short-term conversation memory via LangGraph InMemorySaver
- Simple long-term profile memory via JSON file tools

Run:
    python agent_app.py --demo
"""

from __future__ import annotations

import argparse
import os
from dataclasses import dataclass
from typing import Any

from dotenv import load_dotenv
from langchain_groq import ChatGroq

from memory_store import ProfileMemoryStore
from tools import build_agent_tools


MODEL_NAME = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")  # or "openai/gpt-oss-120b"

SYSTEM_PROMPT = """You are a teaching-demo agent for a classroom session on agent architectures.

Your responsibilities:
1. Use search_model_corpus when the user asks about frameworks, memory, tools, model choices, or architecture trade-offs.
2. Use calculate for arithmetic, cost estimates, percentages, and totals.
3. Use remember_preference when the user explicitly asks you to remember a preference.
4. Use read_preferences before revising recommendations or choosing between options.
5. Explain tool use briefly and cite local source titles when search_model_corpus was used.
6. Keep answers clear for a mixed technical audience.

Do not claim live web access. Your search tool uses a small local teaching corpus.
"""


@dataclass
class AgentRun:
    """Formatted agent run result.

    Parameters:
        answer: Final assistant response.
        trace: Human-readable trace of model and tool messages.

    Returns:
        Dataclass instance.
    """

    answer: str
    trace: str


class TeachingAgent:
    """Wrapper around a LangChain agent with consistent invocation and tracing."""

    def __init__(self, agent: Any, profile_store: ProfileMemoryStore, default_thread_id: str = "bia-session-05") -> None:
        """Create a teaching agent wrapper.

        Parameters:
            agent: LangChain agent returned by create_agent.
            profile_store: Long-term profile memory store.
            default_thread_id: Thread ID for short-term memory.

        Returns:
            None.
        """
        self.agent = agent
        self.profile_store = profile_store
        self.default_thread_id = default_thread_id

    def ask(self, question: str, thread_id: str | None = None) -> AgentRun:
        """Ask the agent a question and return answer plus trace.

        Parameters:
            question: User question.
            thread_id: Optional conversation thread ID.

        Returns:
            AgentRun containing final answer and trace.
        """
        active_thread = thread_id or self.default_thread_id
        profile_context = self.profile_store.as_context()
        augmented_question = (
            f"{question}\n\n"
            f"[Long-term profile memory currently available to you: {profile_context}]"
        )

        # COST NOTE: With gpt-4o-mini and the small prompts used here, a full
        # classroom demo should typically stay well below US $0.50.
        result = self.agent.invoke(
            {"messages": [{"role": "user", "content": augmented_question}]},
            {"configurable": {"thread_id": active_thread}},
        )

        return AgentRun(
            answer=extract_final_answer(result),
            trace=format_trace(result),
        )


def build_teaching_agent(memory_path: str = "data/profile_memory.json") -> TeachingAgent:
    """Build the classroom teaching agent.

    Parameters:
        memory_path: Path to JSON profile memory.

    Returns:
        TeachingAgent instance ready for use.
    """
    load_dotenv()

    if not os.getenv("GROQ_API_KEY"):
        raise RuntimeError(
            "GROQ_API_KEY is missing. Copy .env.sample to .env and add your key. "
            "The offline tool demos still work without an API key."
        )

    try:
        from langchain.agents import create_agent
        from langchain_openai import ChatOpenAI
        from langgraph.checkpoint.memory import InMemorySaver
    except ImportError as exc:
        raise RuntimeError(
            "Required agent dependencies are missing. Run: pip install -r requirements.txt"
        ) from exc

    model_name = os.getenv("GROQ_MODEL", "llama3-70b-chat")  # or "openai/gpt-oss-120b" 
   
    
   

    model = ChatGroq(
        model=model_name,
        temperature=0.2,
        max_tokens=1000,
        reasoning_format="parsed",
        timeout=None,
        max_retries=2,
        # other params...
    )

    profile_store = ProfileMemoryStore(memory_path)
    tools = build_agent_tools(profile_store)

    agent = create_agent(
        model=model,
        tools=tools,
        checkpointer=InMemorySaver(),
        system_prompt=SYSTEM_PROMPT,
    )
    return TeachingAgent(agent=agent, profile_store=profile_store)


def extract_final_answer(result: dict[str, Any]) -> str:
    """Extract the final assistant message from a LangChain agent result.

    Parameters:
        result: Agent invocation result.

    Returns:
        Final answer text.
    """
    messages = result.get("messages", []) if isinstance(result, dict) else []
    if not messages:
        return "No agent messages were returned."

    final_message = messages[-1]
    content = getattr(final_message, "content", final_message)
    if isinstance(content, list):
        return "\n".join(str(item) for item in content)
    return str(content)


def format_trace(result: dict[str, Any]) -> str:
    """Format model/tool message flow for classroom explanation.

    Parameters:
        result: Agent invocation result.

    Returns:
        Readable trace text.
    """
    messages = result.get("messages", []) if isinstance(result, dict) else []
    trace_lines: list[str] = []

    for index, message in enumerate(messages, start=1):
        message_type = getattr(message, "type", message.__class__.__name__)
        content = getattr(message, "content", "")
        tool_calls = getattr(message, "tool_calls", None)

        if tool_calls:
            for call in tool_calls:
                name = call.get("name", "unknown_tool") if isinstance(call, dict) else getattr(call, "name", "unknown_tool")
                args = call.get("args", {}) if isinstance(call, dict) else getattr(call, "args", {})
                trace_lines.append(f"{index}. MODEL requested tool: {name} with args={args}")
        elif message_type == "tool":
            name = getattr(message, "name", "tool")
            trace_lines.append(f"{index}. TOOL returned from {name}: {str(content)[:500]}")
        elif message_type in {"human", "ai", "system"}:
            preview = str(content).replace("\n", " ")[:220]
            trace_lines.append(f"{index}. {message_type.upper()}: {preview}")

    return "\n".join(trace_lines) if trace_lines else "Trace was empty."


def run_demo(agent: TeachingAgent) -> None:
    """Run the recommended classroom prompt sequence.

    Parameters:
        agent: TeachingAgent instance.

    Returns:
        None.
    """
    prompts = [
        "Compare closed hosted models and open-weight models for a startup customer-support chatbot.",
        "Calculate estimated monthly cost if 20,000 support tickets each cost ₹0.08 to process.",
        "Remember that I prefer open-source tools when they are practical.",
        "Given that preference, revise your recommendation.",
        "Which framework would you choose if the same assistant needed explicit retry loops and human approval?",
    ]

    for prompt in prompts:
        print("\n" + "=" * 90)
        print(f"USER: {prompt}")
        run = agent.ask(prompt)
        print("\nASSISTANT:\n" + run.answer)
        print("\nTRACE:\n" + run.trace)


def main() -> None:
    """Run CLI entrypoint.

    Parameters:
        None.

    Returns:
        None.
    """
    parser = argparse.ArgumentParser(description="Session 5 teaching agent demo.")
    parser.add_argument("--demo", action="store_true", help="Run the prebuilt classroom demo sequence.")
    parser.add_argument("--thread-id", default="bia-session-05", help="Thread ID for short-term memory.")
    parser.add_argument("--reset-memory", action="store_true", help="Clear long-term profile memory before running.")
    args = parser.parse_args()

    store = ProfileMemoryStore()
    if args.reset_memory:
        store.clear()
        print("Cleared file-backed profile memory.")

    try:
        agent = build_teaching_agent()
        agent.default_thread_id = args.thread_id
    except RuntimeError as exc:
        print(f"\nSetup issue: {exc}")
        print("\nYou can still run the offline smoke test: python run_smoke_test.py")
        return

    if args.demo:
        run_demo(agent)
        return

    print("Interactive agent ready. Type 'exit' to quit.")
    while True:
        question = input("\nYou: ").strip()
        if question.lower() in {"exit", "quit"}:
            break
        if not question:
            continue
        run = agent.ask(question, thread_id=args.thread_id)
        print("\nAssistant:\n" + run.answer)
        print("\nTrace:\n" + run.trace)


if __name__ == "__main__":
    main()

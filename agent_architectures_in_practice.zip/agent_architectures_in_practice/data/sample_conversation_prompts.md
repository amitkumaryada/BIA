# Sample Conversation Prompts

Use these during the live demo after the notebook reaches the integrated agent section.

1. Compare closed hosted models and open-weight models for a startup customer-support chatbot.
2. Calculate estimated monthly cost if 20,000 support tickets each cost ₹0.08 to process.
3. Remember that I prefer open-source tools when they are practical.
4. Given that preference, revise your recommendation.
5. Which framework would you choose if the same assistant needed explicit retry loops and human approval?
6. Which framework would you choose if the same assistant needed a team of researcher, writer, and critic agents?

Trainer tip: run the same prompt sequence twice with the same `thread_id` to show short-term memory. Then switch the `thread_id` and show that the new conversation does not inherit the previous short-term state.

"""Agent tools for the Session 5 practical.

The tools are deliberately local and deterministic so every participant can run
the practical without additional search API keys. The LLM API is used only for
reasoning and tool selection.
"""

from __future__ import annotations

import ast
import json
import math
import operator
import re
from pathlib import Path
from typing import Any, Callable

try:
    from langchain.tools import tool
except ImportError:  # Allows offline smoke tests before dependencies are installed.
    def tool(func: Callable[..., str]) -> Callable[..., str]:
        """Fallback no-op decorator used when LangChain is not installed.

        Parameters:
            func: Function to return unchanged.

        Returns:
            The same function.
        """
        return func

from memory_store import ProfileMemoryStore


_ALLOWED_BINARY_OPERATORS: dict[type[ast.operator], Callable[[float, float], float]] = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
    ast.FloorDiv: operator.floordiv,
}

_ALLOWED_UNARY_OPERATORS: dict[type[ast.unaryop], Callable[[float], float]] = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}

_ALLOWED_FUNCTIONS: dict[str, Callable[..., float]] = {
    "abs": abs,
    "round": round,
    "ceil": math.ceil,
    "floor": math.floor,
    "sqrt": math.sqrt,
    "log": math.log,
    "log10": math.log10,
    "pow": pow,
}


def _safe_eval_node(node: ast.AST) -> float:
    """Evaluate a whitelisted Python expression AST node.

    Parameters:
        node: AST node parsed from a mathematical expression.

    Returns:
        Numeric result as float or int-compatible float.
    """
    if isinstance(node, ast.Expression):
        return _safe_eval_node(node.body)

    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return float(node.value)

    if isinstance(node, ast.BinOp):
        operator_type = type(node.op)
        if operator_type not in _ALLOWED_BINARY_OPERATORS:
            raise ValueError(f"Operator {operator_type.__name__} is not allowed.")
        left = _safe_eval_node(node.left)
        right = _safe_eval_node(node.right)
        if operator_type is ast.Pow and abs(right) > 8:
            raise ValueError("Exponent is too large for this classroom calculator.")
        return _ALLOWED_BINARY_OPERATORS[operator_type](left, right)

    if isinstance(node, ast.UnaryOp):
        operator_type = type(node.op)
        if operator_type not in _ALLOWED_UNARY_OPERATORS:
            raise ValueError(f"Unary operator {operator_type.__name__} is not allowed.")
        return _ALLOWED_UNARY_OPERATORS[operator_type](_safe_eval_node(node.operand))

    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
        function_name = node.func.id
        if function_name not in _ALLOWED_FUNCTIONS:
            raise ValueError(f"Function '{function_name}' is not allowed.")
        args = [_safe_eval_node(arg) for arg in node.args]
        return float(_ALLOWED_FUNCTIONS[function_name](*args))

    raise ValueError("Expression contains unsupported syntax.")


def safe_calculate(expression: str) -> str:
    """Safely evaluate a simple arithmetic expression.

    Parameters:
        expression: Arithmetic expression such as "20000 * 0.08".

    Returns:
        Result string or a readable error message.
    """
    cleaned = expression.strip().replace("₹", "").replace(",", "")
    if not cleaned:
        return "Calculator error: expression is empty."

    try:
        parsed = ast.parse(cleaned, mode="eval")
        result = _safe_eval_node(parsed)
    except Exception as exc:
        return f"Calculator error: {exc}"

    if float(result).is_integer():
        return str(int(result))
    return f"{result:.6f}".rstrip("0").rstrip(".")


def load_corpus(path: str | Path | None = None) -> list[dict[str, Any]]:
    """Load the local mini research corpus.

    Parameters:
        path: Optional custom JSON corpus path.

    Returns:
        List of corpus records.
    """
    if path is None:
        path = Path(__file__).resolve().parent / "data" / "mini_model_research_corpus.json"
    else:
        path = Path(path)

    with path.open("r", encoding="utf-8") as file:
        records = json.load(file)

    if not isinstance(records, list):
        raise ValueError("Corpus file must contain a list of records.")
    return records


def _tokenize(text: str) -> set[str]:
    """Tokenize text for simple keyword matching.

    Parameters:
        text: Text to tokenize.

    Returns:
        Set of lowercase keyword tokens.
    """
    stopwords = {
        "the", "a", "an", "and", "or", "for", "to", "of", "in", "on", "with",
        "is", "are", "as", "when", "which", "what", "would", "should", "if",
        "we", "you", "i", "it", "this", "that", "same", "need", "needs"
    }
    tokens = set(re.findall(r"[a-zA-Z][a-zA-Z0-9\-]+", text.lower()))
    return {token for token in tokens if token not in stopwords and len(token) > 2}


def search_corpus(query: str, top_k: int = 3) -> str:
    """Search the local architecture/model corpus with keyword overlap.

    Parameters:
        query: User query to match against corpus records.
        top_k: Number of matching records to return.

    Returns:
        Human-readable search summary with source titles.
    """
    query_tokens = _tokenize(query)
    if not query_tokens:
        return "Search found no useful keywords. Ask a more specific question."

    scored: list[tuple[float, dict[str, Any]]] = []
    for record in load_corpus():
        searchable_text = " ".join(
            [
                str(record.get("title", "")),
                str(record.get("category", "")),
                str(record.get("summary", "")),
                " ".join(record.get("best_for", [])),
                " ".join(record.get("tradeoffs", [])),
                " ".join(record.get("tags", [])),
            ]
        )
        record_tokens = _tokenize(searchable_text)
        overlap = query_tokens & record_tokens
        phrase_bonus = 0.0
        query_lower = query.lower()
        for tag in record.get("tags", []):
            if tag.lower() in query_lower:
                phrase_bonus += 1.5
        score = len(overlap) + phrase_bonus
        if score > 0:
            scored.append((score, record))

    if not scored:
        return "No local corpus match found. Try terms like LangChain, LangGraph, memory, tools, open-weight models, or hosted models."

    scored.sort(key=lambda item: item[0], reverse=True)
    lines = []
    for rank, (_, record) in enumerate(scored[:top_k], start=1):
        best_for = ", ".join(record.get("best_for", [])[:3])
        tradeoffs = ", ".join(record.get("tradeoffs", [])[:3])
        lines.append(
            f"{rank}. Source: {record['title']}\n"
            f"   Summary: {record['summary']}\n"
            f"   Best for: {best_for}\n"
            f"   Trade-offs: {tradeoffs}"
        )
    return "\n".join(lines)


def build_agent_tools(profile_store: ProfileMemoryStore | None = None) -> list[Any]:
    """Build LangChain-compatible tools for the agent.

    Parameters:
        profile_store: Optional file-backed profile memory store.

    Returns:
        List of decorated LangChain tools.
    """
    store = profile_store or ProfileMemoryStore()

    @tool
    def calculate(expression: str) -> str:
        """Evaluate arithmetic expressions. Use this for cost, totals, percentages, ratios, and numeric estimates."""
        return safe_calculate(expression)

    @tool
    def search_model_corpus(query: str) -> str:
        """Search the local knowledge corpus about agent frameworks, memory options, tools, and model choices."""
        return search_corpus(query)

    @tool
    def remember_preference(preference: str) -> str:
        """Save a durable user preference, such as preferring open-source tools or low-cost APIs."""
        return store.add_preference(preference)

    @tool
    def read_preferences() -> str:
        """Read saved durable user preferences before making recommendations."""
        return store.as_context()

    return [calculate, search_model_corpus, remember_preference, read_preferences]

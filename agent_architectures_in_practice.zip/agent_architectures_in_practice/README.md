# Agent Architectures in Practice — Practical Package

Build a working tool-using agent with short-term memory, file-backed profile memory, and local tools for search and calculation.

## Prerequisites

- Python 3.10 or 3.11 recommended.
- VS Code or Jupyter Notebook.
- An OpenAI API key for the integrated LangChain agent section.
- No web-search API, Redis server, vector database, or GPU is required.

## Setup

Download and unzip this folder, then open a terminal inside:

```bash
cd agent_architectures_in_practice
```

Create and activate a virtual environment:

```bash
python -m venv .venv
```

Windows PowerShell:

```bash
.venv\Scripts\Activate.ps1
```

macOS/Linux:

```bash
source .venv/bin/activate
```

Or with conda:

```bash
conda create -n bia-session-05 python=3.11 -y
conda activate bia-session-05
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Configure environment variables:

```bash
cp .env.sample .env
```

Then open `.env` and replace `sk-your-key-here` with your actual OpenAI API key.

## How to run

First verify the local deterministic pieces without any API key:

```bash
python run_smoke_test.py
```

Run the full classroom demo:

```bash
python agent_app.py --demo
```

Run interactively:

```bash
python agent_app.py
```

Reset file-backed profile memory:

```bash
python agent_app.py --reset-memory --demo
```

Open the teaching notebook:

```bash
jupyter notebook notebook.ipynb
```

Then run cells from top to bottom.

## What each file does

- `notebook.ipynb` — main guided classroom practical.
- `agent_app.py` — CLI app that runs the integrated LangChain agent.
- `tools.py` — deterministic calculator, local corpus search, and LangChain tool wrappers.
- `memory_store.py` — simple JSON-backed long-term profile memory.
- `run_smoke_test.py` — offline verification for tools and memory.
- `data/mini_model_research_corpus.json` — small local knowledge base for the search tool.
- `data/sample_conversation_prompts.md` — prompt sequence for the live demo.
- `.env.sample` — safe environment variable template.
- `requirements.txt` — pinned Python dependencies.
- `trainer_guide.md` — trainer flow, troubleshooting, and timing notes.

## Expected output

For the smoke test:

```text
Offline smoke test passed: calculator, corpus search, and profile memory work.
```

For the full demo, the agent should:

1. Search the local corpus when asked about frameworks or model choices.
2. Use the calculator tool for arithmetic.
3. Save the preference when asked to remember it.
4. Revise recommendations using the stored preference.
5. Show a readable trace of model and tool steps.

## Estimated API cost

The LLM calls use `gpt-4o-mini` by default through `OPENAI_MODEL`. A full demo run with the provided prompt sequence should usually cost only a few cents and is designed to stay comfortably below US $0.50. Costs depend on provider pricing, prompt length, retries, and how many times the demo is repeated.

## Troubleshooting

**`OPENAI_API_KEY is missing`**  
Copy `.env.sample` to `.env`, then add your API key. Make sure `.env` is in the project root.

**`ModuleNotFoundError: langchain`**  
Activate the correct virtual environment and run `pip install -r requirements.txt`.

**The agent does not remember previous turns**  
Use the same `--thread-id` for short-term memory. Changing the thread ID creates a separate conversation.

**The agent remembers preferences you no longer want**  
Run `python agent_app.py --reset-memory --demo` or delete `data/profile_memory.json`.

**Tool output looks too limited**  
The search tool intentionally uses a small local corpus to avoid external API keys. This is a teaching tool, not a live web search engine.

## Further reading

- LangChain agents: https://docs.langchain.com/oss/python/langchain/agents
- LangChain tools: https://docs.langchain.com/oss/python/langchain/tools
- LangChain short-term memory: https://docs.langchain.com/oss/python/langchain/short-term-memory
- LangGraph: https://docs.langchain.com/oss/python/langgraph/overview
- OpenAI Python SDK: https://developers.openai.com/api/reference/python

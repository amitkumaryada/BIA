# Trainer Guide — Agent Architectures in Practice

## Teaching flow

**0–10 min: Practical goal**  
Position the build: "We are not trying to master every framework today. We are building one clean agent architecture and using it to understand framework decisions."

**10–20 min: Offline tools first**  
Run `python run_smoke_test.py`. Explain that agents become useful when the model can call reliable deterministic tools. Show `tools.py` and highlight the calculator and local search corpus.

**20–35 min: Tool contracts**  
Open `tools.py`. Emphasize name, description/docstring, input argument, output format, and error handling. Ask the class why tool descriptions affect model behavior.

**35–50 min: Memory layers**  
Open `memory_store.py`. Compare:
- short-term thread memory through the LangChain/LangGraph checkpointer
- long-term profile memory through the JSON preference store
- vector memory as a later-course preview, not today's implementation

**50–75 min: Build the agent**  
Open `agent_app.py`. Walk through:
- environment loading
- model configuration
- tool construction
- `create_agent(...)`
- `InMemorySaver()`
- trace formatting

**75–105 min: Run the demo**  
Run:

```bash
python agent_app.py --reset-memory --demo
```

Pause after each prompt:
1. model-choice comparison
2. cost calculation
3. preference save
4. recommendation revision
5. framework choice for explicit loops

**105–125 min: Notebook reinforcement**  
Switch to `notebook.ipynb` and run the major sections. This gives a slower, more annotated path for learners who need to see each concept separately.

**125–145 min: Framework reflection**  
Ask: "What would change if this were built in CrewAI, AutoGen, or LangGraph?" Keep this conceptual:
- CrewAI: convert the single agent into roles and tasks
- AutoGen: express the workflow as agent-to-agent conversation
- LangGraph: make state, edges, retry loops, and human approval explicit

**145–160 min: Exercises and wrap-up**  
Assign one extension: add a new deterministic tool or add a new corpus record, then rerun the same prompt.

## Likely questions and ideal answers

**Q1. Why not use a live web search tool?**  
Because this is an architecture session. A local corpus avoids extra keys and internet variability while still teaching the tool abstraction. Live search can be swapped in later.

**Q2. Is JSON memory production-ready?**  
No. It is a teaching substitute for durable profile memory. Production systems would typically use a database or managed store with privacy controls.

**Q3. Is the checkpointer the same as long-term memory?**  
No. The checkpointer maintains thread-level conversation state. Long-term memory stores reusable facts or preferences across conversations.

**Q4. Why use LangChain instead of building the loop from scratch?**  
The framework handles model calls, tool routing, message state, and execution loop plumbing. This lets developers focus on the application behavior.

**Q5. When should LangGraph be used instead?**  
Use LangGraph when the workflow needs explicit state, branching, retries, human approval, persistence, or predictable control over each step.

**Q6. Where do CrewAI and AutoGen fit?**  
CrewAI is best explained as role/task team orchestration. AutoGen is best explained as conversation-based multi-agent coordination.

**Q7. Why is the model sometimes not choosing the expected tool?**  
Tool names, descriptions, and system instructions are part of the behavior. Improve the description, make the prompt more explicit, or add routing logic.

**Q8. What if learners do not have OpenAI keys?**  
They can run the smoke test, inspect the code, and follow the trace explanation. The trainer should run the LLM demo live.

## Common errors and fixes

**Missing API key**  
Fix: copy `.env.sample` to `.env` and set `OPENAI_API_KEY`.

**Wrong working directory**  
Fix: run commands from inside `agent_architectures_in_practice`.

**PowerShell activation blocked**  
Fix: run `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass`, then activate again.

**Dependency mismatch**  
Fix: create a clean Python 3.10 or 3.11 virtual environment and reinstall with `pip install -r requirements.txt`.

**Profile memory keeps old preferences**  
Fix: run with `--reset-memory` or delete `data/profile_memory.json`.

## Demo timing

The CLI demo takes about 10–15 minutes if run continuously. With teaching pauses, budget 30 minutes. The notebook reinforcement takes 25–35 minutes depending on how many cells are discussed.

## What to skip if running short

Skip the interactive CLI mode and run only `--demo`. Skip detailed explanation of `format_trace`; show its output and say it is a teaching helper. Do not skip the difference between short-term thread memory and long-term profile memory.

## Extension ideas

1. Add a `currency_convert` tool using a fixed exchange rate dictionary.
2. Add records to `mini_model_research_corpus.json` for a new framework.
3. Replace local corpus search with a real web search API.
4. Persist short-term memory with SQLite instead of in-memory checkpointer.
5. Add a human-approval gate before the agent saves long-term preferences.

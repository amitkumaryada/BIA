"""File-backed profile memory for the Agent Architectures practical.

This module intentionally keeps long-term memory simple: a JSON file stores user
preferences that the agent can read and update through tools. The goal is to
teach the architecture pattern before introducing vector stores later in the
course.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ProfileMemoryStore:
    """Small JSON-backed store for user preferences.

    Parameters:
        path: Relative or absolute path to the JSON memory file.

    Returns:
        A store object that can add, list, clear, and format preferences.
    """

    def __init__(self, path: str | Path = "data/profile_memory.json") -> None:
        """Create a profile memory store.

        Parameters:
            path: File location for profile memory.

        Returns:
            None.
        """
        base_dir = Path(__file__).resolve().parent
        self.path = Path(path)
        if not self.path.is_absolute():
            self.path = base_dir / self.path
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> dict[str, Any]:
        """Load the memory JSON document.

        Parameters:
            None.

        Returns:
            Dictionary containing the memory document.
        """
        if not self.path.exists():
            return {"preferences": []}

        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            # Graceful recovery: preserve the broken file for inspection and
            # continue with a clean memory object.
            backup_path = self.path.with_suffix(".broken.json")
            self.path.replace(backup_path)
            return {"preferences": []}

        if not isinstance(data, dict):
            return {"preferences": []}
        if "preferences" not in data or not isinstance(data["preferences"], list):
            data["preferences"] = []
        return data

    def _save(self, data: dict[str, Any]) -> None:
        """Persist the memory JSON document.

        Parameters:
            data: Memory dictionary to save.

        Returns:
            None.
        """
        self.path.write_text(json.dumps(data, indent=2), encoding="utf-8")

    def add_preference(self, preference: str) -> str:
        """Add a user preference if it is not already present.

        Parameters:
            preference: Preference text supplied by the user or agent.

        Returns:
            Human-readable status message.
        """
        cleaned = " ".join(preference.strip().split())
        if not cleaned:
            return "No preference was saved because the preference text was empty."

        data = self._load()
        existing = {item.lower() for item in data["preferences"]}
        if cleaned.lower() not in existing:
            data["preferences"].append(cleaned)
            self._save(data)
            return f"Saved preference: {cleaned}"
        return f"Preference already saved: {cleaned}"

    def list_preferences(self) -> list[str]:
        """Return stored preferences.

        Parameters:
            None.

        Returns:
            List of preference strings.
        """
        return [str(item) for item in self._load().get("preferences", [])]

    def clear(self) -> None:
        """Clear all stored preferences.

        Parameters:
            None.

        Returns:
            None.
        """
        self._save({"preferences": []})

    def as_context(self) -> str:
        """Format preferences as a compact context string.

        Parameters:
            None.

        Returns:
            Text summary of stored preferences.
        """
        preferences = self.list_preferences()
        if not preferences:
            return "No saved long-term preferences yet."
        return "Saved long-term preferences: " + "; ".join(preferences)

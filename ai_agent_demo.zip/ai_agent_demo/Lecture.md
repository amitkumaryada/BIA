# Real-Time Communication in Modern Web Development

> **Lecture Material** — Webhooks, Streaming, WebSockets & FastAPI

---

## 1. The Big Picture — Why Do We Need These?

Traditional HTTP is **request-response**: the client asks, the server answers, and the connection closes. But modern apps need more:

- 💬 Live chat, notifications, dashboards
- 📊 File uploads with progress bars
- 🤖 AI responses that appear word-by-word
- 💳 Payment confirmations without polling

**These four technologies solve different real-time communication problems.**

---

## 2. The Four Concepts

### 2.1 HTTP (Baseline — Know This First)

```
Client ──── GET /data ────► Server
Client ◄─── 200 OK ─────── Server
[Connection Closed]
```

| Characteristic | Description |
|----------------|-------------|
| Flow | One request → One response → Done |
| Data refresh | Client must ask again to get new data |
| Complexity | Simple, stateless, universally supported |

---

### 2.2 Webhooks — "Don't call us, we'll call you"

A webhook is just an **HTTP POST** that the server sends to you when something happens.

```
Your Server ◄── POST /webhook ── Payment Gateway
                 { "event": "payment.success", "amount": 100 }
```

#### How it works:

1. You register a URL with a third-party service  
   *("notify me at https://myapp.com/webhook")*
2. When an event occurs (payment, push to GitHub, new order), they POST to your URL
3. Your server receives and processes it

#### Real examples:

| Service | Event |
|---------|-------|
| **Stripe** | Payment succeeds |
| **GitHub** | Push triggers CI/CD |
| **Twilio** | SMS received |

#### Key characteristics:

- ✅ Still plain HTTP (no special protocol)
- ✅ Server-to-server (not browser-to-server)
- ✅ Event-driven, fire-and-forget
- ⚠️ You need a publicly accessible URL (`ngrok` in dev)

---

### 2.3 Streaming — "Send data in chunks"

Streaming means the server keeps the connection open and sends data progressively instead of waiting to have everything ready.

```
Client ──── GET /stream ────► Server
Client ◄─── chunk 1 ──────── Server  (connection still open)
Client ◄─── chunk 2 ──────── Server
Client ◄─── chunk 3 ──────── Server
[Connection Closes when done]
```

#### Two main flavors:

| Type | Direction | Protocol | Use Case |
|------|-----------|----------|----------|
| **SSE** (Server-Sent Events) | Server → Client only | HTTP | News feeds, AI text, live logs |
| **HTTP Streaming** | Server → Client only | HTTP | File downloads, video |

#### Real examples:

- 🤖 ChatGPT streaming tokens word-by-word
- 📜 Log tailing (`tail -f` over HTTP)
- 📁 Large file downloads with progress

---

### 2.4 WebSockets — "Full duplex, persistent connection"

WebSockets upgrade an HTTP connection into a **persistent, two-way channel**.

```
Client ──── HTTP Upgrade ────► Server
Client ◄══════════════════════► Server  (persistent, both directions)
Client ──── "hello" ─────────► Server
Client ◄─── "world" ────────── Server
Client ──── "ping" ──────────► Server
[Connection stays open until explicitly closed]
```

#### Real examples:

| Application | Description |
|-------------|-------------|
| 💬 Live chat | Real-time messaging |
| 🎮 Multiplayer games | Low-latency game state sync |
| 📝 Collaborative editors | Google Docs-style editing |
| 📈 Live stock tickers | Real-time price updates |
| 📊 Real-time dashboards | Live metrics & monitoring |

---

### 2.5 Websocat — "WebSocket on the command line"

`websocat` is a CLI tool (like `curl` but for WebSockets). It's for testing and debugging WebSocket servers.

```bash
# Connect to a WebSocket server from terminal
websocat ws://localhost:8000/ws

# You can then type messages and see responses live
```

**Think of it as:**

| Tool | Purpose |
|------|---------|
| `curl` | Tests HTTP APIs |
| `websocat` | Tests WebSocket servers |

---

## 3. FastAPI — The Framework That Does All of This

FastAPI is a modern Python web framework that **natively supports all of the above**.

```python
from fastapi import FastAPI, WebSocket
from fastapi.responses import StreamingResponse
import asyncio

app = FastAPI()

# Regular HTTP endpoint
@app.get("/data")
def get_data():
    return {"message": "hello"}

# Webhook receiver
@app.post("/webhook/stripe")
async def stripe_webhook(payload: dict):
    if payload["event"] == "payment.success":
        # process payment...
        pass
    return {"status": "received"}

# Streaming endpoint (e.g., AI response)
@app.get("/stream")
async def stream_response():
    async def generate():
        words = ["The", "answer", "is", "42"]
        for word in words:
            yield f"data: {word}\n\n"
            await asyncio.sleep(0.3)
    return StreamingResponse(generate(), media_type="text/event-stream")

# WebSocket endpoint
@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    while True:
        data = await websocket.receive_text()
        await websocket.send_text(f"Echo: {data}")
```

#### Why FastAPI specifically?

| Feature | Benefit |
|---------|---------|
| Built on `async/await` | Perfect for concurrent connections |
| Automatic OpenAPI/Swagger docs | Self-documenting APIs |
| Type hints | Automatic validation |
| Performance | Fastest Python framework for I/O-bound tasks |

---

## 4. Decision Tree — When to Use What?

```
Do you need real-time data?
│
├── NO → Use plain HTTP REST API
│
└── YES
    │
    ├── Is it server-to-server notification?
    │   └── YES → Use WEBHOOK
    │
    ├── Is communication ONE-WAY (server → client)?
    │   └── YES → Use STREAMING (SSE)
    │       • AI token streaming
    │       • Live logs
    │       • News feeds
    │
    └── Do you need TWO-WAY communication?
        └── YES → Use WEBSOCKETS
            • Chat
            • Games
            • Collaborative tools
            • Live dashboards (with user interaction)
```

---

## 5. Comparison Table

| Feature | HTTP | Webhook | Streaming (SSE) | WebSocket |
|---------|------|---------|-----------------|-----------|
| **Direction** | Client → Server → Client | Server → Client (S2S) | Server → Client | Both ways |
| **Connection** | Opens & closes | Opens & closes | Stays open (read) | Stays open (read+write) |
| **Protocol** | HTTP | HTTP | HTTP | WS (upgraded HTTP) |
| **Browser support** | Universal | N/A | Universal | Universal |
| **Complexity** | Low | Low | Medium | High |
| **Use case** | CRUD APIs | Event notifications | Live feeds, AI | Chat, games |
| **CLI tool** | `curl` | `curl` / Postman | `curl` | `websocat` |

---

## 6. Hands-On Demo Code

### Setup

```bash
pip install fastapi uvicorn websockets
```

### Full working example (`main.py`)

```python
from fastapi import FastAPI, WebSocket
from fastapi.responses import StreamingResponse, HTMLResponse
import asyncio

app = FastAPI()

# --- DEMO 1: Webhook receiver ---
@app.post("/webhook")
async def receive_webhook(body: dict):
    print(f"Received webhook: {body}")
    return {"status": "ok"}

# --- DEMO 2: SSE Streaming ---
@app.get("/stream")
async def stream():
    async def event_generator():
        for i in range(10):
            yield f"data: Message {i}\n\n"
            await asyncio.sleep(0.5)
    return StreamingResponse(event_generator(), media_type="text/event-stream")

# --- DEMO 3: WebSocket Chat ---
@app.websocket("/ws")
async def websocket_chat(ws: WebSocket):
    await ws.accept()
    await ws.send_text("Connected! Type something.")
    try:
        while True:
            msg = await ws.receive_text()
            await ws.send_text(f"You said: {msg}")
    except Exception:
        pass

# --- Simple HTML client to demo in browser ---
@app.get("/")
def index():
    return HTMLResponse("""
    <h2>SSE Stream</h2>
    <div id="sse"></div>
    <h2>WebSocket</h2>
    <input id="msg" placeholder="Type message">
    <button onclick="send()">Send</button>
    <div id="ws"></div>
    <script>
      // SSE
      const es = new EventSource('/stream');
      es.onmessage = e => document.getElementById('sse').innerHTML += e.data + '<br>';

      // WebSocket
      const socket = new WebSocket('ws://localhost:8000/ws');
      socket.onmessage = e => document.getElementById('ws').innerHTML += e.data + '<br>';
      function send() {
        socket.send(document.getElementById('msg').value);
      }
    </script>
    """)
```

### Run it

```bash
uvicorn main:app --reload
```

### Test WebSocket with websocat

```bash
# Install websocat
brew install websocat          # macOS
cargo install websocat         # via Rust

# Connect and chat
websocat ws://localhost:8000/ws
```

### Test Webhook manually

```bash
curl -X POST http://localhost:8000/webhook \
  -H "Content-Type: application/json" \
  -d '{"event": "payment.success", "amount": 99}'
```

### Test Streaming

```bash
curl -N http://localhost:8000/stream
```

---

## 7. Real-World Architecture Example

### "Build a Live AI Chatbot"

```
Browser
  │
  │  WebSocket (persistent, bidirectional)
  ▼
FastAPI Server
  │
  ├── Receives user message via WebSocket
  │
  ├── Calls Claude/OpenAI API with streaming=True
  │
  └── Forwards each token back to browser via WebSocket
                          │
                          ▼
                    Browser renders
                    tokens in real-time
```

### For payment confirmation on subscription:

```
Stripe ──── Webhook POST ────► FastAPI /webhook
                                │
                                └── Update DB, notify user
```

---

## 8. Summary Cheatsheet

| Technology | Description | Tools |
|------------|-------------|-------|
| **WEBHOOK** | HTTP callback. You give your URL, they call you when events happen. | `curl`, Postman, `ngrok` (for local dev) |
| **STREAMING** | One-way, server keeps sending data over open HTTP connection. | `curl -N`, `EventSource` in browser |
| **WEBSOCKET** | Two-way, persistent connection. Both sides can send anytime. | `websocat`, browser WebSocket API |
| **WEBSOCAT** | CLI tool to manually connect to and test WebSocket servers. Like `curl`, but for WebSockets. | — |
| **FASTAPI** | Python framework that handles ALL of the above natively. Best choice for async Python backends. | — |

---

## 9. Suggested Lecture Flow (90 min)

| Time | Topic |
|------|-------|
| **0–10 min** | Problem: why plain HTTP isn't enough |
| **10–25 min** | Webhooks — concept + demo with `curl` |
| **25–40 min** | Streaming — concept + `curl -N` demo |
| **40–60 min** | WebSockets — concept + `websocat` demo |
| **60–75 min** | FastAPI — live code all three |
| **75–90 min** | Build mini chatbot, Q&A |

---


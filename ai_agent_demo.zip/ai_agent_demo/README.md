# Real-Time Event-Driven AI Agent Demo

A demonstration of a real-time AI agent using WebSockets and LLM integration. This project showcases event-driven architecture where an AI agent processes user messages in real-time.

## Architecture

```
┌─────────────────┐     WebSocket      ┌─────────────────┐
│                 │◄──────────────────►│                 │
│    Frontend     │    Real-time       │  FastAPI Server │
│   (Browser)     │    Bi-directional  │                 │
│                 │                    │                 │
└─────────────────┘                    └────────┬────────┘
                                                │
                                       ┌────────▼────────┐
                                       │                 │
                                       │  Event          │
                                       │  Processor      │
                                       │                 │
                                       └────────┬────────┘
                                                │
                                       ┌────────▼────────┐
                                       │                 │
                                       │   AI Agent      │
                                       │   (LLM)         │
                                       │                 │
                                       └─────────────────┘
```

## Features

- **Real-time WebSocket Communication**: Bi-directional messaging between client and server
- **Event-Driven Architecture**: All interactions are processed as events with unique IDs
- **LLM Integration**: OpenAI GPT integration for intelligent responses
- **Fallback Mode**: Works without API key with basic responses
- **Broadcast Support**: Send messages to all connected clients
- **Event Logging**: Visual event stream in the UI
- **Conversation History**: Maintains context across messages

## Project Structure

```
ai_agent_demo/
├── backend/
│   ├── main.py           # FastAPI server with WebSocket endpoints
│   ├── agent.py          # AI Agent with LLM integration
│   └── event_processor.py # Event handling and processing
├── frontend/
│   └── index.html        # Single-page chat interface
├── requirements.txt      # Python dependencies
├── .env.example          # Environment variables template
└── README.md
```

## Quick Start

### 1. Install Dependencies

```bash
cd ai_agent_demo
pip install -r requirements.txt
```

### 2. Configure Environment (Optional)

```bash
cp .env.example .env
# Edit .env and add your OpenAI API key
```

### 3. Run the Server

```bash
cd backend
python main.py
```

Or with uvicorn:

```bash
uvicorn backend.main:app --reload --host 0.0.0.0 --port 8000
```

### 4. Open the Frontend

Open `frontend/index.html` in your browser, or navigate to:
```
http://localhost:8000
```

## Usage

1. Click **Connect** to establish WebSocket connection
2. Type messages in the input field
3. Use commands:
   - `/help` - Show available commands
   - `/status` - Check system status
   - `/clear` - Clear conversation history
   - `/info` - Show system info
4. Toggle **Broadcast** mode to send messages to all connected clients

## Event Types

| Event Type | Description |
|------------|-------------|
| `user_message` | Regular user message |
| `command` | System command (starts with /) |
| `query` | Query for information |
| `broadcast` | Message to all clients |
| `system` | System notifications |

## API Endpoints

- `GET /` - Serve frontend
- `GET /health` - Health check endpoint
- `WS /ws/{client_id}` - WebSocket connection

## WebSocket Message Format

### Client → Server
```json
{
  "type": "user_message",
  "content": "Hello, AI!",
  "broadcast": false
}
```

### Server → Client
```json
{
  "type": "agent_response",
  "content": "Hello! How can I help you?",
  "event_id": "abc12345",
  "processing_time_ms": 150.5,
  "timestamp": "2024-01-01T12:00:00.000Z"
}
```

## Technologies

- **Backend**: FastAPI, Python 3.9+
- **WebSocket**: Native FastAPI WebSocket support
- **LLM**: OpenAI GPT-3.5-turbo
- **Frontend**: HTML, TailwindCSS, Vanilla JavaScript

## License

MIT

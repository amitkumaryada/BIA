import uuid
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional
from collections import deque

logger = logging.getLogger("ai-agent")

class Event:
    def __init__(self, event_type: str, payload: Dict[str, Any], source: str):
        self.event_id = str(uuid.uuid4())[:8]
        self.event_type = event_type
        self.payload = payload
        self.source = source
        self.timestamp = datetime.utcnow()
        self.processed = False
        self.priority = self._determine_priority()
    
    def _determine_priority(self) -> int:
        priority_map = {
            "command": 1,
            "urgent": 1,
            "query": 2,
            "user_message": 3,
            "broadcast": 4,
            "system": 5
        }
        return priority_map.get(self.event_type, 3)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_id": self.event_id,
            "event_type": self.event_type,
            "payload": self.payload,
            "source": self.source,
            "timestamp": self.timestamp.isoformat(),
            "processed": self.processed,
            "priority": self.priority
        }

class EventProcessor:
    def __init__(self, max_history: int = 100):
        self.event_queue: deque = deque(maxlen=1000)
        self.event_history: deque = deque(maxlen=max_history)
        self.event_handlers: Dict[str, List[callable]] = {}
        self.stats = {
            "total_events": 0,
            "processed_events": 0,
            "failed_events": 0
        }
    
    def create_event(self, event_type: str, payload: Dict[str, Any], source: str) -> Dict[str, Any]:
        event = Event(event_type, payload, source)
        self.event_queue.append(event)
        self.stats["total_events"] += 1
        
        logger.info(f"Event created: {event.event_id} | Type: {event_type} | Source: {source}")
        
        return event.to_dict()
    
    def register_handler(self, event_type: str, handler: callable):
        if event_type not in self.event_handlers:
            self.event_handlers[event_type] = []
        self.event_handlers[event_type].append(handler)
        logger.info(f"Handler registered for event type: {event_type}")
    
    async def process_next(self) -> Optional[Dict[str, Any]]:
        if not self.event_queue:
            return None
        
        event = self.event_queue.popleft()
        
        try:
            if event.event_type in self.event_handlers:
                for handler in self.event_handlers[event.event_type]:
                    await handler(event.to_dict())
            
            event.processed = True
            self.stats["processed_events"] += 1
            self.event_history.append(event)
            
            return event.to_dict()
        except Exception as e:
            self.stats["failed_events"] += 1
            logger.error(f"Failed to process event {event.event_id}: {e}")
            return None
    
    def get_stats(self) -> Dict[str, Any]:
        return {
            **self.stats,
            "queue_size": len(self.event_queue),
            "history_size": len(self.event_history)
        }
    
    def get_recent_events(self, limit: int = 10) -> List[Dict[str, Any]]:
        recent = list(self.event_history)[-limit:]
        return [e.to_dict() for e in recent]

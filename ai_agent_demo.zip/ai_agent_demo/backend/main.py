import uvicorn
import asyncio
import json
import logging
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from typing import Dict, Set
from datetime import datetime
from agent import AIAgent
from event_processor import EventProcessor

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
logger = logging.getLogger("ai-agent")

app = FastAPI(title="Real-Time Event-Driven AI Agent")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, WebSocket] = {}
        self.event_processor = EventProcessor()
        self.ai_agent = AIAgent()
    
    async def connect(self, websocket: WebSocket, client_id: str):
        await websocket.accept()
        self.active_connections[client_id] = websocket
        logger.info(f"Client {client_id} connected. Total: {len(self.active_connections)}")
    
    def disconnect(self, client_id: str):
        if client_id in self.active_connections:
            del self.active_connections[client_id]
            logger.info(f"Client {client_id} disconnected. Total: {len(self.active_connections)}")
    
    async def send_to_client(self, client_id: str, message: dict):
        if client_id in self.active_connections:
            await self.active_connections[client_id].send_json(message)
    
    async def broadcast(self, message: dict, exclude: str = None):
        for client_id, connection in self.active_connections.items():
            if client_id != exclude:
                await connection.send_json(message)

manager = ConnectionManager()

@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: str):
    await manager.connect(websocket, client_id)
    
    await manager.send_to_client(client_id, {
        "type": "system",
        "content": f"Connected as {client_id}. AI Agent is ready to assist!",
        "timestamp": datetime.utcnow().isoformat()
    })
    
    try:
        while True:
            data = await websocket.receive_text()
            message = json.loads(data)
            
            event = manager.event_processor.create_event(
                event_type=message.get("type", "user_message"),
                payload=message,
                source=client_id
            )
            logger.info(f"Event received: {event['event_id']} from {client_id}")
            
            await manager.send_to_client(client_id, {
                "type": "event_ack",
                "event_id": event["event_id"],
                "timestamp": datetime.utcnow().isoformat()
            })
            
            await manager.send_to_client(client_id, {
                "type": "agent_thinking",
                "content": "Processing your request...",
                "timestamp": datetime.utcnow().isoformat()
            })
            
            response = await manager.ai_agent.process_event(event)
            
            await manager.send_to_client(client_id, {
                "type": "agent_response",
                "content": response["content"],
                "event_id": event["event_id"],
                "processing_time_ms": response["processing_time_ms"],
                "timestamp": datetime.utcnow().isoformat()
            })
            
            if message.get("broadcast", False):
                await manager.broadcast({
                    "type": "broadcast",
                    "from": client_id,
                    "content": message.get("content", ""),
                    "timestamp": datetime.utcnow().isoformat()
                }, exclude=client_id)
                
    except WebSocketDisconnect:
        manager.disconnect(client_id)
    except Exception as e:
        logger.error(f"Error processing message from {client_id}: {e}")
        await manager.send_to_client(client_id, {
            "type": "error",
            "content": str(e),
            "timestamp": datetime.utcnow().isoformat()
        })

@app.get("/health")
async def health_check():
    return {
        "status": "healthy",
        "active_connections": len(manager.active_connections),
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/")
async def serve_frontend():
    import os
    frontend_path = os.path.join(os.path.dirname(__file__), "..", "frontend", "index.html")
    return FileResponse(frontend_path)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)

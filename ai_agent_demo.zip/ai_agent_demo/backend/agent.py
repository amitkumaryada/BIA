import os
import time
import asyncio
import logging
from typing import Dict, Any, Optional
from openai import AsyncOpenAI
from dotenv import load_dotenv

load_dotenv()
logger = logging.getLogger("ai-agent")

class AIAgent:
    def __init__(self):
        self.client = None
        api_key = os.getenv("OPENAI_API_KEY")
        if api_key:
            self.client = AsyncOpenAI(api_key=api_key)
        
        self.system_prompt = """You are a helpful AI assistant in a real-time event-driven system.
You respond to user queries quickly and concisely.
You can help with:
- Answering questions
- Providing information
- Helping with tasks
- General conversation

Keep responses brief but informative. You're operating in a real-time WebSocket environment."""

        self.conversation_history: Dict[str, list] = {}
    
    async def process_event(self, event: Dict[str, Any]) -> Dict[str, Any]:
        start_time = time.time()
        
        event_type = event.get("event_type", "user_message")
        payload = event.get("payload", {})
        source = event.get("source", "unknown")
        
        if event_type == "user_message":
            response_content = await self._handle_user_message(payload, source)
        elif event_type == "command":
            response_content = await self._handle_command(payload)
        elif event_type == "query":
            response_content = await self._handle_query(payload, source)
        else:
            response_content = f"Received event of type: {event_type}"
        
        processing_time = (time.time() - start_time) * 1000
        
        return {
            "content": response_content,
            "processing_time_ms": round(processing_time, 2),
            "event_id": event.get("event_id")
        }
    
    async def _handle_user_message(self, payload: Dict, source: str) -> str:
        user_content = payload.get("content", "")
        
        if not user_content:
            return "I didn't receive any message content."
        
        if source not in self.conversation_history:
            self.conversation_history[source] = []
        
        self.conversation_history[source].append({
            "role": "user",
            "content": user_content
        })
        
        if len(self.conversation_history[source]) > 20:
            self.conversation_history[source] = self.conversation_history[source][-20:]
        
        if self.client:
            try:
                response = await self.client.chat.completions.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "system", "content": self.system_prompt},
                        *self.conversation_history[source]
                    ],
                    max_tokens=500,
                    temperature=0.7
                )
                assistant_message = response.choices[0].message.content
                
                self.conversation_history[source].append({
                    "role": "assistant",
                    "content": assistant_message
                })
                
                return assistant_message
            except Exception as e:
                logger.error(f"OpenAI API error: {e}")
                return await self._fallback_response(user_content)
        else:
            return await self._fallback_response(user_content)
    
    async def _fallback_response(self, user_content: str) -> str:
        await asyncio.sleep(0.1)
        
        user_lower = user_content.lower()
        
        if any(word in user_lower for word in ["hello", "hi", "hey"]):
            return "Hello! I'm your AI assistant. How can I help you today?"
        
        if "time" in user_lower:
            from datetime import datetime
            return f"The current UTC time is: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}"
        
        if any(word in user_lower for word in ["help", "what can you do"]):
            return """I can help you with:
• Answering questions
• Providing information
• Real-time conversations
• Processing events

Note: For full AI capabilities, please set your OPENAI_API_KEY in the .env file."""
        
        if "?" in user_content:
            return f"That's an interesting question about '{user_content[:50]}...'. To get AI-powered responses, please configure your OpenAI API key."
        
        return f"I received your message: '{user_content[:100]}...'. For intelligent responses, please set up your OpenAI API key in the .env file."
    
    async def _handle_command(self, payload: Dict) -> str:
        command = payload.get("command", "").lower()
        
        commands = {
            "status": "System is running normally. All services operational.",
            "clear": "Conversation history cleared.",
            "help": "Available commands: /status, /clear, /help, /info",
            "info": "Real-Time Event-Driven AI Agent v1.0 - WebSocket-based intelligent assistant"
        }
        
        return commands.get(command, f"Unknown command: {command}")
    
    async def _handle_query(self, payload: Dict, source: str) -> str:
        query = payload.get("query", "")
        return await self._handle_user_message({"content": query}, source)

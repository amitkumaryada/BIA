"""Integration and unit tests for the catalog-contract MCP showcase project."""

import ast
import asyncio
import os
import sys

import pytest
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__))
SRC_ROOT = os.path.join(PROJECT_ROOT, "src")

sys.path.insert(0, SRC_ROOT)

from catalog_contract_mcp_showcase.catalog import CatalogService
from catalog_contract_mcp_showcase.contracts import ContractService
from catalog_contract_mcp_showcase.web_app import render_app


@pytest.fixture(autouse=True)
def setup_runtime(tmp_path, monkeypatch):
    monkeypatch.setenv("SHOWCASE_RUNTIME_DIR", str(tmp_path / "runtime"))
    monkeypatch.setenv("SHOWCASE_VECTOR_DIR", str(tmp_path / "runtime" / "vector_store"))
    monkeypatch.setenv("SHOWCASE_UPLOAD_DIR", str(tmp_path / "runtime" / "uploads"))
    monkeypatch.setenv("SHOWCASE_EVAL_DIR", str(tmp_path / "runtime" / "evals"))


def _extract_content(result):
    if hasattr(result, "content") and result.content:
        text = result.content[0].text
        try:
            return ast.literal_eval(text)
        except Exception:
            return text
    return result


def test_catalog_index_and_search():
    service = CatalogService()
    indexed = service.index_catalog_data(force_reindex=True)
    assert indexed["document_count"] >= 5

    result = service.search_catalog("semantic search with SOC2", top_k=2)
    assert result["matches"]
    assert result["matches"][0]["product_id"] == "P110"


def test_catalog_filters():
    service = CatalogService()
    service.index_catalog_data(force_reindex=True)
    result = service.search_catalog("support workflows", top_k=3, max_price=10000)
    assert result["matches"]
    assert all(match["price"] <= 10000 for match in result["matches"])


def test_contract_clause_extraction_and_risks():
    service = ContractService()
    contract = service.load_contract(contract_name="vendor_agreement.md")
    clauses = service.extract_contract_clauses(contract["text"])
    assert len(clauses) >= 5

    analysis = service.summarize_contract_risks(contract["contract_name"], contract["text"])
    risk_ids = {finding["risk_id"].split(":")[0] for finding in analysis["findings"]}
    assert "auto_renewal" in risk_ids
    assert "uncapped_liability" in risk_ids


@pytest.mark.asyncio
async def test_mcp_server_stdio_roundtrip():
    env = os.environ.copy()
    env["PYTHONPATH"] = SRC_ROOT + os.pathsep + env.get("PYTHONPATH", "")
    server_params = StdioServerParameters(
        command="python3",
        args=["-m", "catalog_contract_mcp_showcase.server"],
        env=env,
        cwd=PROJECT_ROOT,
    )

    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            tools = await session.list_tools()
            tool_names = {tool.name for tool in tools.tools}
            assert "answer_catalog_question" in tool_names
            assert "summarize_contract_risks" in tool_names

            result = await session.call_tool(
                "answer_catalog_question",
                {"question": "Which product fits enterprise semantic search?"},
            )
            payload = _extract_content(result)
            assert payload["citations"]


def test_streamlit_module_imports():
    assert callable(render_app)

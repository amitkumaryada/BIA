# Architecture

This document explains the structure and runtime architecture of the `catalog_contract_mcp_showcase` project.

## Overview

The project is a single Python application that exposes one MCP server with two business domains:

- Catalog RAG for semantic product discovery and grounded product Q&A
- Contract Risk Highlighter for clause extraction, deterministic risk checks, and executive summaries

Two user-facing surfaces consume the same MCP server:

- CLI client for scripted demos and terminal usage
- Streamlit web app for interactive walkthroughs

Both surfaces are intentionally routed through MCP so the demo remains end to end.

## High-Level Architecture

```text
┌───────────────────────────────────────────────────────────────┐
│                        User Surfaces                          │
│                                                               │
│  1. CLI Demo / Agent           2. Streamlit Web Application   │
└───────────────────────────────┬───────────────────────────────┘
                                │
                                │ MCP over stdio
                                ▼
┌───────────────────────────────────────────────────────────────┐
│                  FastMCP Server: server.py                    │
│                                                               │
│  Tools        Resources        Prompts                        │
│  - Catalog    - Catalog        - Buyer assistant             │
│  - Contract   - Contract       - Contract review checklist   │
│                - Risk rules    - Escalation summary          │
└───────────────────────────────┬───────────────────────────────┘
                                │
            ┌───────────────────┴───────────────────┐
            │                                       │
            ▼                                       ▼
┌──────────────────────────────┐      ┌──────────────────────────────┐
│      Catalog Domain          │      │      Contract Domain         │
│                              │      │                              │
│  catalog.py                  │      │  contracts.py               │
│  retrieval.py                │      │                              │
│                              │      │  - Contract loading         │
│  - Catalog loading           │      │  - Clause extraction        │
│  - Index building            │      │  - Rule-based risk scan     │
│  - Retrieval + filters       │      │  - Summary generation       │
│  - Answer synthesis          │      │                              │
└──────────────────────────────┘      └──────────────────────────────┘
            │                                       │
            ▼                                       ▼
┌──────────────────────────────┐      ┌──────────────────────────────┐
│ Bundled catalog data         │      │ Bundled contract samples     │
│ Persisted vector index       │      │ Uploaded text or markdown    │
│ Optional embedding provider  │      │ Deterministic rulebook       │
└──────────────────────────────┘      └──────────────────────────────┘
```

## Project Layout

```text
catalog_contract_mcp_showcase/
├── README.md
├── ARCHITECTURE.md
├── pyproject.toml
├── Dockerfile
├── .env.example
├── tests/
│   └── test_showcase.py
└── src/catalog_contract_mcp_showcase/
    ├── __init__.py
    ├── config.py
    ├── models.py
    ├── observability.py
    ├── retrieval.py
    ├── catalog.py
    ├── contracts.py
    ├── server.py
    ├── client.py
    ├── web_app.py
    ├── evals.py
    └── data/
```

## Component Responsibilities

### `server.py`

Defines the combined `FastMCP` server and exposes:

- Catalog tools
- Contract tools
- Read-only resources
- Reusable prompts

This is the single MCP integration point for both user surfaces.

### `catalog.py`

Implements the catalog business logic:

- loads sample products
- builds or reuses the persisted index
- searches with semantic retrieval plus metadata filters
- answers questions with grounded product citations
- compares products using normalized output shapes

### `retrieval.py`

Implements vector indexing and retrieval behavior:

- embedding provider selection
- local fallback embedding when no external embedding key is configured
- persisted local vector store file
- retrieval scoring and ranking

### `contracts.py`

Implements contract analysis behavior:

- sample contract loading
- clause extraction using heading-aware parsing
- deterministic risk detection
- executive summary generation
- follow-up question generation

### `client.py`

Implements the CLI-facing experience:

- starts the MCP server over `stdio`
- calls tools directly for scripted commands
- supports demo mode
- supports an agent mode for broader freeform prompts

### `web_app.py`

Implements the Streamlit experience:

- catalog workflow tab
- contract workflow tab
- MCP-backed tool calls for all actions

### `config.py`

Centralizes environment and runtime path configuration:

- API keys
- model names
- runtime directories for vector index, eval output, and uploads

### `observability.py`

Provides lightweight optional tracing hooks:

- optional LangSmith decorators
- trace context helper used by eval flows and service calls

### `evals.py`

Runs project validation scenarios:

- retrieval correctness checks
- contract rule detection checks
- output summary checks
- local JSON report generation

## Data Flow

### Catalog workflow

```text
User query
  -> CLI or Streamlit
  -> MCP tool call: search_catalog / answer_catalog_question
  -> CatalogService
  -> VectorIndex search with optional filters
  -> Retrieved product matches
  -> Optional Groq answer synthesis
  -> Structured response with citations
```

### Contract workflow

```text
Sample contract or uploaded text
  -> CLI or Streamlit
  -> MCP tool call: highlight_contract_risks / summarize_contract_risks
  -> ContractService
  -> Clause extraction
  -> Deterministic risk rules
  -> Optional Groq explanation / summary
  -> Structured findings with excerpts, severity, and mitigation notes
```

## MCP Surface

### Tools

Catalog:

- `index_catalog_data`
- `search_catalog`
- `get_product_details`
- `answer_catalog_question`
- `compare_products`

Contract:

- `load_contract`
- `extract_contract_clauses`
- `highlight_contract_risks`
- `summarize_contract_risks`
- `suggest_contract_followups`

### Resources

- `catalog://products/summary`
- `catalog://products/{product_id}`
- `contract://samples/list`
- `contract://samples/{contract_name}`
- `risk://policy/rulebook`

### Prompts

- `catalog_buyer_assistant`
- `contract_review_checklist`
- `contract_escalation_summary`

## Runtime and Persistence

The project uses a small local runtime area for persisted artifacts:

- `data_runtime/vector_store/` for the catalog index
- `data_runtime/evals/` for eval reports
- `data_runtime/uploads/` for temporary uploaded documents if the app is extended to persist them

These paths can be overridden with environment variables.

## Observability

LangSmith tracing is optional. When enabled, the project can trace:

- indexing
- catalog retrieval
- catalog answer generation
- clause extraction
- contract risk highlighting
- eval execution

The tracing layer is intentionally optional so the demo still works offline.

## Testing Strategy

The project includes both unit-style and integration-style coverage:

- direct service tests for retrieval and contract analysis
- MCP server test over `stdio`
- import-level smoke coverage for the Streamlit app

## Architectural Decisions

### Why one MCP server?

One combined server makes the demo easier to run and easier to explain in a training setting. It also shows that MCP can expose multiple business domains from one server without requiring multiple processes.

### Why route the web app through MCP?

This avoids bypassing the protocol layer. The Streamlit app demonstrates the same tool contracts and server behavior as the CLI.

### Why deterministic rules before LLM summarization?

Risk detection should be explainable and testable. The LLM is used as a presentation and summarization layer, not the first source of truth.

### Why support local fallback embeddings?

The showcase should remain runnable in limited environments and during offline demo preparation. External embeddings improve quality, but the project still functions without them.

## Known Limitations

- The fallback local embedding implementation is demo-grade, not production-grade.
- The current Streamlit contract view displays structured results rather than inline highlighted clause markup.
- The vector index is file-backed and simple by design.
- Groq-based synthesis is optional and depends on configured credentials.

## Suggested Future Enhancements

- inline clause highlighting in the web UI
- richer filter controls in catalog search
- stronger eval datasets and regression tracking
- Docker Compose for server and web startup together
- separate architecture views for logical architecture and deployment architecture

# Project Guide

This guide is the practical companion to `ARCHITECTURE.md`. It explains how to understand, run, extend, and demo the project.

## What This Project Demonstrates

The showcase is meant to teach three ideas together:

- how to package a Python MCP server cleanly
- how one MCP server can expose multiple business workflows
- how CLI, UI, observability, and evals can all be connected to the same protocol-backed system

## End-to-End User Journeys

### Journey 1: Catalog RAG

1. Index bundled catalog data.
2. Search for products using a natural-language query.
3. Apply optional business filters such as price or compliance.
4. Produce a grounded answer with product citations.
5. Review raw retrieved matches for transparency.

### Journey 2: Contract Risk Review

1. Select a bundled contract sample or provide custom text.
2. Split the contract into clauses or sections.
3. Run deterministic risk checks.
4. Generate a concise business-facing summary.
5. Review findings, severity, excerpts, and follow-up actions.

## How to Run the Project

Setup:

```bash
cd catalog_contract_mcp_showcase
cp .env.example .env
uv sync
```

Core commands:

```bash
uv run catalog-contract-client index --force
uv run catalog-contract-client ask-catalog "Which product fits semantic search with SOC2 controls?"
uv run catalog-contract-client analyze-contract vendor_agreement.md
uv run catalog-contract-client demo
uv run catalog-contract-web
uv run catalog-contract-eval
```

## Environment Variables

Required for full functionality:

- `GROQ_API_KEY`
- `OPENAI_API_KEY`

Recommended defaults:

- `GROQ_MODEL`
- `EMBEDDING_MODEL`

Optional:

- `LANGSMITH_TRACING`
- `LANGSMITH_API_KEY`
- `LANGSMITH_PROJECT`
- `SHOWCASE_DATA_DIR`
- `SHOWCASE_VECTOR_DIR`
- `SHOWCASE_UPLOAD_DIR`
- `SHOWCASE_EVAL_DIR`

## How the Code Is Organized

Use this reading order if you are onboarding a new engineer or trainer:

1. `README.md`
2. `ARCHITECTURE.md`
3. `src/catalog_contract_mcp_showcase/server.py`
4. `src/catalog_contract_mcp_showcase/catalog.py`
5. `src/catalog_contract_mcp_showcase/contracts.py`
6. `src/catalog_contract_mcp_showcase/client.py`
7. `src/catalog_contract_mcp_showcase/web_app.py`
8. `src/catalog_contract_mcp_showcase/evals.py`

## Response Design

The project returns stable JSON-like dictionaries so all surfaces can reuse the same contracts.

Examples:

- catalog answer payload includes `query`, `answer`, `citations`, and `retrieved_products`
- contract summary payload includes `contract_name`, `finding_count`, `findings`, and `executive_summary`

This reduces special-case rendering logic across CLI, web, and tests.

## Demo Flow for Trainers

Suggested sequence:

1. Show the architecture at a high level.
2. Run `catalog-contract-client demo`.
3. Walk through the catalog tab in Streamlit.
4. Walk through the contract tab in Streamlit.
5. Show `catalog-contract-eval`.
6. Explain where LangSmith tracing would appear if enabled.

## Extension Points

### Add more catalog data

- update the bundled catalog JSON
- rebuild the index
- add eval cases for new query patterns

### Add more risk rules

- extend `RISK_RULEBOOK` in `contracts.py`
- add detection logic in `_apply_risk_rules`
- add tests and eval coverage

### Replace the local fallback retrieval

- keep `VectorIndex` as the abstraction boundary
- swap the local file-backed implementation for a production vector store
- preserve output shapes so the rest of the system does not need to change

### Improve the web experience

- render inline contract highlighting
- add richer retrieval filters and comparison layouts
- expose trace IDs or run metadata when tracing is enabled

## Operational Notes

- The catalog index is intentionally persisted locally for repeat demos.
- The contract workflow is deterministic first, LLM second.
- The app is designed to degrade gracefully when some keys are missing.
- The eval harness is lightweight and suitable for demo regression checks.

## Files Worth Calling Out

- [README.md](/Users/amit.yadav/Documents/docs/BIA/AgenticAIAug2025/MCP/catalog_contract_mcp_showcase/README.md)
- [ARCHITECTURE.md](/Users/amit.yadav/Documents/docs/BIA/AgenticAIAug2025/MCP/catalog_contract_mcp_showcase/ARCHITECTURE.md)
- [server.py](/Users/amit.yadav/Documents/docs/BIA/AgenticAIAug2025/MCP/catalog_contract_mcp_showcase/src/catalog_contract_mcp_showcase/server.py)
- [catalog.py](/Users/amit.yadav/Documents/docs/BIA/AgenticAIAug2025/MCP/catalog_contract_mcp_showcase/src/catalog_contract_mcp_showcase/catalog.py)
- [contracts.py](/Users/amit.yadav/Documents/docs/BIA/AgenticAIAug2025/MCP/catalog_contract_mcp_showcase/src/catalog_contract_mcp_showcase/contracts.py)
- [web_app.py](/Users/amit.yadav/Documents/docs/BIA/AgenticAIAug2025/MCP/catalog_contract_mcp_showcase/src/catalog_contract_mcp_showcase/web_app.py)
- [evals.py](/Users/amit.yadav/Documents/docs/BIA/AgenticAIAug2025/MCP/catalog_contract_mcp_showcase/src/catalog_contract_mcp_showcase/evals.py)

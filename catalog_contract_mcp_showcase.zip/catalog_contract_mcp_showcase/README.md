# Catalog RAG + Contract Risk Highlighter MCP Showcase

This project is a standalone MCP showcase that combines two demo capabilities in one server:

- Catalog RAG for grounded product discovery and product Q&A
- Contract Risk Highlighter for clause extraction, deterministic risk detection, and executive summaries

The repo includes:

- A packaged FastMCP server
- A CLI demo/client that talks to the server over `stdio`
- A Streamlit UI that also routes through MCP
- Bundled sample catalog and contract data
- Local evals and optional LangSmith tracing

Additional project documentation:

- [Architecture](./ARCHITECTURE.md)
- [Project Guide](./PROJECT_GUIDE.md)

## Structure

```text
catalog_contract_mcp_showcase/
├── pyproject.toml
├── Dockerfile
├── tests/
└── src/catalog_contract_mcp_showcase/
    ├── server.py
    ├── client.py
    ├── web_app.py
    ├── evals.py
    ├── catalog.py
    ├── contracts.py
    ├── retrieval.py
    ├── observability.py
    └── data/
```

## Setup

```bash
cd catalog_contract_mcp_showcase
cp .env.example .env
```

Minimum environment:

- `GROQ_API_KEY` for chat synthesis
- `OPENAI_API_KEY` for external embeddings

If `OPENAI_API_KEY` is not set, the catalog index falls back to a deterministic local embedding implementation so tests and offline demos still work.

Optional observability:

- `LANGSMITH_TRACING=true`
- `LANGSMITH_TRACING_V2=true` (recommended for newer LangSmith SDKs)
- `LANGSMITH_API_KEY=...`
- `LANGSMITH_PROJECT=catalog-contract-mcp-showcase`

## Run

Index the catalog:

```bash
uv run catalog-contract-client index --force
```

Ask a catalog question:

```bash
uv run catalog-contract-client ask-catalog "Which product fits semantic search with SOC2 controls?"
```

Analyze a sample contract:

```bash
uv run catalog-contract-client analyze-contract vendor_agreement.md
```

Run the scripted end-to-end demo:

```bash
uv run catalog-contract-client demo
```

Launch the Streamlit app:

```bash
uv run catalog-contract-web
```

Run evals:

```bash
uv run catalog-contract-eval
```

## MCP Surface

Tools:

- `index_catalog_data`
- `search_catalog`
- `get_product_details`
- `answer_catalog_question`
- `compare_products`
- `load_contract`
- `extract_contract_clauses`
- `highlight_contract_risks`
- `summarize_contract_risks`
- `suggest_contract_followups`

Resources:

- `catalog://products/summary`
- `catalog://products/{product_id}`
- `contract://samples/list`
- `contract://samples/{contract_name}`
- `risk://policy/rulebook`

Prompts:

- `catalog_buyer_assistant`
- `contract_review_checklist`
- `contract_escalation_summary`

## Observability and Eval

LangSmith tracing is optional but supported for catalog indexing, retrieval, answer generation, clause extraction, and risk highlighting. In the Streamlit app, successful runs now also render a direct LangSmith trace link under the workflow output. Local eval reports are written to `data_runtime/evals/latest_eval_report.json`.

## Docker

Build:

```bash
docker build -t catalog-contract-showcase .
```

Run Streamlit:

```bash
docker run --rm -p 8501:8501 --env-file .env catalog-contract-showcase
```

Run the MCP server directly:

```bash
docker run --rm -it --env-file .env catalog-contract-showcase catalog-contract-server
```

## Notes

- Sample catalog and contracts are synthetic and bundled for demo use.
- Uploaded contracts stay local to the app process except for model calls needed for summary generation.
- Tool outputs use stable JSON-like shapes so the CLI, web app, evals, and tests all render the same payloads.

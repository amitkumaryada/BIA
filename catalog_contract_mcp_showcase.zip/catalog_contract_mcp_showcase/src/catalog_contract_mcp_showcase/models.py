"""Pydantic models shared across catalog, contract, eval, and UI flows."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class Product(BaseModel):
    id: str
    name: str
    category: str
    description: str
    features: list[str]
    price: float
    compliance_tags: list[str]
    support_tier: str


class CatalogMatch(BaseModel):
    product_id: str
    name: str
    category: str
    score: float
    price: float
    compliance_tags: list[str]
    summary: str


class CatalogResponse(BaseModel):
    query: str
    filters: dict[str, Any]
    matches: list[CatalogMatch]


class CatalogAnswer(BaseModel):
    query: str
    answer: str
    citations: list[dict[str, str]]
    retrieved_products: list[CatalogMatch]


class ContractClause(BaseModel):
    clause_id: str
    heading: str
    text: str
    offset_start: int
    offset_end: int


class RiskFinding(BaseModel):
    risk_id: str
    severity: str
    title: str
    reason: str
    source_excerpt: str
    section_heading: str
    offset_start: int
    offset_end: int
    followup_question: str
    mitigation_note: str


class ContractAnalysis(BaseModel):
    contract_name: str
    finding_count: int
    findings: list[RiskFinding]
    executive_summary: str


class EvalResult(BaseModel):
    eval_name: str
    passed: bool
    details: dict[str, Any] = Field(default_factory=dict)

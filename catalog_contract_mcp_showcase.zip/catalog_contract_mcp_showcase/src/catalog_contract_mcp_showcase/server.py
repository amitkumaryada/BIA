"""Combined FastMCP server exposing catalog RAG and contract review capabilities."""

from __future__ import annotations

import json

from mcp.server.fastmcp import FastMCP

from .catalog import CatalogService
from .contracts import ContractService, RISK_RULEBOOK

mcp = FastMCP(
    "CatalogContractShowcase",
    instructions=(
        "This MCP server combines two demo domains: catalog RAG for grounded product discovery "
        "and contract risk highlighting for clause-based review. Prefer returning cited, inspectable "
        "results and use the domain-specific tools directly."
    ),
)

catalog_service = CatalogService()
contract_service = ContractService()


@mcp.tool()
def index_catalog_data(force_reindex: bool = False) -> dict:
    return catalog_service.index_catalog_data(force_reindex=force_reindex)


@mcp.tool()
def search_catalog(
    query: str,
    top_k: int = 3,
    category: str | None = None,
    max_price: float | None = None,
    compliance_tag: str | None = None,
) -> dict:
    return catalog_service.search_catalog(
        query,
        top_k=top_k,
        category=category,
        max_price=max_price,
        compliance_tag=compliance_tag,
    )


@mcp.tool()
def get_product_details(product_id: str) -> dict:
    return catalog_service.get_product_details(product_id)


@mcp.tool()
def answer_catalog_question(
    question: str,
    category: str | None = None,
    max_price: float | None = None,
    compliance_tag: str | None = None,
) -> dict:
    return catalog_service.answer_catalog_question(
        question,
        category=category,
        max_price=max_price,
        compliance_tag=compliance_tag,
    )


@mcp.tool()
def compare_products(product_ids: list[str]) -> dict:
    return catalog_service.compare_products(product_ids)


@mcp.tool()
def load_contract(contract_name: str) -> dict:
    return contract_service.load_contract(contract_name=contract_name)


@mcp.tool()
def extract_contract_clauses(contract_name: str) -> dict:
    loaded = contract_service.load_contract(contract_name=contract_name)
    return {
        "contract_name": loaded["contract_name"],
        "clauses": contract_service.extract_contract_clauses(loaded["text"]),
    }


@mcp.tool()
def highlight_contract_risks(contract_name: str, contract_text: str | None = None) -> dict:
    loaded = contract_service.load_contract(contract_name=contract_name, text=contract_text)
    return contract_service.highlight_contract_risks(loaded["contract_name"], loaded["text"])


@mcp.tool()
def summarize_contract_risks(contract_name: str, contract_text: str | None = None) -> dict:
    loaded = contract_service.load_contract(contract_name=contract_name, text=contract_text)
    return contract_service.summarize_contract_risks(loaded["contract_name"], loaded["text"])


@mcp.tool()
def suggest_contract_followups(contract_name: str, contract_text: str | None = None) -> dict:
    loaded = contract_service.load_contract(contract_name=contract_name, text=contract_text)
    return contract_service.suggest_contract_followups(loaded["contract_name"], loaded["text"])


@mcp.resource("catalog://products/summary")
def catalog_products_summary() -> str:
    products = [product.model_dump() for product in catalog_service.load_products()]
    return json.dumps({"product_count": len(products), "products": products}, indent=2)


@mcp.resource("catalog://products/{product_id}")
def catalog_product_resource(product_id: str) -> str:
    return json.dumps(catalog_service.get_product_details(product_id), indent=2)


@mcp.resource("contract://samples/list")
def contract_samples_list() -> str:
    return json.dumps({"samples": contract_service.list_samples()}, indent=2)


@mcp.resource("contract://samples/{contract_name}")
def contract_sample_resource(contract_name: str) -> str:
    return json.dumps(contract_service.load_contract(contract_name=contract_name), indent=2)


@mcp.resource("risk://policy/rulebook")
def risk_policy_rulebook() -> str:
    return json.dumps(RISK_RULEBOOK, indent=2)


@mcp.prompt()
def catalog_buyer_assistant(query: str, category: str = "") -> str:
    category_text = f" Focus on category {category}." if category else ""
    return (
        "Use the catalog tools to answer the buyer's request. Cite the selected products by ID and name."
        f"{category_text} Buyer query: {query}"
    )


@mcp.prompt()
def contract_review_checklist(contract_name: str) -> str:
    return (
        "Review the contract with the risk highlighter workflow. "
        "Extract clauses, flag deterministic risks, then summarize the highest-severity findings. "
        f"Contract: {contract_name}"
    )


@mcp.prompt()
def contract_escalation_summary(contract_name: str) -> str:
    return (
        "Prepare a short escalation summary for legal or procurement stakeholders. "
        f"Include high risks, evidence, and mitigation asks for {contract_name}."
    )


def main() -> None:
    catalog_service.index_catalog_data(force_reindex=False)
    mcp.run()


if __name__ == "__main__":
    main()

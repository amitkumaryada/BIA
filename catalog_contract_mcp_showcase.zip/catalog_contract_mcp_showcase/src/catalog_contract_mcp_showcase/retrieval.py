"""Embedding and vector-search utilities used by the catalog RAG workflow."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

from langchain_openai import OpenAIEmbeddings

from .config import Settings, get_settings
from .models import Product
from .observability import optional_traceable


def _tokenize(text: str) -> list[str]:
    return [token.strip(".,:;()[]{}").lower() for token in text.split() if token.strip()]


class EmbeddingProvider:
    def __init__(self, settings: Settings):
        self.settings = settings
        self._provider = None
        if settings.openai_api_key:
            self._provider = OpenAIEmbeddings(
                api_key=settings.openai_api_key,
                model=settings.embedding_model,
            )

    def embed_documents(self, texts: list[str]) -> list[list[float]]:
        if self._provider:
            return self._provider.embed_documents(texts)
        return [self._local_embed(text) for text in texts]

    def embed_query(self, text: str) -> list[float]:
        if self._provider:
            return self._provider.embed_query(text)
        return self._local_embed(text)

    def _local_embed(self, text: str, dimensions: int = 64) -> list[float]:
        vector = [0.0] * dimensions
        for token in _tokenize(text):
            digest = hashlib.md5(token.encode("utf-8")).hexdigest()
            index = int(digest[:8], 16) % dimensions
            vector[index] += 1.0
        norm = math.sqrt(sum(value * value for value in vector)) or 1.0
        return [value / norm for value in vector]


class VectorIndex:
    def __init__(self, settings: Settings | None = None):
        self.settings = settings or get_settings()
        self.index_path = Path(self.settings.vector_dir) / "catalog_index.json"
        self.embedding_provider = EmbeddingProvider(self.settings)

    @optional_traceable("catalog.index.build")
    def build(self, products: list[Product], force_reindex: bool = False) -> dict[str, Any]:
        source_hash = hashlib.sha256(
            json.dumps([product.model_dump() for product in products], sort_keys=True).encode("utf-8")
        ).hexdigest()
        if self.index_path.exists() and not force_reindex:
            current = self.load()
            if current.get("source_hash") == source_hash:
                return {
                    "status": "skipped",
                    "reason": "index already current",
                    "document_count": len(current.get("documents", [])),
                    "index_path": str(self.index_path),
                }

        documents: list[dict[str, Any]] = []
        texts = []
        for product in products:
            text = " ".join(
                [
                    product.name,
                    product.category,
                    product.description,
                    " ".join(product.features),
                    " ".join(product.compliance_tags),
                    product.support_tier,
                ]
            )
            texts.append(text)
            documents.append(
                {
                    "product_id": product.id,
                    "name": product.name,
                    "category": product.category,
                    "price": product.price,
                    "price_band": _price_band(product.price),
                    "compliance_tags": product.compliance_tags,
                    "support_tier": product.support_tier,
                    "text": text,
                }
            )

        vectors = self.embedding_provider.embed_documents(texts)
        payload = {
            "source_hash": source_hash,
            "documents": [{**document, "vector": vector} for document, vector in zip(documents, vectors)],
        }
        self.index_path.parent.mkdir(parents=True, exist_ok=True)
        self.index_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        return {
            "status": "rebuilt",
            "document_count": len(documents),
            "index_path": str(self.index_path),
        }

    def load(self) -> dict[str, Any]:
        if not self.index_path.exists():
            return {"documents": []}
        return json.loads(self.index_path.read_text(encoding="utf-8"))

    @optional_traceable("catalog.index.search")
    def search(
        self,
        query: str,
        *,
        top_k: int = 3,
        category: str | None = None,
        max_price: float | None = None,
        compliance_tag: str | None = None,
    ) -> list[dict[str, Any]]:
        payload = self.load()
        documents = payload.get("documents", [])
        if not documents:
            return []

        query_vector = self.embedding_provider.embed_query(query)
        query_tokens = set(_tokenize(query))
        filtered = []
        for document in documents:
            if category and document["category"].lower() != category.lower():
                continue
            if max_price is not None and float(document["price"]) > max_price:
                continue
            if compliance_tag and compliance_tag not in document["compliance_tags"]:
                continue
            semantic_score = cosine_similarity(query_vector, document["vector"])
            keyword_score = keyword_overlap_score(query_tokens, set(_tokenize(document["text"])))
            score = (0.55 * semantic_score) + (0.45 * keyword_score)
            filtered.append({**document, "score": round(score, 4)})
        filtered.sort(key=lambda item: item["score"], reverse=True)
        return filtered[:top_k]


def cosine_similarity(left: list[float], right: list[float]) -> float:
    numerator = sum(a * b for a, b in zip(left, right))
    left_norm = math.sqrt(sum(value * value for value in left)) or 1.0
    right_norm = math.sqrt(sum(value * value for value in right)) or 1.0
    return numerator / (left_norm * right_norm)


def _price_band(price: float) -> str:
    if price < 10000:
        return "budget"
    if price < 18000:
        return "mid"
    return "premium"


def keyword_overlap_score(query_tokens: set[str], document_tokens: set[str]) -> float:
    if not query_tokens:
        return 0.0
    return len(query_tokens & document_tokens) / len(query_tokens)

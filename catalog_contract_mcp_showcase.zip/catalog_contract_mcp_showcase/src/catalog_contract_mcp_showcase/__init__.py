"""Catalog RAG + Contract Risk Highlighter MCP showcase."""

__all__ = ["__version__"]

__version__ = "0.1.0"

"""Optional LangSmith tracing helpers used across the showcase workflows."""

from __future__ import annotations

import os
from contextlib import contextmanager
from typing import Any, Callable

from .config import get_settings

try:
    from langsmith import Client, trace, traceable
except Exception:  # pragma: no cover
    Client = None
    trace = None
    traceable = None


def _tracing_config() -> tuple[bool, Any, Any]:
    settings = get_settings()
    enabled = bool(traceable and trace and Client and settings.langsmith_tracing and settings.langsmith_api_key)
    if not enabled:
        return False, settings, None

    # `traceable` in the installed LangSmith SDK expects the V2 tracing flag.
    os.environ["LANGSMITH_TRACING"] = "true"
    os.environ["LANGSMITH_TRACING_V2"] = "true"
    os.environ["LANGSMITH_API_KEY"] = settings.langsmith_api_key or ""
    os.environ["LANGSMITH_PROJECT"] = settings.langsmith_project
    client = Client(api_key=settings.langsmith_api_key, auto_batch_tracing=False)
    return True, settings, client


def optional_traceable(name: str) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    enabled, settings, client = _tracing_config()

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        if enabled:
            return traceable(name=name, project_name=settings.langsmith_project, client=client)(func)
        return func

    return decorator


@contextmanager
def trace_context(name: str, metadata: dict[str, Any] | None = None):
    enabled, settings, client = _tracing_config()
    if enabled:
        with trace(
            name,
            project_name=settings.langsmith_project,
            client=client,
            metadata=metadata or {},
        ) as run:
            yield run
        return
    yield metadata or {}

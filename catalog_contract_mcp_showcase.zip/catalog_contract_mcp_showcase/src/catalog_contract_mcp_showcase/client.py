"""CLI client and scripted demo runner that talks to the showcase server over MCP."""

from __future__ import annotations

import argparse
import asyncio
import ast
import json
import os
from typing import Any

from langchain_groq import ChatGroq
from langchain_mcp_adapters.tools import load_mcp_tools
from langgraph.prebuilt import create_react_agent
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from .config import get_settings


def get_server_params() -> StdioServerParameters:
    env = os.environ.copy()
    package_root = str(get_settings().package_dir.parent)
    env["PYTHONPATH"] = package_root + os.pathsep + env.get("PYTHONPATH", "")
    return StdioServerParameters(
        command="python3",
        args=["-m", "catalog_contract_mcp_showcase.server"],
        env=env,
    )


async def call_tool(name: str, arguments: dict[str, Any]) -> Any:
    async with stdio_client(get_server_params()) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            return await session.call_tool(name, arguments)


async def run_prompt_agent(query: str) -> str:
    settings = get_settings()
    if not settings.groq_api_key:
        raise RuntimeError("GROQ_API_KEY is required for freeform agent mode.")
    async with stdio_client(get_server_params()) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            tools = await load_mcp_tools(session)
            agent = create_react_agent(
                ChatGroq(api_key=settings.groq_api_key, model=settings.groq_model, temperature=0),
                tools,
            )
            response = await agent.ainvoke({"messages": [("user", query)]})
            return response["messages"][-1].content


def _extract_content(result: Any) -> Any:
    if hasattr(result, "content") and result.content:
        parts = []
        for item in result.content:
            if hasattr(item, "text"):
                parts.append(item.text)
        if len(parts) == 1:
            try:
                return json.loads(parts[0])
            except Exception:
                try:
                    return ast.literal_eval(parts[0])
                except Exception:
                    return parts[0]
        return parts
    return result


async def run_demo() -> list[dict[str, Any]]:
    outputs = []
    outputs.append(
        {
            "step": "index_catalog_data",
            "result": _extract_content(await call_tool("index_catalog_data", {"force_reindex": True})),
        }
    )
    outputs.append(
        {
            "step": "answer_catalog_question",
            "result": _extract_content(
                await call_tool(
                    "answer_catalog_question",
                    {"question": "Which product best fits enterprise semantic search with SOC2 controls?"},
                )
            ),
        }
    )
    outputs.append(
        {
            "step": "summarize_contract_risks",
            "result": _extract_content(
                await call_tool("summarize_contract_risks", {"contract_name": "vendor_agreement.md"})
            ),
        }
    )
    return outputs


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Catalog + Contract MCP showcase client")
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("demo", help="Run the scripted showcase demo")

    index_parser = subparsers.add_parser("index", help="Index catalog sample data")
    index_parser.add_argument("--force", action="store_true")

    ask_parser = subparsers.add_parser("ask-catalog", help="Ask a grounded catalog question")
    ask_parser.add_argument("question")
    ask_parser.add_argument("--category")
    ask_parser.add_argument("--max-price", type=float)
    ask_parser.add_argument("--compliance-tag")

    contract_parser = subparsers.add_parser("analyze-contract", help="Analyze a sample contract")
    contract_parser.add_argument("contract_name")

    prompt_parser = subparsers.add_parser("prompt", help="Run a freeform MCP agent prompt")
    prompt_parser.add_argument("query")

    return parser


async def _run_cli(args: argparse.Namespace) -> Any:
    if args.command == "index":
        return _extract_content(await call_tool("index_catalog_data", {"force_reindex": args.force}))
    if args.command == "ask-catalog":
        return _extract_content(
            await call_tool(
                "answer_catalog_question",
                {
                    "question": args.question,
                    "category": args.category,
                    "max_price": args.max_price,
                    "compliance_tag": args.compliance_tag,
                },
            )
        )
    if args.command == "analyze-contract":
        return _extract_content(
            await call_tool("summarize_contract_risks", {"contract_name": args.contract_name})
        )
    if args.command == "prompt":
        return await run_prompt_agent(args.query)
    return await run_demo()


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    result = asyncio.run(_run_cli(args))
    print(json.dumps(result, indent=2) if not isinstance(result, str) else result)


if __name__ == "__main__":
    main()

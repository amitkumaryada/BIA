"""Catalog domain services for indexing, retrieval, grounded answers, and comparisons."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from langchain_groq import ChatGroq

from .config import Settings, get_settings
from .models import CatalogAnswer, CatalogMatch, CatalogResponse, Product
from .observability import optional_traceable
from .retrieval import VectorIndex


class CatalogService:
    def __init__(self, settings: Settings | None = None):
        self.settings = settings or get_settings()
        self.catalog_path = Path(self.settings.data_dir) / "catalog_products.json"
        self.vector_index = VectorIndex(self.settings)

    def load_products(self) -> list[Product]:
        data = json.loads(self.catalog_path.read_text(encoding="utf-8"))
        return [Product(**item) for item in data]

    def get_product(self, product_id: str) -> Product | None:
        for product in self.load_products():
            if product.id == product_id:
                return product
        return None

    def index_catalog_data(self, force_reindex: bool = False) -> dict[str, Any]:
        return self.vector_index.build(self.load_products(), force_reindex=force_reindex)

    @optional_traceable("catalog.search")
    def search_catalog(
        self,
        query: str,
        *,
        top_k: int = 3,
        category: str | None = None,
        max_price: float | None = None,
        compliance_tag: str | None = None,
    ) -> dict[str, Any]:
        matches = self.vector_index.search(
            query,
            top_k=top_k,
            category=category,
            max_price=max_price,
            compliance_tag=compliance_tag,
        )
        response = CatalogResponse(
            query=query,
            filters={
                "category": category,
                "max_price": max_price,
                "compliance_tag": compliance_tag,
                "top_k": top_k,
            },
            matches=[
                CatalogMatch(
                    product_id=item["product_id"],
                    name=item["name"],
                    category=item["category"],
                    score=item["score"],
                    price=item["price"],
                    compliance_tags=item["compliance_tags"],
                    summary=item["text"][:180],
                )
                for item in matches
            ],
        )
        return response.model_dump()

    def get_product_details(self, product_id: str) -> dict[str, Any]:
        product = self.get_product(product_id)
        if not product:
            return {"status": "not_found", "product_id": product_id}
        return {"status": "ok", "product": product.model_dump()}

    @optional_traceable("catalog.answer")
    def answer_catalog_question(
        self,
        question: str,
        *,
        category: str | None = None,
        max_price: float | None = None,
        compliance_tag: str | None = None,
    ) -> dict[str, Any]:
        retrieval = self.search_catalog(
            question,
            top_k=3,
            category=category,
            max_price=max_price,
            compliance_tag=compliance_tag,
        )
        matches = retrieval["matches"]
        citations = [{"product_id": match["product_id"], "name": match["name"]} for match in matches]
        answer = self._synthesize_answer(question, matches)
        return CatalogAnswer(
            query=question,
            answer=answer,
            citations=citations,
            retrieved_products=[CatalogMatch(**match) for match in matches],
        ).model_dump()

    def compare_products(self, product_ids: list[str]) -> dict[str, Any]:
        products = [self.get_product(product_id) for product_id in product_ids]
        valid_products = [product for product in products if product]
        if len(valid_products) < 2:
            return {"status": "error", "message": "Provide at least two valid product IDs."}
        comparisons = []
        for product in valid_products:
            comparisons.append(
                {
                    "product_id": product.id,
                    "name": product.name,
                    "category": product.category,
                    "price": product.price,
                    "support_tier": product.support_tier,
                    "compliance_tags": product.compliance_tags,
                    "features": product.features,
                }
            )
        return {"status": "ok", "comparisons": comparisons}

    def _synthesize_answer(self, question: str, matches: list[dict[str, Any]]) -> str:
        if not matches:
            return "No matching products were retrieved from the catalog."
        if self.settings.groq_api_key:
            try:
                model = ChatGroq(
                    api_key=self.settings.groq_api_key,
                    model=self.settings.groq_model,
                    temperature=0,
                )
                context = "\n\n".join(
                    f"{item['product_id']} - {item['name']}: {item['summary']}" for item in matches
                )
                prompt = (
                    "Answer the buyer question using only the catalog context. "
                    "Cite product IDs and names directly in the answer.\n\n"
                    f"Question: {question}\n\nCatalog context:\n{context}"
                )
                return model.invoke(prompt).content
            except Exception:
                pass
        joined = "; ".join(
            f"{item['product_id']} {item['name']} fits because {item['summary']}" for item in matches
        )
        return f"Grounded answer for '{question}': {joined}"

"""Local evaluation runner for catalog retrieval and contract risk demo scenarios."""

from __future__ import annotations

import json
from datetime import datetime

from .catalog import CatalogService
from .config import get_settings
from .contracts import ContractService
from .models import EvalResult
from .observability import trace_context


def run_catalog_evals() -> list[EvalResult]:
    service = CatalogService()
    service.index_catalog_data(force_reindex=True)

    search_result = service.search_catalog("semantic search with SOC2", top_k=2)
    top_match = search_result["matches"][0]["product_id"] if search_result["matches"] else None

    answer_result = service.answer_catalog_question("Which product supports privacy controls and HIPAA?")
    citation_ids = {item["product_id"] for item in answer_result["citations"]}

    filter_result = service.search_catalog("support workflows", top_k=3, max_price=10000)

    return [
        EvalResult(
            eval_name="catalog_top_match_semantic_search",
            passed=top_match == "P110",
            details={"top_match": top_match},
        ),
        EvalResult(
            eval_name="catalog_citation_presence",
            passed="P140" in citation_ids,
            details={"citations": sorted(citation_ids)},
        ),
        EvalResult(
            eval_name="catalog_price_filter",
            passed=all(match["price"] <= 10000 for match in filter_result["matches"]),
            details={"matches": filter_result["matches"]},
        ),
    ]


def run_contract_evals() -> list[EvalResult]:
    service = ContractService()
    contract = service.load_contract(contract_name="vendor_agreement.md")
    clauses = service.extract_contract_clauses(contract["text"])
    summary = service.summarize_contract_risks(contract["contract_name"], contract["text"])
    risk_ids = {finding["risk_id"].split(":")[0] for finding in summary["findings"]}

    return [
        EvalResult(
            eval_name="contract_clause_extraction",
            passed=len(clauses) >= 5,
            details={"clause_count": len(clauses)},
        ),
        EvalResult(
            eval_name="contract_expected_risks",
            passed={"auto_renewal", "uncapped_liability", "broad_data_usage"}.issubset(risk_ids),
            details={"risk_ids": sorted(risk_ids)},
        ),
        EvalResult(
            eval_name="contract_summary_present",
            passed=bool(summary["executive_summary"]),
            details={"summary": summary["executive_summary"]},
        ),
    ]


def write_report(results: list[EvalResult]) -> str:
    settings = get_settings()
    report = {
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "passed": all(result.passed for result in results),
        "results": [result.model_dump() for result in results],
    }
    path = settings.eval_dir / "latest_eval_report.json"
    path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    return str(path)


def main() -> None:
    with trace_context("showcase.evals", metadata={"surface": "cli", "domain": "both"}):
        results = run_catalog_evals() + run_contract_evals()
    report_path = write_report(results)
    print(json.dumps({"report_path": report_path, "results": [result.model_dump() for result in results]}, indent=2))


if __name__ == "__main__":
    main()

# Mutual NDA

## Confidential Information
Each party may disclose confidential information marked or reasonably understood to be confidential.

## Use Restrictions
Receiving party will use confidential information only for the evaluation purpose.

## Termination
This agreement may be terminated by either party with ten days notice.

## Return or Destruction
Receiving party will return or destroy confidential information upon request.

## Governing Law
The agreement is governed by the laws of California.

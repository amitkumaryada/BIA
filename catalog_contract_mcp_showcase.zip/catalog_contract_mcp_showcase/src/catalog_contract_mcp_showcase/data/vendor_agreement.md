# Vendor Agreement

## Services
Vendor will provide implementation services and hosting support for the platform.

## Term
The initial term is twelve months and renews automatically for successive one-year periods unless either party provides notice.

## Fees
Customer will pay annual fees within thirty days of invoice.

## Liability
Vendor shall not be liable for any indirect damages. Vendor's aggregate liability is not limited under this agreement.

## Data Use
Vendor may use customer usage data, account data, and service-generated content to improve products and for internal analytics.

## Support
Vendor will use commercially reasonable efforts to respond to support requests.

## Governing Law
This agreement will be interpreted in accordance with applicable law.

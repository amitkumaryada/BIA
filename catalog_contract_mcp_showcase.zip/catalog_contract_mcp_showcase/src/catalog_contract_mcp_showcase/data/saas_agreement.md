# SaaS Agreement

## Subscription Services
Provider grants customer access to the hosted subscription services described in the order form.

## Termination
Either party may terminate for material breach if the breach remains uncured for thirty days after written notice.

## Liability Cap
Provider's aggregate liability under this agreement is capped at the fees paid in the prior twelve months.

## Indemnity
Customer will indemnify provider against all claims arising from customer's data and use of the services.

## Privacy
Provider may process personal data only to deliver the services and maintain security controls.

## Service Levels
Provider targets 99.9 percent uptime and critical support response within four hours.

## Governing Law
This agreement is governed by the laws of New York, excluding conflict of law rules.

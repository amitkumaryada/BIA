"""Configuration loading and runtime path helpers for the showcase project."""

from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel, Field

load_dotenv()


def _get_env_value(name: str) -> str | None:
    value = os.getenv(name)
    if value is None:
        return None
    value = value.strip()
    return value or None


def _get_env_path(name: str, default: Path) -> Path:
    value = _get_env_value(name)
    return Path(value) if value else default


def _get_env_str(name: str, default: str) -> str:
    value = _get_env_value(name)
    return value or default


class Settings(BaseModel):
    groq_api_key: str | None = Field(default_factory=lambda: _get_env_value("GROQ_API_KEY"))
    groq_model: str = Field(default_factory=lambda: _get_env_str("GROQ_MODEL", "llama-3.1-70b-versatile"))
    openai_api_key: str | None = Field(default_factory=lambda: _get_env_value("OPENAI_API_KEY"))
    embedding_model: str = Field(default_factory=lambda: _get_env_str("EMBEDDING_MODEL", "text-embedding-3-small"))
    langsmith_tracing: bool = Field(
        default_factory=lambda: _get_env_str("LANGSMITH_TRACING", "false").lower() == "true"
    )
    langsmith_api_key: str | None = Field(default_factory=lambda: _get_env_value("LANGSMITH_API_KEY"))
    langsmith_project: str = Field(
        default_factory=lambda: _get_env_str("LANGSMITH_PROJECT", "catalog-contract-mcp-showcase")
    )
    package_dir: Path = Path(__file__).resolve().parent
    data_dir: Path = Field(
        default_factory=lambda: _get_env_path(
            "SHOWCASE_DATA_DIR",
            Path(__file__).resolve().parent / "data",
        )
    )
    runtime_dir: Path = Field(
        default_factory=lambda: _get_env_path(
            "SHOWCASE_RUNTIME_DIR",
            Path(__file__).resolve().parent.parent.parent / "data_runtime",
        )
    )

    @property
    def vector_dir(self) -> Path:
        return _get_env_path("SHOWCASE_VECTOR_DIR", self.runtime_dir / "vector_store")

    @property
    def upload_dir(self) -> Path:
        return _get_env_path("SHOWCASE_UPLOAD_DIR", self.runtime_dir / "uploads")

    @property
    def eval_dir(self) -> Path:
        return _get_env_path("SHOWCASE_EVAL_DIR", self.runtime_dir / "evals")

    def ensure_runtime_dirs(self) -> None:
        self.runtime_dir.mkdir(parents=True, exist_ok=True)
        self.vector_dir.mkdir(parents=True, exist_ok=True)
        self.upload_dir.mkdir(parents=True, exist_ok=True)
        self.eval_dir.mkdir(parents=True, exist_ok=True)


def get_settings() -> Settings:
    settings = Settings()
    settings.ensure_runtime_dirs()
    return settings

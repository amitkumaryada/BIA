"""Contract loading, clause extraction, deterministic risk checks, and summaries."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from langchain_groq import ChatGroq

from .config import Settings, get_settings
from .models import ContractAnalysis, ContractClause, RiskFinding
from .observability import optional_traceable


RISK_RULEBOOK = {
    "missing_termination": {
        "severity": "high",
        "title": "Missing termination language",
        "reason": "Agreement does not clearly define termination rights or exit mechanics.",
        "followup_question": "What termination rights, notice periods, and post-termination obligations should be added?",
        "mitigation_note": "Add clear termination for convenience and breach language.",
    },
    "uncapped_liability": {
        "severity": "high",
        "title": "Uncapped liability",
        "reason": "Liability language appears broad or uncapped.",
        "followup_question": "Can the parties agree on a defined liability cap and carve-outs?",
        "mitigation_note": "Introduce a liability cap tied to recent fees plus narrow carve-outs.",
    },
    "auto_renewal": {
        "severity": "medium",
        "title": "Auto-renewal",
        "reason": "The contract renews automatically and may require proactive notice.",
        "followup_question": "What notice window and renewal controls should be negotiated?",
        "mitigation_note": "Require clear renewal notice and opt-out timing.",
    },
    "one_sided_indemnity": {
        "severity": "high",
        "title": "One-sided indemnity",
        "reason": "Indemnity obligation appears to run in only one direction.",
        "followup_question": "Should indemnity be mutual or limited to specific claim types?",
        "mitigation_note": "Balance indemnity obligations and add standard exclusions.",
    },
    "broad_data_usage": {
        "severity": "high",
        "title": "Broad data usage wording",
        "reason": "Data use rights appear broader than service delivery needs.",
        "followup_question": "Can data use be limited to service delivery, support, and security purposes?",
        "mitigation_note": "Limit data use, define anonymization requirements, and tighten privacy language.",
    },
    "weak_sla": {
        "severity": "medium",
        "title": "Weak SLA/support commitment",
        "reason": "Support or uptime language is vague or unenforceable.",
        "followup_question": "What measurable uptime, response, and remediation commitments are needed?",
        "mitigation_note": "Add measurable service levels and response times.",
    },
    "unclear_governing_law": {
        "severity": "medium",
        "title": "Unclear governing law or jurisdiction",
        "reason": "Governing law language is missing or too vague.",
        "followup_question": "Which governing law and venue should apply to disputes?",
        "mitigation_note": "Specify jurisdiction and venue explicitly.",
    },
}


class ContractService:
    def __init__(self, settings: Settings | None = None):
        self.settings = settings or get_settings()
        self.data_dir = Path(self.settings.data_dir)

    def list_samples(self) -> list[str]:
        return sorted(path.name for path in self.data_dir.glob("*.md"))

    def load_contract(self, contract_name: str | None = None, text: str | None = None) -> dict[str, Any]:
        if text is not None:
            return {"contract_name": contract_name or "uploaded_contract", "text": text}
        if not contract_name:
            raise ValueError("contract_name is required when text is not provided")
        path = self.data_dir / contract_name
        if not path.exists():
            raise FileNotFoundError(f"Contract sample not found: {contract_name}")
        return {"contract_name": contract_name, "text": path.read_text(encoding="utf-8")}

    @optional_traceable("contract.extract_clauses")
    def extract_contract_clauses(self, contract_text: str) -> list[dict[str, Any]]:
        clauses = []
        current_heading = "Introduction"
        current_lines: list[str] = []
        block_start = 0
        running_offset = 0

        for line in contract_text.splitlines(keepends=True):
            stripped = line.strip()
            is_heading = stripped.startswith("#") or (
                stripped.endswith(":") and len(stripped.split()) <= 8
            )
            if is_heading:
                if current_lines:
                    text = "".join(current_lines).strip()
                    clauses.append(
                        ContractClause(
                            clause_id=f"clause_{len(clauses) + 1}",
                            heading=current_heading,
                            text=text,
                            offset_start=block_start,
                            offset_end=block_start + len(text),
                        ).model_dump()
                    )
                current_heading = stripped.lstrip("#").strip(": ").strip() or "Section"
                current_lines = []
                block_start = running_offset + len(line)
            else:
                current_lines.append(line)
            running_offset += len(line)

        if current_lines:
            text = "".join(current_lines).strip()
            clauses.append(
                ContractClause(
                    clause_id=f"clause_{len(clauses) + 1}",
                    heading=current_heading,
                    text=text,
                    offset_start=block_start,
                    offset_end=block_start + len(text),
                ).model_dump()
            )

        if not clauses:
            chunk = contract_text.strip()
            clauses.append(
                ContractClause(
                    clause_id="clause_1",
                    heading="Document",
                    text=chunk,
                    offset_start=0,
                    offset_end=len(chunk),
                ).model_dump()
            )
        return clauses

    @optional_traceable("contract.highlight_risks")
    def highlight_contract_risks(self, contract_name: str, contract_text: str) -> dict[str, Any]:
        clauses = self.extract_contract_clauses(contract_text)
        findings = self._apply_risk_rules(contract_text, clauses)
        return {
            "contract_name": contract_name,
            "findings": findings,
            "clause_count": len(clauses),
        }

    def summarize_contract_risks(self, contract_name: str, contract_text: str) -> dict[str, Any]:
        findings = self.highlight_contract_risks(contract_name, contract_text)["findings"]
        summary = self._summarize_with_llm(contract_name, findings)
        return ContractAnalysis(
            contract_name=contract_name,
            finding_count=len(findings),
            findings=[RiskFinding(**finding) for finding in findings],
            executive_summary=summary,
        ).model_dump()

    def suggest_contract_followups(self, contract_name: str, contract_text: str) -> dict[str, Any]:
        findings = self.highlight_contract_risks(contract_name, contract_text)["findings"]
        return {
            "contract_name": contract_name,
            "followups": [
                {
                    "risk_id": finding["risk_id"],
                    "severity": finding["severity"],
                    "followup_question": finding["followup_question"],
                }
                for finding in findings
            ],
        }

    def _apply_risk_rules(
        self,
        contract_text: str,
        clauses: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        findings = []
        lower_text = contract_text.lower()

        if "termination" not in lower_text:
            findings.append(self._document_level_finding("missing_termination", contract_text))

        for clause in clauses:
            text = clause["text"].lower()
            heading = clause["heading"].lower()
            if "renews automatically" in text or "auto-renew" in text:
                findings.append(self._clause_finding("auto_renewal", clause))
            if "aggregate liability is not limited" in text or (
                "liability" in heading and "cap" not in text and "limited" not in text
            ):
                findings.append(self._clause_finding("uncapped_liability", clause))
            if "indemnify provider" in text or "indemnify vendor" in text:
                findings.append(self._clause_finding("one_sided_indemnity", clause))
            if "use customer usage data" in text or "service-generated content" in text:
                findings.append(self._clause_finding("broad_data_usage", clause))
            if "commercially reasonable efforts" in text and "uptime" not in text:
                findings.append(self._clause_finding("weak_sla", clause))
            if "applicable law" in text and "new york" not in text and "california" not in text:
                findings.append(self._clause_finding("unclear_governing_law", clause))

        deduped = {finding["risk_id"]: finding for finding in findings}
        return list(deduped.values())

    def _document_level_finding(self, rule_key: str, contract_text: str) -> dict[str, Any]:
        rule = RISK_RULEBOOK[rule_key]
        excerpt = contract_text[:180]
        return RiskFinding(
            risk_id=rule_key,
            severity=rule["severity"],
            title=rule["title"],
            reason=rule["reason"],
            source_excerpt=excerpt,
            section_heading="Document",
            offset_start=0,
            offset_end=min(len(contract_text), len(excerpt)),
            followup_question=rule["followup_question"],
            mitigation_note=rule["mitigation_note"],
        ).model_dump()

    def _clause_finding(self, rule_key: str, clause: dict[str, Any]) -> dict[str, Any]:
        rule = RISK_RULEBOOK[rule_key]
        return RiskFinding(
            risk_id=f"{rule_key}:{clause['clause_id']}",
            severity=rule["severity"],
            title=rule["title"],
            reason=rule["reason"],
            source_excerpt=clause["text"][:220],
            section_heading=clause["heading"],
            offset_start=clause["offset_start"],
            offset_end=clause["offset_end"],
            followup_question=rule["followup_question"],
            mitigation_note=rule["mitigation_note"],
        ).model_dump()

    def _summarize_with_llm(self, contract_name: str, findings: list[dict[str, Any]]) -> str:
        if not findings:
            return f"{contract_name} has no flagged risks based on the current deterministic rules."
        if self.settings.groq_api_key:
            try:
                model = ChatGroq(
                    api_key=self.settings.groq_api_key,
                    model=self.settings.groq_model,
                    temperature=0,
                )
                prompt = (
                    "Write a concise executive summary of the contract risks below. "
                    "Mention the most severe items first and include negotiation actions.\n\n"
                    f"Contract: {contract_name}\nFindings: {findings}"
                )
                return model.invoke(prompt).content
            except Exception:
                pass
        top = ", ".join(f"{finding['title']} ({finding['severity']})" for finding in findings[:3])
        return f"{contract_name} review found {len(findings)} issue(s). Highest priority items: {top}."

"""Streamlit interface for running the catalog and contract demos through MCP."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path

import streamlit as st
from streamlit.web import cli as stcli

if __package__ in (None, ""):
    sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
    from catalog_contract_mcp_showcase.client import call_tool, _extract_content
    from catalog_contract_mcp_showcase.contracts import ContractService
    from catalog_contract_mcp_showcase.observability import trace_context
else:
    from .client import call_tool, _extract_content
    from .contracts import ContractService
    from .observability import trace_context


def run_tool(name: str, arguments: dict):
    return _extract_content(asyncio.run(call_tool(name, arguments)))


def render_catalog_tab() -> None:
    st.subheader("Catalog RAG")
    query = st.text_input("Search or ask a question", value="Which product fits semantic search with SOC2 controls?")
    category = st.selectbox("Category", ["", "Catalog Management", "Search", "Procurement", "Support", "Security"])
    max_price = st.number_input("Max price", min_value=0, value=25000, step=1000)
    compliance_tag = st.selectbox("Compliance tag", ["", "SOC2", "GDPR", "HIPAA", "ISO27001"])

    if st.button("Run catalog workflow", use_container_width=True):
        with trace_context(
            "streamlit.catalog_workflow",
            metadata={"surface": "streamlit", "domain": "catalog", "query": query},
        ) as run:
            run_tool("index_catalog_data", {"force_reindex": False})
            search_result = run_tool(
                "search_catalog",
                {
                    "query": query,
                    "top_k": 3,
                    "category": category or None,
                    "max_price": max_price if max_price > 0 else None,
                    "compliance_tag": compliance_tag or None,
                },
            )
            answer_result = run_tool(
                "answer_catalog_question",
                {
                    "question": query,
                    "category": category or None,
                    "max_price": max_price if max_price > 0 else None,
                    "compliance_tag": compliance_tag or None,
                },
            )
        st.markdown("### Grounded answer")
        st.write(answer_result["answer"])
        st.markdown("### Citations")
        st.json(answer_result["citations"])
        st.markdown("### Retrieved products")
        st.json(search_result["matches"])
        if hasattr(run, "get_url"):
            st.caption(f"LangSmith trace: {run.get_url()}")


def render_contract_tab() -> None:
    st.subheader("Contract Risk Highlighter")
    service = ContractService()
    selected_contract = st.selectbox("Sample contract", service.list_samples())
    uploaded_file = st.file_uploader("Optional .txt or .md upload", type=["txt", "md"])

    if st.button("Analyze contract", use_container_width=True):
        contract_name = selected_contract
        contract_text = None
        if uploaded_file is not None:
            contract_name = uploaded_file.name
            contract_text = uploaded_file.getvalue().decode("utf-8")

        with trace_context(
            "streamlit.contract_workflow",
            metadata={"surface": "streamlit", "domain": "contract", "contract_name": contract_name},
        ) as run:
            highlight_result = run_tool(
                "highlight_contract_risks",
                {"contract_name": contract_name, "contract_text": contract_text},
            )
            summary_result = run_tool(
                "summarize_contract_risks",
                {"contract_name": contract_name, "contract_text": contract_text},
            )

        st.markdown("### Executive summary")
        st.write(summary_result["executive_summary"])
        st.markdown("### Findings")
        st.dataframe(summary_result["findings"], use_container_width=True)
        st.markdown("### Raw highlighted output")
        st.code(json.dumps(highlight_result, indent=2), language="json")
        if hasattr(run, "get_url"):
            st.caption(f"LangSmith trace: {run.get_url()}")


def render_app() -> None:
    st.set_page_config(page_title="Catalog + Contract MCP Showcase", layout="wide")
    st.title("Catalog RAG + Contract Risk Highlighter")
    catalog_tab, contract_tab = st.tabs(["Catalog RAG", "Contract Risk Highlighter"])
    with catalog_tab:
        render_catalog_tab()
    with contract_tab:
        render_contract_tab()


def main() -> None:
    sys.argv = ["streamlit", "run", __file__]
    sys.exit(stcli.main())


if __name__ == "__main__":
    render_app()
